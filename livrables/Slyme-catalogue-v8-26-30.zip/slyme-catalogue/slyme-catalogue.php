<?php
/**
 * Plugin Name: Slyme — Catalogue fluide
 * Description: Catalogue fluide, affiche Xiaomi, fiches produit premium et commande WhatsApp.
 * Version: 8.26.30
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: Slyme Abidjan
 * License: GPL-2.0-or-later
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/device-classification.php';

final class Slyme_Catalogue_V6 {
    const VERSION = '8.26.30';
    private static $config;
    private static $data = array();
    private static $section_cache;
    private static $section_dirty = false;
    private static $hero_product;
    private static $lists_invalidated = false;
    private static $search_index_cache;

    public static function boot() {
        foreach (array('woocommerce_update_product','woocommerce_new_product','woocommerce_update_product_variation','woocommerce_new_product_variation','woocommerce_product_set_stock','woocommerce_variation_set_stock','woocommerce_product_set_stock_status','woocommerce_variation_set_stock_status','woocommerce_delete_product_transients','woocommerce_updated_product_sales','update_option_woocommerce_hide_out_of_stock_items','wc_after_products_starting_sales','wc_after_products_ending_sales') as $hook) add_action($hook, array(__CLASS__, 'clear_lists_cache'));
        add_filter('posts_clauses', array(__CLASS__, 'merchandising_clauses'), 20, 2);
        foreach (array('deleted_post','trashed_post','untrashed_post','post_updated') as $hook) add_action($hook, array(__CLASS__, 'post_cache_changed'), 10, 2);
        add_action('set_object_terms', array(__CLASS__, 'post_cache_changed'));
        add_action('deleted_term_relationships', array(__CLASS__, 'post_cache_changed'));
        add_action('transition_post_status', array(__CLASS__, 'product_status_changed'), 10, 3);
        foreach (array('edited_term','delete_term') as $hook) add_action($hook, array(__CLASS__, 'catalogue_term_changed'), 10, 3); 
        foreach (array('added_post_meta','updated_post_meta','deleted_post_meta') as $hook) add_action($hook, array(__CLASS__, 'stock_meta_changed'), 10, 3);
        add_action('admin_init',array(__CLASS__,'purge_after_update'));
        add_filter('wp_inline_script_attributes',array(__CLASS__,'essential_inline_attributes'));
        add_filter('wp_script_attributes',array(__CLASS__,'essential_script_attributes'));
        add_filter('script_loader_tag',array(__CLASS__,'essential_script_tag'),10,2);
        add_filter('style_loader_tag',array(__CLASS__,'essential_style_tag'),10,2);
        add_filter('litespeed_optm_js_defer_exc',array(__CLASS__,'essential_js_excludes'));
        add_filter('litespeed_optimize_js_excludes',array(__CLASS__,'essential_js_excludes'));
        add_filter('litespeed_optm_gm_js_exc',array(__CLASS__,'essential_js_excludes'));
        add_filter('woocommerce_single_product_image_thumbnail_html',array(__CLASS__,'gallery_image_loading'),10,2);
        add_action('wp_head',array(__CLASS__,'preload_campaign_image'),3);
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_shortcode('slyme_catalogue', array(__CLASS__, 'catalogue'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('wp_footer', array(__CLASS__, 'header_search_form'));
        add_action('rest_api_init', array(__CLASS__, 'routes'));
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'whatsapp'), 35);
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
        add_action('admin_notices', array(__CLASS__, 'dependency_notice'));
    }

    private static function config() {
        if (null === self::$config) {
            self::$config = json_decode(file_get_contents(__DIR__ . '/catalogue.json'), true);
        }
        return is_array(self::$config) ? self::$config : array('sections' => array(), 'products' => array(), 'images' => array());
    }

    private static function catalogue_page() {
        return is_singular() && has_shortcode((string) get_post_field('post_content', get_queried_object_id()), 'slyme_catalogue');
    }
    public static function body_class($classes) {
        if (self::catalogue_page()) $classes[] = 'slyme-catalogue-page';
        return $classes;
    }
    public static function assets() {
        $url = plugin_dir_url(__FILE__) . 'assets/';
        if (current_user_can('manage_options') && isset($_GET['slyme_diagnostic'])) wp_enqueue_script('slyme-diagnostic', $url . 'diagnostic-8-26-29.js', array(), self::VERSION, array('in_footer'=>true, 'strategy'=>'defer'));
        wp_register_script('slyme-interactions', $url . 'interactions-8-26-29.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_register_style('slyme-catalogue-v5', $url . 'catalogue-8-26-29.css', array(), self::VERSION);
        wp_register_script('slyme-motion-v5', $url . 'motion-8-26-29.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_register_script('slyme-offers-scroll', $url . 'offers-scroll-8-26-29.js', array(), self::VERSION, array('in_footer'=>true, 'strategy'=>'defer'));
        wp_register_style('slyme-offers-scroll', $url . 'offers-scroll-8-26-29.css', array('slyme-catalogue-v5'), self::VERSION);
        wp_register_script('slyme-catalogue-v5', $url . 'catalogue-8-26-29.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        if (self::catalogue_page() || (function_exists('is_product') && is_product())) {
            wp_enqueue_script('slyme-image-loading', $url . 'image-loading-8-26-29.js', array(), self::VERSION, array('in_footer'=>true, 'strategy'=>'defer'));
        }
        if (self::catalogue_page()) {
            self::enqueue();
        }
        if (function_exists('is_product') && is_product()) {
            wp_enqueue_style('slyme-related-products', $url . 'related-products-8-26-29.css', array(), self::VERSION);
            wp_enqueue_style('slyme-whatsapp-v5', $url . 'whatsapp-8-26-29.css', array(), self::VERSION);
            wp_enqueue_script('slyme-whatsapp-v5', $url . 'whatsapp-8-26-29.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        }
    }

    private static function enqueue() {
        wp_enqueue_style('slyme-catalogue-v5');
        if (empty($_GET['slyme_collection']) && empty($_GET['slyme_search'])) {
            wp_enqueue_script('slyme-motion-v5');
            wp_enqueue_script('slyme-offers-scroll');
            wp_enqueue_style('slyme-offers-scroll');
        }
        wp_enqueue_script('slyme-catalogue-v5');
    }

    private static function public_product($product) {
        return $product && 'product' === get_post_type($product->get_id()) && 'publish' === $product->get_status() && !post_password_required($product->get_id()) && '' === (string) get_post_field('post_password', $product->get_id()) && in_array($product->get_catalog_visibility(), array('visible', 'catalog'), true);
    }

    private static function prime_card_caches($ids) {
        $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
        if (!$ids) return;
        _prime_post_caches($ids, true, true);
        $attachments = array();
        foreach ($ids as $id) {
            $image_id = (int) get_post_meta($id, '_thumbnail_id', true);
            if ($image_id) $attachments[] = $image_id;
            // Prime the verified alternate too; product_data still validates and selects it.
            if ('iphone-18-pro-max' === get_post_field('post_name', $id) && in_array(6361, array_map('absint', explode(',', (string) get_post_meta($id, '_product_image_gallery', true))), true)) $attachments[] = 6361;
        }
        // One batch for attachment posts and metadata, instead of one read per card.
        if ($attachments) _prime_post_caches(array_values(array_unique($attachments)), false, true);
    }

    public static function product_data($product, $with_hero = false, $with_benefit = true) {
        if (!self::public_product($product)) return null;
        $id = $product->get_id();
        $data_key = $id . ($with_benefit ? ':full' : ':search');
        if (isset(self::$data[$data_key])) {
            $cached = self::$data[$data_key];
            if ($with_hero) $cached['hero'] = self::hero_data($product, $cached);
            return $cached;
        }
        $config = self::config();
        $price = $product->get_price();
        $prefix = '';
        if ($product->is_type('variable')) {
            $price = $product->get_variation_price('min', true);
            $max = $product->get_variation_price('max', true);
            if ('' !== $price && (float) $max > (float) $price) $prefix = 'À partir de';
        } elseif ($product->is_type('grouped')) {
            $amounts = array();
            foreach ($product->get_children() as $child_id) {
                $child = wc_get_product($child_id);
                if (self::public_product($child) && '' !== $child->get_price()) $amounts[] = wc_get_price_to_display($child);
            }
            $price = $amounts ? min($amounts) : '';
            if ($amounts) $prefix = 'À partir de';
        } elseif ('' !== $price) {
            $price = wc_get_price_to_display($product);
        }
        $currency = get_woocommerce_currency();
        $symbol = in_array($currency, array('XOF', 'XAF'), true) ? 'FCFA' : html_entity_decode(get_woocommerce_currency_symbol($currency), ENT_QUOTES, 'UTF-8');
        $image_id = $product->get_image_id();
        // Verified Bordeaux image in this product's own gallery. Catalogue only.
        if ($product->get_slug() === 'iphone-18-pro-max' && in_array(6361, array_map('absint', $product->get_gallery_image_ids()), true) && wp_attachment_is_image(6361)) $image_id = 6361;
        $image = isset($config['images'][$image_id]) ? $config['images'][$image_id] : '';
        $current_image = wp_get_attachment_url($image_id);
        if ($image && $current_image) {
            $current_path = strstr((string) wp_parse_url($current_image, PHP_URL_PATH), '/wp-content/uploads/');
            $optimized_path = strstr((string) wp_parse_url($image, PHP_URL_PATH), '/wp-content/uploads/');
            if (!$current_path || rawurldecode($current_path) !== rawurldecode((string) $optimized_path)) $image = '';
        }
        if (!$image) $image = wp_get_attachment_image_url($image_id, 'medium');
        if (!$image) $image = wc_placeholder_img_src('woocommerce_thumbnail');
        $brand = isset($config['products'][$id]['brand']) ? $config['products'][$id]['brand'] : '';
        if (taxonomy_exists('product_brand')) {
            $brands = get_the_terms($id, 'product_brand');
            if ($brands && !is_wp_error($brands)) $brand = reset($brands)->name;
        }
        $result = array(
            'id' => $id,
            'name' => html_entity_decode(wp_strip_all_tags($product->get_name()), ENT_QUOTES, 'UTF-8'),
            'benefit' => $with_benefit ? self::card_benefit($product) : '',
            'url' => get_permalink($id),
            'image' => esc_url_raw($image),
            'srcset' => self::responsive_image($image_id,$image),
            'brand' => html_entity_decode($brand, ENT_QUOTES, 'UTF-8'),
            'price' => array(
                'label' => $prefix,
                'amount' => '' === $price ? '' : number_format((float) $price, wc_get_price_decimals(), ',', ' '),
                'currency' => $symbol,
                'suffix' => html_entity_decode(wp_strip_all_tags($product->get_price_suffix()), ENT_QUOTES, 'UTF-8'),
            ),
        );
        self::$data[$data_key] = $result;
        if ($with_hero) $result['hero'] = self::hero_data($product, $result);
        return $result;
    }

    private static function hero_data($product, $data) {
        $config = self::config();
        if (empty($config['hero']) || $product->get_slug() !== $config['hero']['slug']) return null;
        $settings = $config['hero'];
        $colors = array();
        // Les variantes publiées dans WooCommerce déterminent les couleurs et leurs prix.
        if ($product->is_type('variable')) {
            $prices = $product->get_variation_prices(true);
            $variations = $product->get_available_variations('objects');
            foreach ($settings['colors'] as $color) {
                $amounts = array();
                $image = ''; $hero_image_id=0;
                foreach ($variations as $variation) {
                    $attributes = $variation->get_variation_attributes();
                    if (!isset($attributes['attribute_pa_couleur']) || $attributes['attribute_pa_couleur'] !== $color['key']) continue;
                    $vid = $variation->get_id();
                    if (!isset($prices['price'][$vid]) || '' === $prices['price'][$vid]) continue;
                    $amounts[] = (float) $prices['price'][$vid];
                    if (!$image && $variation->get_image_id()) { $hero_image_id=$variation->get_image_id();$image=wp_get_attachment_image_url($hero_image_id,'full'); }
                }
                if (!$amounts) continue;
                $price = $data['price'];
                $price['amount'] = number_format(min($amounts), wc_get_price_decimals(), ',', ' ');
                $price['label'] = max($amounts) > min($amounts) ? 'À partir de' : '';
                $colors[] = array('key' => $color['key'], 'label' => $color['label'],
                    'image' => esc_url_raw($image ? $image : $color['image']), 'srcset'=>self::responsive_image($hero_image_id,$image,true),
                    'url' => add_query_arg('attribute_pa_couleur', $color['key'], $data['url']), 'price' => $price);
            }
        }
        $image = wp_get_attachment_image_url($product->get_image_id(), 'full');
        if (!$image && !empty($settings['colors'][0]['image'])) $image = $settings['colors'][0]['image'];
        return array('title' => preg_replace('/^Samsung\s+/iu', '', $data['name']),
            'tagline' => $settings['tagline'], 'image' => esc_url_raw($image), 'srcset'=>self::responsive_image($product->get_image_id(),$image,true), 'colors' => $colors);
    }

    private static function hero_product() {
        if (null !== self::$hero_product) return self::$hero_product;
        $settings = self::config()['hero'] ?? array();
        if (empty($settings['slug'])) return self::$hero_product = false;
        $product = wc_get_product(absint($settings['id'] ?? 0));
        if (!$product || $product->get_slug() !== $settings['slug']) {
            $post = get_page_by_path($settings['slug'], OBJECT, 'product');
            $product = $post ? wc_get_product($post->ID) : null;
        }
        return self::$hero_product = self::public_product($product) && $product->get_slug() === $settings['slug'] ? $product : false;
    }

    private static function hero() {
        // Visuel fourni par la boutique, texte HTML lisible à toute taille d’écran.
        // Une annonce sans prix ni disponibilité fictive, sans requête de variantes.
        $url = plugin_dir_url(__FILE__) . 'assets/';
        $uid = wp_unique_id('slyme-campaign-');
        $base = get_permalink(get_queried_object_id());
        if (!$base) $base = home_url('/');
        $out = '<section class="slyme-campaign" aria-labelledby="' . esc_attr($uid) . '-title">';
        $out .= '<div class="slyme-campaign-heading"><p class="slyme-campaign-label"><span class="slyme-campaign-soon">Bientôt disponible</span><span>Chez Slyme Abidjan CI</span></p><h2 id="' . esc_attr($uid) . '-title"><strong>Xiaomi 18 Pro<span>&amp; Pro Max</span></strong></h2><p class="slyme-campaign-subtitle">Développé conjointement <br>par Xiaomi et Leica.</p></div>';
        $out .= '<picture class="slyme-campaign-art"><source type="image/webp" srcset="' . esc_url($url . 'xiaomi-18-visual-v21-480.webp') . ' 480w, ' . esc_url($url . 'xiaomi-18-visual-v21-800.webp') . ' 800w, ' . esc_url($url . 'xiaomi-18-visual-v21-1200.webp') . ' 1200w, ' . esc_url($url . 'xiaomi-18-visual-v21-1512.webp') . ' 1512w" sizes="(min-width:1440px) 676px, (min-width:1024px) 49vw, (min-width:768px) 45vw, calc(100vw - 40px)">';
        $out .= '<img data-no-lazy="1" src="' . esc_url($url . 'xiaomi-18-visual-v21.jpg') . '" width="1512" height="1512" loading="eager" fetchpriority="high" decoding="async" draggable="false" alt="Xiaomi 18 Pro et Pro Max : les quatre téléphones du nouveau visuel Slyme, dont le modèle violet tenu en main."></picture>';
        $out .= '<div class="slyme-campaign-footer"><a class="slyme-campaign-link" href="' . esc_url(self::view_url($base, 'smartphones')) . '">Découvrir nos smartphones <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"/></svg></a><span class="slyme-campaign-note">La nouveauté arrive chez vous.</span></div></section>';
        return $out;
    }

    private static function price_html($price) {
        $out = '<p class="slyme-product-price">';
        if ('' === $price['amount']) return $out . '<span class="slyme-price-request">Prix sur demande</span></p>';
        if ($price['label']) $out .= '<span class="slyme-price-label">' . esc_html($price['label']) . ' </span>';
        $out .= '<span class="slyme-price-amount">' . esc_html($price['amount']) . ' <span class="slyme-price-currency">' . esc_html($price['currency']) . '</span></span>';
        if ($price['suffix']) $out .= '<span class="slyme-price-note">' . esc_html($price['suffix']) . '</span>';
        return $out . '</p>';
    }

    private static function card_benefit($product) {
        return Slyme_Card_Benefits::get($product);
    }

    // Les fichiers utiles sont différés jusqu’à l’analyse HTML, jamais jusqu’au premier geste.
    public static function purge_after_update() {
        if(!current_user_can('manage_options') || get_option('slyme_catalogue_assets_version','')===self::VERSION)return;
        update_option('slyme_catalogue_assets_version',self::VERSION,false);
        self::clear_lists_cache();
        // Une seule purge à la mise à jour ; jamais au défilement ni à chaque visite.
        do_action('litespeed_purge_all');
    }
    public static function essential_inline_attributes($attributes) {
        $id=$attributes['id']??'';
        $essential=strpos($id,'slyme-')===0 || strpos($id,'sinatra-js-')===0 || strpos($id,'wp-hooks-js-')===0 || strpos($id,'gla-gtag-events-js-')===0 || $id==='google_gtagjs-js-after' || (function_exists('is_product') && is_product() && (strpos($id,'wc-add-to-cart-variation-')===0 || strpos($id,'wc-single-product-')===0));
        if($essential)$attributes['data-no-optimize']='1';
        return $attributes;
    }
    public static function essential_script_attributes($attributes) {
        // Site Kit prints these tags directly: they have no enqueue handle.
        // Its sign-in script reads data-siwg-config from document.currentScript.
        $src=$attributes['src']??'';
        if(isset($attributes['data-siwg-config']) || strpos($src,'/google-site-kit/dist/assets/js/sign-in-with-google')!==false || preg_match('~^https://accounts\.google\.com/gsi/client(?:[?#]|$)~',$src))$attributes['data-no-optimize']='1';
        return $attributes;
    }
    public static function essential_script_tag($tag,$handle) {
        $essential=strpos($handle,'slyme-')===0 || in_array($handle,array('sinatra-js','wp-hooks','gla-gtag-events'),true) || (function_exists('is_product') && is_product() && in_array($handle,array('jquery-core','jquery-migrate','wc-add-to-cart-variation','wc-single-product','flexslider','zoom','photoswipe','photoswipe-ui-default'),true));
        if(!$essential)return $tag;
        // WordPress may pass inline-before + external + inline-after in ONE block.
        // A protected inline tag must not leave the external file unprotected.
        $processor=new WP_HTML_Tag_Processor($tag);
        while($processor->next_tag('SCRIPT'))$processor->set_attribute('data-no-optimize','1');
        return $processor->get_updated_html();
    }
    public static function essential_style_tag($tag,$handle) {
        return strpos($handle,'slyme-')===0 && strpos($tag,'data-no-optimize=')===false ? str_replace('<link ','<link data-no-optimize="1" ',$tag) : $tag;
    }
    public static function essential_js_excludes($list) {
        // Native navigation must initialize before the first tap, including its settings.
        $list=is_array($list)?$list:array();
        foreach(array('/slyme-catalogue/assets/','/themes/sinatra/assets/js/sinatra.','sinatra_vars','slymeHeaderSearch','slymeCartConfig','/wp-includes/js/dist/hooks','/google-listings-and-ads/js/build/gtag-events','glaGtagData','/google-site-kit/dist/assets/js/sign-in-with-google','accounts.google.com/gsi/client','data-siwg-config') as $path)$list[]=$path;
        if(function_exists('is_product') && is_product()) foreach(array('/jquery/jquery','/wc-add-to-cart-variation','/single-product','/jquery.flexslider','/jquery.zoom','/photoswipe') as $path)$list[]=$path;
        return array_values(array_unique($list));
    }
    public static function gallery_image_loading($html,$attachment_id) {
        // The main photo gets the network first; gallery alternatives stay native-lazy.
        static $first=true;
        $tags=new WP_HTML_Tag_Processor($html);
        if($tags->next_tag('IMG')){
            $tags->set_attribute('data-no-lazy','1');
            $tags->set_attribute('loading',$first?'eager':'lazy');
            $tags->set_attribute('fetchpriority',$first?'high':'low');
            $tags->set_attribute('decoding','async');
            // Keep a native srcset when present. Reuse the existing image service
            // only when WordPress can supply sizes for this attachment.
            if(!$tags->get_attribute('srcset')){
                $responsive=self::responsive_image($attachment_id,(string)$tags->get_attribute('src'),true);
                if($responsive){
                    $tags->set_attribute('srcset',$responsive);
                    if(!$tags->get_attribute('sizes'))$tags->set_attribute('sizes','(max-width: 768px) calc(100vw - 40px), (max-width: 1280px) 50vw, 640px');
                }
            }
            $html=$tags->get_updated_html();$first=false;
        }
        return $html;
    }
    public static function responsive_image($id,$fallback='',$hero=false) {
        if (!$id) return '';
        $native=(string)wp_get_attachment_image_srcset($id,'medium_large');
        // Réutilise le CDN déjà actif. Aucun nouveau service n’est activé.
        $host=(string)wp_parse_url($fallback,PHP_URL_HOST);
        $meta=wp_get_attachment_metadata($id);
        if(!preg_match('/^i[0-3]\.wp\.com$/',$host) || empty($meta['width']))return $native;
        $maximum=min((int)$meta['width'],$hero?1600:640);
        $widths=$hero?array(320,640,960,1280):array(80,160,320,480);
        $widths[]= $maximum;sort($widths);$set=array();
        foreach(array_unique($widths) as $width){
            if($width>$maximum)continue;
            $url=remove_query_arg(array('fit','resize','w','h','crop','zoom'),$fallback);
            $url=add_query_arg('w',$width,$url);
            $set[]=esc_url_raw($url).' '.$width.'w';
        }
        return implode(', ',$set);
    }

    public static function preload_campaign_image() {
        // Same responsive WebP candidates as the picture below. No product query.
        if (!self::catalogue_page() || !empty($_GET['slyme_collection']) || !empty($_GET['slyme_search'])) return;
        $url=plugin_dir_url(__FILE__).'assets/';
        echo '<link data-no-optimize="1" rel="preload" as="image" type="image/webp" fetchpriority="high" href="'.esc_url($url.'xiaomi-18-visual-v21-800.webp').'" imagesrcset="'.esc_url($url.'xiaomi-18-visual-v21-480.webp').' 480w, '.esc_url($url.'xiaomi-18-visual-v21-800.webp').' 800w, '.esc_url($url.'xiaomi-18-visual-v21-1200.webp').' 1200w, '.esc_url($url.'xiaomi-18-visual-v21-1512.webp').' 1512w" imagesizes="(min-width:1440px) 676px, (min-width:1024px) 49vw, (min-width:768px) 45vw, calc(100vw - 40px)">' . "\n";
    }

    public static function rest_section($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable','Catalogue indisponible.',array('status'=>503));
        $key = sanitize_key((string) $request->get_param('section'));
        $offset = (string) $request->get_param('offset');
        if (!in_array($offset,array('0','3'),true) && !(in_array($key,array('nouveautes','smartphones'),true) && $offset === '6')) return new WP_Error('slyme_offset','Position invalide.',array('status'=>400));
        foreach (self::config()['sections'] as $section) {
            if ($section['key'] !== $key || !empty($section['nav_only'])) continue;
            $ids = array_slice(self::section_ids($section),(int)$offset,self::section_limit($section)-(int)$offset);
            self::prime_card_caches($ids);
            $html = '';
            foreach ($ids as $id) $html .= self::card(wc_get_product($id));
            self::save_section_cache();
            return self::response(array(array('key'=>$key,'html'=>$html,'empty'=>$html === '')));
        }
        return new WP_Error('slyme_section','Collection inconnue.',array('status'=>404));
    }

    private static function normalize_search($text) {
        $text = strtolower(remove_accents(wp_strip_all_tags((string)$text)));
        // Même modèle, qu’il soit saisi collé, séparé ou avec le signe Plus.
        $text = preg_replace('/\b(galaxy|iphone|pixel|note)(?=[a-z]?\d)/', '$1 ', $text);
        $text = preg_replace('/\b([samfz])[\s-]+(\d{1,3})\b/', '$1$2', $text);
        $text = preg_replace('/\b([a-z]+\d{1,3})\s*\+(?=\s|$)/', '$1 plus ', $text);
        $text = preg_replace('/(\d)(ultra|plus|fe|edge|promax|pro|max|mini|lite|fold|flip)\b/', '$1 $2', $text);
        $text = preg_replace('/\bpromax\b/', 'pro max', $text);
        $text = preg_replace('/\b(telephones?|smartphones?)\b/','smartphone',$text);
        $text = preg_replace('/\bordinateurs?\b/','ordinateur',$text);
        $text = preg_replace('/\bmontres?\b/','montre',$text);
        $text = preg_replace('/\btablettes?\b/','tablette',$text);
        $text = preg_replace('/(\d+)\s*(gb|go)\b/u','$1go',$text);
        $text = preg_replace('/(\d+)\s*(tb|to)\b/u','$1to',$text);
        return trim(preg_replace('/[^a-z0-9]+/',' ',$text));
    }

    private static function search_index() {
        if (null !== self::$search_index_cache) return self::$search_index_cache;
        $saved = self::$lists_invalidated ? false : get_transient('slyme_search_index_v82624');
        if (is_array($saved) && isset($saved['items'], $saved['vocabulary']) && is_array($saved['items']) && is_array($saved['vocabulary'])) return self::$search_index_cache = $saved;
        global $wpdb;
        $args = self::query_args();
        $args['fields'] = 'ids';
        $args['posts_per_page'] = 3000;
        $args['no_found_rows'] = true;
        $args['update_post_meta_cache'] = false;
        $args['update_post_term_cache'] = false;
        $index = array();
        $product_ids = array_map('absint', (new WP_Query($args))->posts);
        if ($product_ids) {
            // Select only search fields; never hydrate/cache partial WP_Post objects.
            $ids = implode(',', $product_ids);
            $posts = $wpdb->get_results("SELECT ID,post_title,post_password FROM {$wpdb->posts} WHERE ID IN ($ids)");
            $titles = array();
            foreach ($posts as $post) if ($post->post_password === '') $titles[(int) $post->ID] = self::normalize_search($post->post_title);
            // Keep WP_Query order so equally ranked suggestions do not shuffle.
            foreach ($product_ids as $id) if (isset($titles[$id])) $index[$id] = array('title'=>$titles[$id], 'text'=>$titles[$id]);
        }
        if ($index) {
            $ids = implode(',',array_map('absint',array_keys($index)));
            $rows = $wpdb->get_results("SELECT tr.object_id,t.name,tt.taxonomy FROM {$wpdb->term_relationships} tr INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tr.object_id IN ($ids) AND (tt.taxonomy='product_cat' OR tt.taxonomy='product_brand' OR tt.taxonomy LIKE 'pa\\_%')");
            // Category, brand and attribute names recur across many products.
            // Reuse their normalized text only for this rebuild, preserving row order.
            $normalized_terms = array();
            foreach ($rows as $row) if (isset($index[$row->object_id])) {
                if (!isset($normalized_terms[$row->name])) $normalized_terms[$row->name] = self::normalize_search($row->name);
                $index[$row->object_id]['text'] .= ' ' . $normalized_terms[$row->name];
            }
            $rows = $wpdb->get_results("SELECT post_id,meta_value FROM {$wpdb->postmeta} WHERE post_id IN ($ids) AND meta_key='_product_attributes'");
            foreach ($rows as $row) {
                $attributes = maybe_unserialize($row->meta_value);
                if (!isset($index[$row->post_id]) || !is_array($attributes)) continue;
                foreach ($attributes as $attribute) if (empty($attribute['is_taxonomy']) && isset($attribute['value'])) $index[$row->post_id]['text'] .= ' ' . self::normalize_search($attribute['value']);
            }
        }
        $vocabulary = array();
        foreach ($index as $item) foreach (explode(' ', $item['text']) as $word) if ($word !== '') $vocabulary[$word] = true;
        self::$search_index_cache = array('items'=>$index, 'vocabulary'=>$vocabulary);
        // Product, stock, taxonomy and sale hooks invalidate this selection index.
        // Prices are read afresh by product_data, never stored in this cache.
        if (!self::$lists_invalidated) set_transient('slyme_search_index_v82624',self::$search_index_cache,HOUR_IN_SECONDS);
        return self::$search_index_cache;
    }

    private static function search_ids($term) {
        $normal = self::normalize_search($term);
        if (strlen($normal)<2 || strlen($normal)>80) return array();
        $tokens = array_values(array_unique(explode(' ',$normal)));
        $prepared = self::search_index();
        $index = $prepared['items'];
        $vocabulary = $prepared['vocabulary'];
        $terms = array();
        foreach ($tokens as $token) {
            $alternatives = array($token);
            // Une capacité ou un numéro de modèle ne doit jamais être corrigé.
            if (strlen($token)>=4 && !preg_match('/\d/',$token) && !isset($vocabulary[$token])) {
                $best = strlen($token)>=8 ? 2 : 1; $candidates = array();
                foreach ($vocabulary as $word=>$unused) {
                    if (strlen($word)<4 || preg_match('/\d/',$word) || abs(strlen($word)-strlen($token))>$best) continue;
                    $distance=levenshtein($token,$word);
                    if ($distance<$best) { $best=$distance; $candidates=array($word); }
                    elseif ($distance===$best) $candidates[]=$word;
                }
                $alternatives=array_merge($alternatives,array_slice($candidates,0,4));
            }
            $patterns = array();
            foreach ($alternatives as $position=>$alternative) {
                $patterns[] = array('pattern'=>'/\b'.preg_quote($alternative,'/').(strlen($alternative)<3 || preg_match('/\d/',$alternative) ? '\b' : '[a-z0-9]*\b').'/', 'weight'=>$position===0 ? 10 : 6);
            }
            $terms[]=$patterns;
        }
        $ranked=array();
        $accessory_pattern = '~' . Slyme_Device_Classification::accessory_pattern() . '~iu';
        $accessory_query = preg_match($accessory_pattern, $normal);
        $phrase = '/\b' . preg_quote($normal, '/') . '\b/';
        foreach ($index as $id=>$item) {
            $score=0; $all_in_title=true;
            foreach ($terms as $alternatives) {
                $match=0; $title_match=false;
                foreach ($alternatives as $candidate) {
                    if (preg_match($candidate['pattern'],$item['text'])) {
                        $in_title = (bool) preg_match($candidate['pattern'],$item['title']);
                        $title_match = $title_match || $in_title;
                        $match=max($match,$candidate['weight']+($in_title?4:0));
                    }
                }
                if (!$match) { $score=0;break; }
                $all_in_title = $all_in_title && $title_match;
                $score+=$match;
            }
            if ($score) {
                // Le modèle recherché dans le nom passe avant une simple mention d’attribut.
                if ($all_in_title) $score += 100;
                if (preg_match($phrase, $item['title'])) $score += 30;
                if ($item['title'] === $normal) $score += 60;
                // Les coques restent trouvables mais ne passent pas devant le téléphone.
                if (!$accessory_query && preg_match($accessory_pattern, $item['title'])) $score -= 500;
                $ranked[$id]=$score;
            }
        }
        arsort($ranked,SORT_NUMERIC);
        return array_keys($ranked);
    }

    private static function card($product, $eager = false) {
        $data = self::product_data($product);
        if (!$data) return '';
        $responsive = $data['srcset'];
        $image = '<img data-no-lazy="1" sizes="(max-width:599px) 44vw, (max-width:1023px) 220px, 240px"' . ($responsive ? ' srcset="' . esc_attr($responsive) . '"' : '') . ' src="' . esc_url($data['image']) . '" alt="' . esc_attr($data['name']) . '" width="600" height="600" decoding="async" draggable="false" loading="' . ($eager ? 'eager' : 'lazy') . '"' . ($eager ? ' fetchpriority="high"' : '') . '>';
        return '<a class="slyme-product-card" data-product-id="' . absint($data['id']) . '" href="' . esc_url($data['url']) . '" draggable="false"><div class="slyme-product-media" aria-hidden="true">' . $image . '</div><div class="slyme-product-content"><p class="slyme-product-brand">' . esc_html($data['brand']) . '</p><h4 class="slyme-product-name">' . esc_html($data['name']) . '</h4><p class="slyme-product-benefit">' . preg_replace('/(à partir de)/iu', '<strong class="slyme-starting-label">$1</strong>', esc_html($data['benefit'])) . '</p>' . self::price_html($data['price']) . '</div></a>';
    }

    private static function query_args() {
        $excluded = array('exclude-from-catalog');
        if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) $excluded[] = 'outofstock';
        return array('post_type' => 'product', 'post_status' => 'publish', 'has_password' => false, 'ignore_sticky_posts' => true,
            'tax_query' => array(array('taxonomy' => 'product_visibility', 'field' => 'slug', 'terms' => $excluded, 'operator' => 'NOT IN')));
    }

    public static function stock_meta_changed($meta_id, $product_id, $key) {
        if (in_array($key, array('_stock','_stock_status','_visibility','_price','_regular_price','_sale_price','_sale_price_dates_from','_sale_price_dates_to','_thumbnail_id','_product_image_gallery','_product_attributes','total_sales'), true) && in_array(get_post_type($product_id), array('product','product_variation'), true)) self::clear_lists_cache();
    }

    public static function post_cache_changed($id, $post = null) {
        $type = is_object($post) && isset($post->post_type) ? $post->post_type : get_post_type($id);
        if (in_array($type, array('product','product_variation'), true)) self::clear_lists_cache();
        elseif ('page' === $type) delete_transient('slyme_search_page');
    }

    public static function product_status_changed($new_status, $old_status, $post) {
        if ($new_status !== $old_status && in_array($post->post_type, array('product','product_variation'), true)) self::clear_lists_cache();
    }

    public static function catalogue_term_changed($term_id, $tt_id, $taxonomy) {
        if (in_array($taxonomy, array('product_cat','product_brand','product_visibility'), true) || strpos($taxonomy, 'pa_') === 0) self::clear_lists_cache();
    }

    private static function delete_lists_cache() {
        delete_transient('slyme_lists_v828');
        delete_transient('slyme_lists_v827');
        delete_transient('slyme_lists_v810');
        delete_transient('slyme_search_index_v812');
        delete_transient('slyme_search_index_v829');
        delete_transient('slyme_search_index_v82624');
    }

    public static function clear_lists_cache() {
        // Always invalidate in-memory data, but do not repeat database deletes for
        // every price, stock and taxonomy hook fired during the same product import.
        self::$data = array();
        self::$search_index_cache = null;
        self::$section_cache = null;
        self::$hero_product = null;
        self::$section_dirty = false;
        if (self::$lists_invalidated) return;
        self::$lists_invalidated = true;
        self::delete_lists_cache();
        // LiteSpeed finalizes its headers at shutdown priority 0. Queue the purge
        // now and finish our local invalidation just before that finalization.
        add_action('shutdown', array(__CLASS__, 'flush_catalogue_cache'), -1);
        do_action('litespeed_purge', 'slyme_catalogue');
        do_action('litespeed_purge_url', home_url('/'));
        $catalogue_url = self::search_home();
        if ($catalogue_url !== home_url('/')) do_action('litespeed_purge_url', $catalogue_url);
    }

    public static function flush_catalogue_cache() {
        if (!self::$lists_invalidated) return;
        // Save hooks can precede the final categories/variations. Clear once more
        // after all writes so a partially built list cannot survive this import.
        self::delete_lists_cache();
    }

    private static function save_section_cache() {
        if (!self::$section_dirty) return;
        if (!self::$lists_invalidated) set_transient('slyme_lists_v828', self::$section_cache, HOUR_IN_SECONDS);
        self::$section_dirty = false;
    }

    public static function merchandising_clauses($clauses, $query) {
        if ($query->get('post_type') !== 'product') return $clauses;
        $device = $query->get('slyme_device_type');
        if ($device) {
            global $wpdb;
            $classification = Slyme_Device_Classification::classification_sql();
            $categories = $query->get('slyme_device_categories');
            $category_sql = '0=1';
            if ($categories) {
                $tax = new WP_Tax_Query(array(array('taxonomy'=>'product_cat','field'=>'slug','terms'=>$categories,'include_children'=>true)));
                $parts = $tax->get_sql('slyme_device_product', 'ID');
                $category_sql = "EXISTS (SELECT 1 FROM {$wpdb->posts} AS slyme_device_product {$parts['join']} WHERE slyme_device_product.ID = {$wpdb->posts}.ID {$parts['where']})";
            }
            if ($device === 'autres') {
                // A wrong/missing category must not strand a recognized model in Other.
                $clauses['where'] .= " AND {$classification} = '' AND NOT ({$category_sql})";
            } elseif ($device === 'ordinateurs') {
                $clauses['where'] .= " AND ({$classification} IN ('ordinateurs-portables','ordinateurs-bureau') OR ({$classification} = '' AND {$category_sql}))";
            } else {
                $recognized = Slyme_Device_Classification::recognized_sql($device);
                // Existing categories remain the fallback for unrecognized names only.
                $clauses['where'] .= " AND ({$recognized} OR ({$classification} = '' AND {$category_sql}))";
            }
        }
        // The bounded recent-ID pool also uses classification, without price sorting.
        if (!$query->get('slyme_price_order')) return $clauses;
        global $wpdb;
        if (strpos($clauses['join'], ' AS slyme_product_lookup ') === false) {
            $clauses['join'] .= " LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup AS slyme_product_lookup ON {$wpdb->posts}.ID = slyme_product_lookup.product_id ";
        }
        // For variable products use their displayed starting price; unknown prices last.
        $direction = $query->get('slyme_price_order') === 'asc' ? 'ASC' : 'DESC';
        $clauses['orderby'] = "CASE WHEN slyme_product_lookup.min_price IS NULL THEN 1 ELSE 0 END ASC, slyme_product_lookup.min_price {$direction}, {$wpdb->posts}.post_date DESC, {$wpdb->posts}.ID DESC";
        return $clauses;
    }

    private static function section_query_args($section) {
        $args = self::query_args();
        // Premium-first selection shared by home rows and their paginated collections.
        $args['orderby'] = array('date'=>'DESC', 'ID'=>'DESC');
        $args['order'] = 'DESC';
        $args['slyme_price_order'] = true;
        $categories = $section['categories'] ?? array();
        if ($section['key'] === 'nouveautes') {
            // Actual latest publications across all families, not a price ranking.
            unset($args['slyme_price_order']);
            $recent = $args;
            $recent['posts_per_page'] = 60;
            $recent['fields'] = 'ids';
            $recent['no_found_rows'] = true;
            $recent['update_post_meta_cache'] = false;
            $recent['update_post_term_cache'] = false;
            $recent_ids = (new WP_Query($recent))->posts;
            $args['post__in'] = $recent_ids ? array_map('absint', $recent_ids) : array(0);
        } elseif ($section['key'] === 'en-avant') {
            $phones = array();
            foreach (self::config()['sections'] as $entry) {
                if ($entry['key'] === 'smartphones') { $phones = $entry['categories'] ?? array(); break; }
            }
            $args['slyme_device_type'] = 'smartphones';
            $args['slyme_device_categories'] = $phones;
            $args['tax_query'][] = array('taxonomy'=>'product_visibility', 'field'=>'slug', 'terms'=>array('outofstock'), 'operator'=>'NOT IN');
        } elseif ($section['key'] === 'offres') {
            // WooCommerce supplies active sales, including parents of variations.
            $sale_ids = function_exists('wc_get_product_ids_on_sale') ? wc_get_product_ids_on_sale() : array();
            $args['post__in'] = $sale_ids ? array_map('absint', $sale_ids) : array(0);
        } elseif ($section['key'] === 'ordinateurs' || isset(Slyme_Device_Classification::patterns()[$section['key']])) {
            $args['slyme_device_type'] = $section['key'];
            $args['slyme_device_categories'] = $categories;
        } elseif ($categories) {
            $args['tax_query'][] = array('taxonomy'=>'product_cat', 'field'=>'slug', 'terms'=>$categories, 'include_children'=>true);
        } elseif ($section['key'] === 'autres') {
            $args['slyme_device_type'] = 'autres';
            $known = array();
            foreach (self::config()['sections'] as $entry) $known = array_merge($known, $entry['categories'] ?? array());
            $args['slyme_device_categories'] = array_values(array_unique($known));
        }
        return $args;
    }

    private static function section_limit($section) {
        if ($section['key'] === 'en-avant') return 5;
        return in_array($section['key'], array('nouveautes','smartphones'), true) ? 12 : 6;
    }

    private static function ordered_section_ids($args, $section) {
        // Two bounded ID-only reads: the requested order, then other premium phones.
        $limit = (int) $args['posts_per_page'];
        $reserved = array_map('absint', $args['post__not_in'] ?? array());
        $priority = array_values(array_diff(array_filter(array_unique(array_map('absint', $section['priority_products'] ?? array()))), $reserved));
        $ids = array();
        if ($priority) {
            $pinned = $args;
            unset($pinned['slyme_price_order'], $pinned['post__not_in']);
            $pinned['post__in'] = $priority;
            $pinned['posts_per_page'] = min($limit, count($priority));
            $pinned['orderby'] = 'post__in';
            $ids = array_values(array_unique(array_map('absint', (new WP_Query($pinned))->posts)));
        }
        if (count($ids) < $limit) {
            $remaining = $args;
            $remaining['posts_per_page'] = $limit - count($ids);
            $remaining['post__not_in'] = array_values(array_unique(array_merge($reserved, $ids)));
            $ids = array_merge($ids, array_map('absint', (new WP_Query($remaining))->posts));
        }
        return array_slice(array_values(array_unique($ids)), 0, $limit);
    }

    private static function section_ids($section, $allow_query = true) {
        $hero = self::hero_product();
        $hero_id = $hero ? (int) $hero->get_id() : 0;
        if (null === self::$section_cache) {
            $hash = md5('classified-home-v82630|' . $hero_id . '|' . wp_json_encode(self::config()['sections']));
            $saved = self::$lists_invalidated ? false : get_transient('slyme_lists_v828');
            self::$section_cache = is_array($saved) && ($saved['hash'] ?? '') === $hash ? $saved : array('hash'=>$hash, 'sections'=>array());
        }
        $cache_key = $section['key'];
        if (isset(self::$section_cache['sections'][$cache_key])) return self::$section_cache['sections'][$cache_key];
        // No hidden queries while outputting the deferred rows.
        if (!$allow_query) return null;

        // A fixed allocation order makes parallel REST requests agree. Reserve
        // the hero, then Smartphones, active offers, new products and other rows.
        $ordered = array();
        foreach (array('smartphones','offres','nouveautes','en-avant') as $priority) {
            foreach (self::config()['sections'] as $entry) {
                if ($entry['key'] === $priority && empty($entry['nav_only'])) $ordered[] = $entry;
            }
        }
        foreach (self::config()['sections'] as $entry) {
            if (!in_array($entry['key'], array('smartphones','nouveautes','offres','en-avant'), true) && empty($entry['nav_only'])) $ordered[] = $entry;
        }
        // Explicit picks belong to their own row before automatic filling begins.
        // Resolving ownership in memory avoids extra queries and cross-row duplicates.
        $priority_owners = array();
        foreach ($ordered as $entry) {
            foreach (array_filter(array_map('absint', $entry['priority_products'] ?? array())) as $id) {
                if (!isset($priority_owners[$id])) $priority_owners[$id] = $entry['key'];
            }
        }
        $reserved = $hero_id ? array($hero_id) : array();
        foreach ($ordered as $entry) {
            $key = $entry['key'];
            if (!isset(self::$section_cache['sections'][$key])) {
                $args = self::section_query_args($entry);
                $excluded = $reserved;
                foreach ($priority_owners as $id => $owner) {
                    if ($owner !== $key) $excluded[] = $id;
                }
                $excluded = array_values(array_unique($excluded));
                // WordPress ignores post__not_in when post__in is nonempty.
                // News and active offers therefore need an explicit intersection.
                if (!empty($args['post__in'])) {
                    $included = array_values(array_diff(array_map('absint', $args['post__in']), $excluded));
                    $args['post__in'] = $included ? $included : array(0);
                } else {
                    $args['post__not_in'] = array_values(array_unique(array_merge($args['post__not_in'] ?? array(), $excluded)));
                }
                $args['fields'] = 'ids';
                $args['posts_per_page'] = self::section_limit($entry);
                $args['no_found_rows'] = true;
                $args['update_post_meta_cache'] = false;
                $args['update_post_term_cache'] = false;
                $ids = !empty($entry['priority_products']) ? self::ordered_section_ids($args, $entry) : array_values(array_unique(array_map('absint', (new WP_Query($args))->posts)));
                self::$section_cache['sections'][$key] = $ids;
                self::$section_dirty = true;
            }
            $ids = self::$section_cache['sections'][$key];
            if ($key === $cache_key) return $ids;
            $reserved = array_merge($reserved, $ids);
        }
        return array();
    }

    private static function view_url($base, $collection = '', $search = '', $page = 1) {
        $args = array();
        if ($collection) $args['slyme_collection'] = $collection;
        if ($search) $args['slyme_search'] = $search;
        if ($page > 1) $args['slyme_page'] = $page;
        return $args ? add_query_arg($args, $base) : $base;
    }

    private static function category_nav($base) {
        $items = array('smartphones' => 'Smartphones', 'montres' => 'Montres', 'tablettes' => 'Tablettes', 'ordinateurs' => 'Ordinateurs');
        $icons = array(
            'smartphones' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="27" y="10" width="42" height="76" rx="9"/><path d="M41 16h14M44 80h8"/><path class="slyme-category-accent" d="M35 63l25-31M35 48l15-17"/></svg>'
,            'montres' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M37 25l3-17h16l3 17M37 71l3 17h16l3-17"/><rect x="26" y="25" width="44" height="46" rx="13"/><path d="M70 40h4v10h-4"/><path class="slyme-category-accent" d="M48 35v14l9 5"/><circle cx="48" cy="49" r="17"/></svg>'
,            'tablettes' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="17" y="10" width="62" height="76" rx="7"/><path d="M23 20h50v55H23zM44 80h8"/><path class="slyme-category-accent" d="M31 62l33-29M31 47l18-16"/></svg>'
,            'ordinateurs' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="13" y="20" width="70" height="49" rx="5"/><path d="M13 69L5 80h86l-8-11M40 74h16"/><path class="slyme-category-accent" d="M31 53l30-18M31 40l13-8"/></svg>'
        );
        // Term lists use WordPress's own cache; no per-category product queries.
        $terms = get_terms(array('taxonomy'=>'product_cat','hide_empty'=>true));
        if (is_wp_error($terms)) $terms = array();
        $by_slug = array(); $by_id = array();
        foreach ($terms as $term) { $by_slug[$term->slug] = $term; $by_id[(int)$term->term_id] = $term; }
        $covered = array(); $links = array();
        foreach (self::config()['sections'] as $entry) {
            if (in_array($entry['key'], array('nouveautes','en-avant','offres','autres'), true)) continue;
            $present = false;
            foreach ($entry['categories'] ?? array() as $slug) {
                if (!isset($by_slug[$slug])) continue;
                $present = true; $term = $by_slug[$slug];
                // Parent brand categories may contain other families as well.
                // Keep their own card unless that exact term is represented.
                $covered[(int)$term->term_id] = true;
            }
            if (!$present || in_array($entry['key'], array('ordinateurs-portables','ordinateurs-bureau'), true)) continue;
            $label = preg_replace('/^[^\p{L}\p{N}]+/u', '', $entry['title']);
            if (!isset($items[$entry['key']])) $items[$entry['key']] = $label;
        }
        // Include populated top-level categories that the configured cards miss.
        // Their native term URL works immediately, without creating taxonomy terms.
        foreach ($terms as $term) {
            if ((int)$term->parent || isset($covered[(int)$term->term_id]) || $term->slug === 'uncategorized' || $term->slug === 'non-classe') continue;
            $url = get_term_link($term);
            if (is_wp_error($url)) continue;
            $key = 'term-' . (int)$term->term_id;
            $items[$key] = $term->name; $links[$key] = $url;
        }
        $drawings = array(
            'televisions'=>'<rect x="9" y="16" width="78" height="53" rx="4"/><path d="M35 82h26M48 69v13M23 27h49"/>',
            'ecrans'=>'<rect x="9" y="16" width="78" height="53" rx="4"/><path d="M35 82h26M48 69v13"/>',
            'audio'=>'<path d="M20 53v-8a28 28 0 0 1 56 0v8"/><rect x="13" y="45" width="17" height="31" rx="7"/><rect x="66" y="45" width="17" height="31" rx="7"/>',
            'cameras'=>'<path d="M10 30h20l7-10h22l7 10h20v48H10z"/><circle cx="48" cy="53" r="17"/><circle cx="76" cy="39" r="2"/>',
            'reseau'=>'<rect x="14" y="52" width="68" height="25" rx="5"/><path d="M26 52V32M70 52V32M36 66h2M46 66h2M36 27a17 17 0 0 1 24 0M29 19a27 27 0 0 1 38 0"/>',
            'stockage'=>'<rect x="18" y="13" width="60" height="70" rx="7"/><circle cx="48" cy="43" r="16"/><path d="M48 43l17 22M29 73h8"/>',
            'bureautique'=>'<path d="M28 33V12h40v21M28 64H14V33h68v31H68M28 53h40v31H28zM36 64h24M36 73h18"/>',
            'cartouches-encres'=>'<path d="M30 14h36v17l8 12v40H22V43l8-12zM31 55h34M37 22h22"/>',
            'onduleurs'=>'<rect x="25" y="10" width="46" height="76" rx="5"/><path d="M52 22l-13 22h17L43 66M36 77h24"/>',
            'accessoires'=>'<path d="M35 11v19h26V11M30 30h36v20H30zM48 50v11c0 24 31 24 31 4V48"/>',
            'maison'=>'<path d="M11 44l37-30 37 30M22 39v45h52V39M40 84V59h16v25"/>',
            'objets-connectes'=>'<circle cx="48" cy="52" r="25"/><circle cx="48" cy="52" r="7"/><path d="M37 16a27 27 0 0 1 22 0M42 24a17 17 0 0 1 12 0"/>'
        );
        $fallback = '<rect x="13" y="13" width="28" height="28" rx="5"/><rect x="55" y="13" width="28" height="28" rx="5"/><rect x="13" y="55" width="28" height="28" rx="5"/><rect x="55" y="55" width="28" height="28" rx="5"/>';
        $out = '<nav class="slyme-category-nav" aria-label="Explorer les catégories"><div class="slyme-category-track" tabindex="0" aria-label="Catégories de produits" aria-keyshortcuts="ArrowLeft ArrowRight Home End">';
        foreach ($items as $key => $label) {
            $icon = $icons[$key] ?? ('<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' . ($drawings[$key] ?? $fallback) . '</svg>');
            $out .= '<a class="slyme-category-card" data-slyme-category="' . esc_attr($key) . '" href="' . esc_url($links[$key] ?? self::view_url($base, $key)) . '">' . $icon . '<span class="slyme-category-label">' . esc_html($label) . '</span></a>';
        }
        return $out . '</div></nav>';
    }

    public static function search_form($base, $query) {
        $uid = wp_unique_id('slyme-search-');
        $query_args = array();
        wp_parse_str((string) wp_parse_url($base, PHP_URL_QUERY), $query_args);
        $hidden = '';
        foreach (array('page_id', 'p', 'lang') as $key) if (isset($query_args[$key]) && is_scalar($query_args[$key])) $hidden .= '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($query_args[$key]) . '">';
        return '<form class="slyme-search" role="search" action="' . esc_url($base) . '" method="get">' . $hidden . '<label class="slyme-sr-only" for="' . $uid . '">Rechercher un produit</label><div class="slyme-search-field"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 4 4"></path></svg><input id="' . $uid . '" type="search" name="slyme_search" value="' . esc_attr($query) . '" placeholder="Rechercher un produit…" maxlength="80" autocomplete="off" enterkeyhint="search" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="' . $uid . '-results"><button type="submit" aria-label="Lancer la recherche"><span class="slyme-search-submit-label">Rechercher</span><svg class="slyme-search-submit-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></button></div><ul id="' . $uid . '-results" class="slyme-search-results" role="listbox" aria-label="Produits suggérés" hidden></ul><p class="slyme-search-status" aria-live="polite"></p></form>';
    }

    public static function search_home() {
        $front = (int) get_option('page_on_front');
        if ($front && has_shortcode((string) get_post_field('post_content', $front), 'slyme_catalogue')) return get_permalink($front);
        $id = get_transient('slyme_search_page');
        if (false === $id) {
            global $wpdb;
            $id = (int) $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_status='publish' AND post_type='page' AND post_content LIKE %s ORDER BY ID ASC LIMIT 1", '%' . $wpdb->esc_like('[slyme_catalogue') . '%'));
            set_transient('slyme_search_page', $id, HOUR_IN_SECONDS);
        }
        return $id ? get_permalink($id) : home_url('/');
    }
    public static function header_search_icon() {
        return '<a class="sls-header-search-link" data-slyme-search-open href="' . esc_url(add_query_arg(array('s'=>'','post_type'=>'product'), home_url('/'))) . '" aria-label="Rechercher un produit" aria-haspopup="dialog"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg></a>';
    }
    public static function header_search_form() {
        if (!function_exists('WC')) return;
        echo '<div id="slyme-header-search-source" hidden>' . self::search_form(self::search_home(), '') . '</div>';
    }

    public static function catalogue() {
        if (!function_exists('wc_get_product')) return '<p>Le catalogue est momentanément indisponible.</p>';
        self::enqueue();
        do_action('litespeed_tag_add', 'slyme_catalogue');
        global $wpdb; $started = microtime(true); $queries_before = $wpdb->num_queries;
        $base = get_permalink(get_queried_object_id());
        if (!$base) $base = home_url('/');
        $key = isset($_GET['slyme_collection']) ? sanitize_key(wp_unslash($_GET['slyme_collection'])) : '';
        $search = isset($_GET['slyme_search']) ? sanitize_text_field(wp_unslash($_GET['slyme_search'])) : '';
        $search = function_exists('mb_substr') ? mb_substr($search, 0, 80) : substr($search, 0, 80);
        $page = isset($_GET['slyme_page']) ? max(1, absint($_GET['slyme_page'])) : 1;
        $sections = self::config()['sections'];
        $selected = null;
        foreach ($sections as $section) if ($section['key'] === $key) $selected = $section;
        $hero = (!$selected && !$search) ? self::hero() : '';
        $out = '<div class="slyme-products-grid' . ($hero ? ' slyme-has-hero' : '') . '" id="slyme-catalogue" data-slyme-light="8" data-slyme-rendered="' . time() . '" data-slyme-api="' . esc_url(rest_url('slyme/v1/')) . '" data-slyme-home="' . esc_url($base) . '">';
        // Search is now opened exclusively from the header icon.
        if ($selected || $search) {
            $args = self::query_args();
            $args['posts_per_page'] = 24;
            $args['paged'] = $page;
            if ($search) {
                $matches = self::search_ids($search);
                $args['post__in'] = $matches ? $matches : array(0);
                $args['orderby'] = 'post__in';
                $title = 'Résultats pour « ' . $search . ' »';
            } else {
                // Query this page directly: never load the whole category just to
                // paginate it, and never restrict Voir tout to the six preview IDs.
                $args = self::section_query_args($selected);
                $args['posts_per_page'] = 24;
                $args['paged'] = $page;
                $title = $selected['title'];
            }
            $query = new WP_Query($args);
            self::prime_card_caches(array_map(static function($post) { return (int) $post->ID; }, $query->posts));
            $out .= '<a class="slyme-return" data-slyme-return href="' . esc_url(self::view_url($base)) . '">← Retour au catalogue</a><div class="slyme-collection-header"><h2>' . esc_html($title) . '</h2><p>' . absint($query->found_posts) . ' produit' . (1 === (int) $query->found_posts ? '' : 's') . '</p></div><div class="slyme-collection-grid">';
            foreach ($query->posts as $index => $post) $out .= self::card(wc_get_product($post->ID), 0 === $index);
            $out .= '</div>';
            if (!$query->found_posts) $out .= '<p class="slyme-empty">Aucun produit trouvé. Essaie un autre nom ou une autre marque.</p>';
            if ($query->max_num_pages > 1) {
                $out .= '<nav class="slyme-pagination" aria-label="Pages de produits">';
                if ($page > 1) $out .= '<a href="' . esc_url(self::view_url($base, $key, $search, $page - 1)) . '">← Précédent</a>';
                $out .= '<span aria-current="page">Page ' . absint($page) . ' sur ' . absint($query->max_num_pages) . '</span>';
                if ($page < $query->max_num_pages) $out .= '<a href="' . esc_url(self::view_url($base, $key, $search, $page + 1)) . '">Suivant →</a>';
                $out .= '</nav>';
            }
        } else {
            $out .= '<noscript><p>Ouvre une collection avec « Voir tout » pour consulter tous ses produits.</p><style>#slyme-catalogue .slyme-card-placeholder{display:none}</style></noscript>' . $hero . self::category_nav($base) . '<div class="slyme-boutique">';
            // Une seule préparation de métadonnées pour les aperçus, au lieu d’une par rangée.
            $preview_ids=array();$preview_count=0;$preview_attempts=0;
            foreach($sections as $preview_section){
                if(!empty($preview_section['nav_only']))continue;
                // Bound cold-page selection work even when the first rows are empty.
                if(++$preview_attempts>4)break;
                $section_preview=self::section_ids($preview_section);
                if(!$section_preview)continue;
                $preview_ids=array_merge($preview_ids,array_slice($section_preview,0,6));
                if(++$preview_count===2)break;
            }
            // Prepare the leading three cards of at most two more known rows.
            // Reuse already-selected IDs; never add selection queries for distant rows.
            $seeded_rows=$preview_count;
            foreach($sections as $seed_section){
                if($seeded_rows>=4)break;
                if(!empty($seed_section['nav_only']))continue;
                $seed_ids=self::section_ids($seed_section,false);
                if(!$seed_ids || in_array($seed_ids[0],$preview_ids,true))continue;
                $preview_ids=array_merge($preview_ids,array_slice($seed_ids,0,3));
                $seeded_rows++;
            }
            $preview_ids=array_values(array_unique($preview_ids));
            self::prime_card_caches($preview_ids);
            $rendered_sections = 0;
            foreach ($sections as $index => $section) {
                if (!empty($section['nav_only'])) continue;
                $ids = self::section_ids($section, false);
                if ($ids === array() && $section['key'] !== 'offres') continue;
                $limit = self::section_limit($section);
                $available = null === $ids ? $limit : min($limit,count($ids));
                $title = $section['title'];
                $track = 'slyme-carousel-' . $section['key'];
                $heading = explode(' ', $title, 2);
                $title_html = count($heading) === 2 ? '<span aria-hidden="true">' . esc_html($heading[0]) . '</span> ' . esc_html($heading[1]) : esc_html($title);
                $out .= '<section class="slyme-carousel-section' . ($section['key'] === 'offres' ? ' slyme-offers-section' : '') . '"><header class="slyme-carousel-header"><h3 class="slyme-cat-title">' . $title_html . '</h3><div class="slyme-header-actions"><a class="slyme-see-all" href="' . esc_url(self::view_url($base, $section['key'])) . '" aria-label="Voir tous les produits — ' . esc_attr($title) . '">Voir tout <span aria-hidden="true">→</span></a><div class="slyme-carousel-controls" hidden role="group" aria-label="Défiler dans ' . esc_attr($title) . '">';
                foreach (array(true, false) as $previous) {
                    $out .= '<button class="slyme-carousel-arrow" type="button" aria-controls="' . $track . '" aria-label="' . ($previous ? 'Produits précédents' : 'Produits suivants') . '" data-slyme-' . ($previous ? 'prev' : 'next') . '><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' . ($previous ? 'm14 6-6 6 6 6' : 'm10 6 6 6-6 6') . '"></path></svg></button>';
                }
                $out .= '</div></div></header><div class="slyme-product-grid" id="' . $track . '" tabindex="0" role="group" aria-label="' . esc_attr($title) . ' — carrousel de produits" aria-keyshortcuts="ArrowLeft ArrowRight Home End">';
                $initial = null !== $ids && $rendered_sections < 4 ? min($rendered_sections < 2 ? 6 : 3,$available) : 0;
                if ($initial) $rendered_sections++;
                $visible_ids = $initial ? array_slice($ids, 0, $initial) : array();
                if ($visible_ids) _prime_post_caches($visible_ids, true, true);
                // Sous la bannière : laisser la priorité réseau au visuel principal.
                foreach ($visible_ids as $id) $out .= self::card(wc_get_product($id));
                if (!$available && $section['key'] === 'offres') $out .= '<p class="slyme-offers-empty">Aucune offre active pour le moment.</p>';
                if ($available > $initial) {
                    $out .= '<template class="slyme-section-loader" data-slyme-section="' . esc_attr($section['key']) . '" data-slyme-offset="' . $initial . '"></template>';
                    for ($slot=$initial; $slot<$available; $slot++) $out .= '<div class="slyme-product-card slyme-card-placeholder" aria-hidden="true"><div class="slyme-product-media"></div></div>';
                }
                $out .= '</div></section>';
            }
            $out .= '</div>';
        }
        self::save_section_cache();
        if (current_user_can('manage_options') && isset($_GET['slyme_diagnostic'])) $out .= '<span hidden id="slyme-server-metrics" data-ms="' . round((microtime(true)-$started)*1000,1) . '" data-queries="' . ($wpdb->num_queries-$queries_before) . '"></span>';
        return $out . '</div>';
    }

    public static function routes() {
        register_rest_route('slyme/v1', '/section', array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'rest_section')));
        register_rest_route('slyme/v1', '/search', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_search'), 'args' => array('search' => array('sanitize_callback' => 'sanitize_text_field', 'default' => ''))));
        register_rest_route('slyme/v1', '/products', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_products')));
    }

    private static function response($products) {
        $response = new WP_REST_Response($products, 200);
        $response->header('Cache-Control', 'no-store, private');
        return $response;
    }

    public static function rest_search($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable', 'Catalogue indisponible.', array('status' => 503));
        $term = trim((string) $request->get_param('search'));
        $length = function_exists('mb_strlen') ? mb_strlen($term) : strlen($term);
        if ($length < 2 || $length > 80) return self::response(array());
        $ids = array_slice(self::search_ids($term),0,8);
        self::prime_card_caches($ids);
        $products = array();
        foreach ($ids as $id) {
            $data = self::product_data(wc_get_product($id), false, false);
            if ($data) $products[] = $data;
        }
        return self::response($products);
    }

    public static function rest_products($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable', 'Catalogue indisponible.', array('status' => 503));
        $include = $request->get_param('include');
        if (!is_string($include) || !preg_match('/^\d+(,\d+){0,59}$/', $include)) return new WP_Error('slyme_ids', 'Liste de produits invalide.', array('status' => 400));
        $products = array();
        $ids = wp_parse_id_list($include);
        self::prime_card_caches($ids);
        foreach ($ids as $id) {
            $data = self::product_data(wc_get_product($id), (string) $id === (string) $request->get_param('hero'));
            if ($data) $products[] = $data;
        }
        return self::response($products);
    }

    private static function whatsapp_icon() {
        return '<svg class="slyme-wa-logo" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.5 3.5A11.9 11.9 0 0 0 12 0C5.4 0 0 5.4 0 12c0 2.1.6 4.2 1.6 6L0 24l6.2-1.6A12 12 0 0 0 12 24c6.6 0 12-5.4 12-12 0-3.2-1.2-6.2-3.5-8.5ZM12 22a10 10 0 0 1-5.1-1.4l-.4-.2-3.7 1 1-3.6-.3-.4A10 10 0 1 1 12 22Z"/><path fill="currentColor" d="M17.4 14.1c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.2-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6.3-.5c.1-.2.1-.4 0-.6-.1-.2-.7-1.7-1-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.7 1.2 2.9c.2.2 2 3 4.9 4.2.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.5-.1 1.8-.7 2.1-1.4.3-.7.3-1.3.2-1.4-.1-.2-.2-.2-.5-.4Z"/></svg>';
    }
    public static function whatsapp() {
        global $product;
        if (!self::public_product($product)) return;
        $phone = preg_replace('/\D/', '', get_option('slyme_whatsapp_number', '2250703283286'));
        if (!preg_match('/^[1-9]\d{9,14}$/', $phone)) return;
        $name = html_entity_decode(wp_strip_all_tags($product->get_name()), ENT_QUOTES, 'UTF-8');
        $url = get_permalink($product->get_id());
        $text = "Bonjour Slyme Abidjan, je souhaite passer commande de : " . $name . "\nQuantité : 1\n" . $url . "\nMerci de confirmer ma commande.";
        $uid = wp_unique_id('slyme-wa-');
        $currency = get_woocommerce_currency();
        $symbol = in_array($currency, array('XOF', 'XAF'), true) ? 'FCFA' : html_entity_decode(get_woocommerce_currency_symbol($currency), ENT_QUOTES, 'UTF-8');
        $unit = $product->is_type('simple') && '' !== $product->get_price() ? wc_get_price_to_display($product) : '';
        $image = wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail');
        $qtymax = $product->get_max_purchase_quantity();
        $qtymax = $qtymax > 0 ? ' max="' . esc_attr($qtymax) . '"' : '';
        $logo = self::whatsapp_icon();
        $in_stock = $product->is_in_stock();
        $variable = $product->is_type('variable');
        $ready = $in_stock && !$variable && $product->is_purchasable();
        $state = $ready ? '' : ' aria-disabled="true" tabindex="-1"';
        $destination = ' href="#' . esc_attr($uid) . 'title"';
        $label = !$in_stock ? 'Rupture de stock' : ($variable ? 'Choisissez vos options' : ($ready ? 'Commander sur WhatsApp' : 'Produit indisponible'));
        echo '<div class="slyme-whatsapp"><a class="slyme-whatsapp-link" data-in-stock="' . ($in_stock ? '1' : '0') . '" data-purchasable="' . ($product->is_purchasable() ? '1' : '0') . '" data-variable="' . ($variable ? '1' : '0') . '"' . $state . ' data-phone="' . esc_attr($phone) . '" data-product-id="' . absint($product->get_id()) . '" data-order-endpoint="' . esc_url(WC_AJAX::get_endpoint('slyme_direct_order')) . '" data-order-session="' . esc_url(WC_AJAX::get_endpoint('slyme_direct_session')) . '" data-product-name="' . esc_attr($name) . '" data-product-url="' . esc_url($url) . '" data-unit-price="' . esc_attr($unit) . '" data-currency="' . esc_attr($symbol) . '" data-decimals="' . absint(wc_get_price_decimals()) . '"' . $destination . ' role="button" aria-haspopup="dialog">' . $logo . '<span data-wa-link-label>' . esc_html($label) . '</span><span class="slyme-wa-link-arrow" aria-hidden="true">↗</span></a><p class="slyme-wa-link-note" aria-live="polite">' . esc_html($ready ? 'Commandez ici, notre service client vous recontacte.' : (!$in_stock ? 'Ce produit est actuellement indisponible.' : 'Sélectionnez une option disponible pour commander.')) . '</p>
<dialog class="slyme-whatsapp-dialog" aria-labelledby="' . esc_attr($uid) . 'title"><form class="slyme-whatsapp-form" method="post" data-wa-delivery-times="' . esc_attr(wp_json_encode(Slyme_Product_Shopping::delivery_info($product))) . '">
<header class="slyme-wa-header"><span class="slyme-wa-brand">' . $logo . '</span><div><p class="slyme-wa-eyebrow">Commande directe</p><h2 id="' . esc_attr($uid) . 'title">Votre commande.</h2></div><button class="slyme-wa-close" type="button" aria-label="Fermer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg></button></header>
<div class="slyme-wa-body"><p class="slyme-wa-intro">Quelques détails, et on s’occupe de vous.</p><section class="slyme-wa-product" aria-label="Récapitulatif du produit">';
        if ($image) echo '<img class="slyme-wa-photo" src="' . esc_url($image) . '" width="72" height="72" loading="lazy" decoding="async" alt="">';
        echo '<div class="slyme-wa-product-info"><strong>' . esc_html($name) . '</strong><p data-wa-options></p><p class="slyme-wa-unit" data-wa-unit hidden></p></div></section>
<div class="slyme-wa-order-row"><div><label for="' . esc_attr($uid) . 'quantity">Quantité</label><div class="slyme-wa-quantity"><button type="button" data-wa-quantity-step="-1" aria-label="Diminuer la quantité">−</button><input id="' . esc_attr($uid) . 'quantity" name="customer_quantity" type="number" inputmode="numeric" min="1" step="1"' . $qtymax . ' value="1" required aria-label="Quantité"><button type="button" data-wa-quantity-step="1" aria-label="Augmenter la quantité">+</button></div></div><div class="slyme-wa-total" hidden><span>Montant des produits</span><strong data-wa-total></strong></div></div>
<h3 class="slyme-wa-section-title">Livraison</h3>
<label>Mode de livraison<select name="customer_delivery" required><option value="abidjan">Abidjan — 2 000 F</option><option value="express">Express Abidjan — 3 000 F</option><option value="expedition">Expédition possible — frais à confirmer</option></select></label>
<p class="slyme-wa-delivery-note" data-wa-delivery-note>Livraison : 2 000 F</p>
<p class="slyme-wa-delivery-note" data-wa-delivery-time hidden></p>
<p class="slyme-wa-grand-total">Total <strong data-wa-grand-total></strong></p>
<h3 class="slyme-wa-section-title">Vos coordonnées</h3>
<div class="slyme-wa-names"><label>Nom<input name="customer_lastname" autocomplete="family-name" maxlength="80" required placeholder="Votre nom"></label><label>Prénom<input name="customer_firstname" autocomplete="given-name" maxlength="80" required placeholder="Votre prénom"></label></div>
<label>Numéro de téléphone<input name="customer_phone" type="tel" autocomplete="tel" inputmode="tel" maxlength="24" required placeholder="Ex. +225 07 00 00 00 00"></label>
<label>Adresse de livraison<textarea name="customer_address" autocomplete="street-address" rows="2" maxlength="500" required placeholder="Commune, quartier et repère…"></textarea></label>
<label>Précisions pour la livraison <span class="slyme-wa-optional">(facultatif)</span><textarea name="customer_note" rows="2" maxlength="500" placeholder="Une indication utile pour le livreur…"></textarea></label>
</div>
<footer class="slyme-wa-footer"><p>Votre commande est enregistrée sur le site. Aucun paiement n’est prélevé ici.</p><p data-wa-error role="alert" hidden></p><button class="slyme-wa-submit" type="submit">' . $logo . '<span>Commander</span><span aria-hidden="true">↗</span></button></footer>
</form><section class="slyme-wa-success" hidden tabindex="-1" aria-labelledby="' . esc_attr($uid) . 'success"><span class="slyme-wa-success-check" aria-hidden="true">✓</span><p class="slyme-wa-eyebrow">Merci pour votre confiance</p><h2 id="' . esc_attr($uid) . 'success">Votre commande a bien été reçue !</h2><p>Notre service client vous contactera pour confirmer les détails et organiser votre livraison.</p><strong data-wa-reference></strong><p data-wa-confirmed-total></p><button type="button" data-wa-success-close>Continuer mes achats</button></section></dialog></div>';
    }

    public static function admin_menu() {
        add_options_page('Slyme — Catalogue', 'Slyme Catalogue', 'manage_options', 'slyme-catalogue', array(__CLASS__, 'settings_page'));
    }
    public static function settings() {
        register_setting('slyme_catalogue', 'slyme_whatsapp_number', array('type' => 'string', 'sanitize_callback' => array(__CLASS__, 'sanitize_phone'), 'default' => '2250703283286'));
    }
    public static function sanitize_phone($value) {
        $number = preg_replace('/\D/', '', (string) $value);
        if ('' === $number || preg_match('/^[1-9]\d{9,14}$/', $number)) return $number;
        add_settings_error('slyme_whatsapp_number', 'invalid_phone', 'Saisis le numéro complet avec son indicatif, par exemple 2250703283286.');
        return get_option('slyme_whatsapp_number', '2250703283286');
    }
    public static function settings_page() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>Slyme — Catalogue fluide</h1><p>Sur la page du catalogue, remplace l’ancien bloc par un bloc Code court contenant <code>[slyme_catalogue]</code>.</p><form action="options.php" method="post">';
        settings_fields('slyme_catalogue');
        echo '<table class="form-table"><tr><th scope="row"><label for="slyme-whatsapp-number">Numéro WhatsApp</label></th><td><input id="slyme-whatsapp-number" class="regular-text" type="tel" name="slyme_whatsapp_number" value="' . esc_attr(get_option('slyme_whatsapp_number', '2250703283286')) . '"><p class="description">Indicatif et numéro complet. Le numéro prérempli est celui du service client publié sur slymeabidjan.ci. Utilise ici ton numéro WhatsApp ; laisse vide pour masquer le bouton.</p></td></tr></table>';
        echo '<p><input type="hidden" name="slyme_product_presentation" value="0"><label><input type="checkbox" name="slyme_product_presentation" value="1"' . checked(get_option('slyme_product_presentation', '1'), '1', false) . '> Activer les aides à l’achat sur les fiches produit</label></p><p>Personnalise les caractéristiques dans <strong>Produits → Fiches Slyme</strong>. Les caractéristiques gardent la mise en page du thème, sans icônes ni blocs décoratifs ajoutés.</p>';
        do_action('slyme_catalogue_settings_fields');
        submit_button();
        echo '</form>';
        do_action('slyme_catalogue_after_settings_form');
        echo '<h2>Diagnostic de fluidité</h2><p>Connecté comme administrateur, ouvre la page du catalogue avec <code>?slyme_diagnostic=1</code> dans son adresse (ou <code>&amp;slyme_diagnostic=1</code> si elle contient déjà un paramètre). Le panneau mesure cette visite uniquement, sans envoi de données. Les durées des fichiers indiquent leur chargement, pas leur coût JavaScript.</p><p><a class="button" href="' . esc_url(add_query_arg('slyme_diagnostic','1',home_url('/'))) . '">Tester la page d’accueil</a></p><p>Les prix, noms et liens proviennent de WooCommerce. Les nouveautés apparaissent en premier avec jusqu’à 12 produits ; les autres carrousels présentent jusqu’à 6 produits ; « Voir tout » donne accès à la collection complète, par pages de 24 produits. Les sélections « Nos offres du moment », « Tout juste sortis » et « Autres » reprennent tes sélections actuelles.</p></div>';
    }
    public static function dependency_notice() {
        if (!function_exists('wc_get_product') && current_user_can('activate_plugins')) echo '<div class="notice notice-warning"><p>Slyme Catalogue nécessite WooCommerce actif.</p></div>';
    }
}
require_once __DIR__ . '/includes/card-benefits.php';
Slyme_Catalogue_V6::boot();
require_once __DIR__ . '/includes/product-presentation.php';
Slyme_Product_Presentation::boot();

require_once __DIR__ . '/includes/product-shopping.php';
Slyme_Product_Shopping::boot();

require_once __DIR__ . '/includes/delivery-info.php';
Slyme_Delivery_Info::boot();

require_once __DIR__ . '/includes/variation-gallery.php';
Slyme_Variation_Gallery::boot();

require_once __DIR__ . '/includes/cart-sync.php';
Slyme_Cart_Sync::boot();

require_once __DIR__ . '/includes/direct-orders.php';
Slyme_Direct_Orders::boot();

require_once __DIR__ . '/includes/display-stability.php';
Slyme_Display_Stability::boot();

require_once __DIR__ . '/includes/image-loading.php';
Slyme_Image_Loading::boot();

require_once __DIR__ . "/includes/cache-health.php";
Slyme_Cache_Health::boot();
