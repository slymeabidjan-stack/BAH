/* Slyme : navigation, recherche et prix. Aucun gestionnaire de déplacement tactile. */
(() => {
  const onReady = callback => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', callback, {once:true}) : callback();
  const storage = {
    get(key) { try { return JSON.parse(sessionStorage.getItem(key)); } catch (_) { return null; } },
    set(key, value) { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch (_) {} },
    remove(key) { try { sessionStorage.removeItem(key); } catch (_) {} }
  };
  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  onReady(() => document.querySelectorAll('.slyme-products-grid[data-slyme-api]').forEach(root => {
    if (root.dataset.slymeAppReady) return;
    root.dataset.slymeAppReady = '813';
    const home = new URL(root.dataset.slymeHome, location.href);
    const api = new URL(root.dataset.slymeApi, location.href);
    const safeURL = (value, image = false) => {
      try {
        const url = new URL(value, home);
        return /^https?:$/.test(url.protocol) && (image || url.origin === home.origin) ? url.href : '';
      } catch (_) { return ''; }
    };
    const request = async (route, parameters, signal, priority = route === 'search' ? 'high' : 'low') => {
      const url = api.searchParams.has('rest_route') ? new URL(api) : new URL(route, api);
      if (url.searchParams.has('rest_route')) url.searchParams.set('rest_route', api.searchParams.get('rest_route').replace(/\/?$/, '/') + route);
      Object.entries(parameters).forEach(([key, value]) => url.searchParams.set(key, value));
      const response = await fetch(url, {signal, credentials:'same-origin', cache:'no-store', priority, headers:{Accept:'application/json'}});
      if (!response.ok) throw new Error('Catalogue indisponible');
      const result = await response.json();
      if (!Array.isArray(result)) throw new Error('Réponse invalide');
      return result;
    };
    const priceText = price => price && price.amount !== '' ? [price.label, price.amount, price.currency].filter(Boolean).join(' ') : 'Prix sur demande';

    // Une sauvegarde au départ de la page, sans écritures répétées pendant les gestes.
    const pageKey = location.pathname + location.search;
    let entry = history.state && typeof history.state === 'object' ? history.state.slymeEntry : '';
    if (!entry) {
      entry = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      try { history.replaceState({...((history.state && typeof history.state === 'object') ? history.state : {}), slymeEntry:entry}, '', location.href); } catch (_) {}
    }
    const snapshot = () => {
      const tracks = {};
      root.querySelectorAll('.slyme-product-grid[id]').forEach(track => { tracks[track.id] = track.scrollLeft; });
      const saved = {time:Date.now(), y:scrollY, tracks};
      storage.set('slyme:entry:' + entry, saved);
      storage.set('slyme:page:' + pageKey, saved);
    };
    const restore = event => {
      if (event && event.persisted) return; // Le cache de navigation du navigateur conserve déjà tout.
      const navigation = performance.getEntriesByType('navigation')[0];
      const explicitReturn = storage.get('slyme:return') === pageKey;
      if ((!navigation || navigation.type !== 'back_forward') && !explicitReturn) return;
      const saved = explicitReturn ? storage.get('slyme:page:' + pageKey) : storage.get('slyme:entry:' + entry);
      if (explicitReturn) storage.remove('slyme:return');
      if (!saved || Date.now() - saved.time > 86400000 || !Number.isFinite(saved.y)) return;
      Object.entries(saved.tracks || {}).forEach(([id, left]) => {
        const track = document.getElementById(id);
        if (track && root.contains(track) && Number.isFinite(left)) track.scrollLeft = left;
      });
      requestAnimationFrame(() => scrollTo({top:saved.y, behavior:'instant'}));
    };
    window.addEventListener('pagehide', snapshot);
    window.addEventListener('pageshow', restore);
    root.addEventListener('click', event => {
      const link = event.target.closest('a[href]');
      if (!link || event.defaultPrevented || event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      snapshot();
      if (link.hasAttribute('data-slyme-return')) storage.set('slyme:return', home.pathname + home.search);
    });

    // Prix actuels : rafraîchissement groupé des cartes proches de l'écran, même si la page HTML est en cache.
    const cards = new Map(), latestProducts = new Map(), pending = new Set(), inFlight = new Set(), completed = new Set();
    const productSelector = '.slyme-product-card[data-product-id],.slyme-hero[data-product-id]';
    let timer = 0, running = false;
    const rendered = Number(root.dataset.slymeRendered || 0) * 1000;
    const heroId = root.querySelector('.slyme-hero')?.dataset.productId || '';
    root.querySelectorAll(productSelector).forEach(card => {
      const id = Number(card.dataset.productId);
      if (!Number.isInteger(id) || id < 1) return;
      if (!cards.has(id)) cards.set(id, []);
      cards.get(id).push(card);
    });
    const drawPrice = (card, price) => {
      if (!price || typeof price.amount !== 'string') return;
      const holder = card.querySelector('.slyme-product-price');
      const content = document.createDocumentFragment();
      if (price.amount === '') content.append(create('span', 'slyme-price-request', 'Prix sur demande'));
      else {
        if (price.label) content.append(create('span', 'slyme-price-label', price.label + ' '));
        const amount = create('span', 'slyme-price-amount', price.amount + ' ');
        amount.append(create('span', 'slyme-price-currency', price.currency));
        content.append(amount);
        if (price.suffix) content.append(create('span', 'slyme-price-note', price.suffix));
      }
      if (holder.textContent.replace(/\s/g,'') !== content.textContent.replace(/\s/g,'')) holder.replaceChildren(content);
    };
    const updateCard = (card, product, receivedAt = 0) => {
      const url = safeURL(product.url), image = safeURL(product.image, true);
      if (!url || typeof product.name !== 'string') return;
      if (card.matches('.slyme-hero')) {
        if (!product.hero) { card.hidden = true; return; }
        card.dispatchEvent(new CustomEvent('slyme:product', {detail:product}));
        card.dataset.slymeFresh = 'true';
        if (receivedAt) card.dataset.slymeFreshAt = String(receivedAt);
        return;
      }
      card.href = url;
      const name = card.querySelector('.slyme-product-name');
      if (name.textContent !== product.name) name.textContent = product.name;

      const benefit = card.querySelector('.slyme-product-benefit');
      if (benefit && typeof product.benefit === 'string' && benefit.textContent !== product.benefit) {
        const parts = product.benefit.split(/(à partir de)/iu);
        benefit.replaceChildren(...parts.map(part => /^à partir de$/iu.test(part) ? create('strong', 'slyme-starting-label', part) : document.createTextNode(part)));
      }
      const brand = card.querySelector('.slyme-product-brand');
      if (brand.textContent !== (product.brand || '')) brand.textContent = product.brand || '';
      const photo = card.querySelector('img');
      if (photo) { if (typeof product.srcset === 'string' && photo.srcset !== product.srcset) photo.srcset = product.srcset; photo.alt = product.name; if (image && photo.src !== image) photo.src = image; }
      drawPrice(card, product.price);
      card.dataset.slymeFresh = 'true';
      if (receivedAt) card.dataset.slymeFreshAt = String(receivedAt);
    };
    const flush = async () => {
      timer = 0;
      if (running || !pending.size) return;
      running = true;
      const ids = [...pending].slice(0, 16);
      ids.forEach(id => { pending.delete(id); inFlight.add(id); });
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 9000);
      try {
        const products = await request('products', {include:ids.join(','), hero:ids.includes(Number(heroId)) ? heroId : ''}, controller.signal);
        const receivedAt = Date.now();
        const available = new Set();
        products.forEach(product => {
          const id = Number(product.id);
          if (!ids.includes(id)) return;
          available.add(id);latestProducts.set(id,product);
          (cards.get(id) || []).forEach(card => updateCard(card, product, receivedAt));
        });
        const changedTracks = new Set();
        ids.forEach(id => {
          completed.add(id);
          if (!available.has(id)) latestProducts.set(id,null);
          if (!available.has(id)) (cards.get(id) || []).forEach(card => {
            card.hidden = true;
            const track = card.closest('.slyme-product-grid');
            if (track) changedTracks.add(track);
          });
        });
        // Toutes les cartes sont mises à jour avant de recalculer chaque carrousel une fois.
        changedTracks.forEach(track => track.dispatchEvent(new Event('slyme:refresh')));
      } catch (_) {
        // Une panne de réseau laisse le catalogue rendu par WooCommerce consultable.
      } finally {
        ids.forEach(id => inFlight.delete(id));
        clearTimeout(timeout); running = false;
        if (pending.size) timer = setTimeout(flush, 120);
      }
    };
    const enqueue = element => {
      if (rendered && Date.now() - rendered < 60000) return;
      const list = element.matches(productSelector) ? [element] : element.querySelectorAll(productSelector);
      list.forEach(card => {
        if (Date.now() - Number(card.dataset.slymeFreshAt || 0) < 60000) return;
        // Une carte peut réapparaître pendant la réponse ou figurer dans plusieurs rangées.
        const id = Number(card.dataset.productId); if (!completed.has(id) && !inFlight.has(id)) pending.add(id);
      });
      if (!running && pending.size && !timer) timer = setTimeout(flush, 120);
    };
    const nearScreen = card => { const r = card.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight + 150 && r.right > 0 && r.left < innerWidth; };
    const revealImages = card => card.querySelectorAll('img').forEach(img => {
      if (img.loading === 'lazy') img.loading = 'eager';
      if (img.fetchPriority === 'low') img.fetchPriority = 'auto';
    });
    let priceObserver = null;
    if ('IntersectionObserver' in window) {
      const observer = priceObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) { revealImages(entry.target); enqueue(entry.target); }
      }), {rootMargin:'150px 0px'});
      root.querySelectorAll(productSelector).forEach(element => observer.observe(element));
    } else cards.forEach(list => list.filter(nearScreen).forEach(card => { revealImages(card); enqueue(card); }));
    const refreshVisible = () => cards.forEach(list => list.filter(nearScreen).forEach(enqueue));
    window.addEventListener('online', refreshVisible);
    window.addEventListener('pageshow', event => { if (event.persisted) { completed.clear(); refreshVisible(); } });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { completed.clear(); refreshVisible(); } });

    // Deux collections au maximum en vol ; les autres ne sont préparées qu’à l’approche.
    const sectionQueue = [], sectionState = new WeakMap(), sectionRequests = new Map();
    let loadingSections = 0, sectionFrame = 0, watchingQueue = false, sectionObserver = null, visibleSectionsObserver = null;
    const sectionMargin = navigator.connection?.saveData ? 300 : 900;
    const installSection = (loader, content, fresh = false) => {
      if (!loader.isConnected) return;
      const track = loader.parentElement;
      sectionObserver?.unobserve(track); visibleSectionsObserver?.unobserve(track);
      // A cached page can predate a price/stock change. Keep one card per ID
      // even when its deferred response comes from a newer catalogue selection.
      const seen = new Set([...root.querySelectorAll(productSelector)].filter(card => !card.hidden).map(card => Number(card.dataset.productId)));
      const newCards = [...content.querySelectorAll(productSelector)].filter(card => {
        const id = Number(card.dataset.productId);
        if (seen.has(id)) { card.remove(); return false; }
        seen.add(id); return true;
      });
      // Les images éloignées ne prennent pas la priorité lors de l’insertion du HTML.
      newCards.forEach(card => card.querySelectorAll('img').forEach(img => { img.loading = 'lazy'; img.fetchPriority = 'low'; }));
      track.querySelectorAll('.slyme-card-placeholder,.slyme-section-status').forEach(node => node.remove());
      track.append(content); loader.remove();
      newCards.forEach(card => {
        const id = Number(card.dataset.productId);
        if (!cards.has(id)) cards.set(id, []);
        cards.get(id).push(card);
        if (fresh) card.dataset.slymeFreshAt = String(Date.now());
        else if (latestProducts.has(id)) {
          const product = latestProducts.get(id);
          if (product) updateCard(card, product); else card.hidden = true;
        }
        if (priceObserver) priceObserver.observe(card);
      });
      // Lire les positions ensemble, puis promouvoir seulement les images qui approchent.
      newCards.filter(nearScreen).forEach(revealImages);
      if (!track.querySelector('.slyme-product-card[data-product-id]:not([hidden])')) (track.closest('.slyme-carousel-section') || track).hidden = true;
      track.removeAttribute('aria-busy');
      track.dispatchEvent(new Event('slyme:refresh'));
    };
    const loadSection = async (loader, visible = false) => {
      if (!loader.isConnected) return;
      const track = loader.parentElement;
      sectionState.set(loader, 'loading');
      track.setAttribute('aria-busy', 'true');
      track.querySelectorAll('.slyme-section-status').forEach(node => node.remove());
      const controller = new AbortController();
      const job = {controller, cancelled:false};
      sectionRequests.set(loader, job);
      const timeout = setTimeout(() => controller.abort(), 12000);
      try {
        const key = loader.dataset.slymeSection;
        const result = await request('section', {section:key, offset:loader.dataset.slymeOffset || '0'}, controller.signal, visible ? 'auto' : 'low');
        if (job.cancelled) throw new Error('Chargement reporté');
        const section = result.find(item => item && item.key === key && typeof item.html === 'string');
        if (!section) throw new Error('Collection indisponible');
        const template = document.createElement('template');
        // HTML généré et échappé par notre endpoint WordPress, jamais par le champ de recherche.
        template.innerHTML = section.html;
        installSection(loader, template.content, true);
        sectionState.set(loader, 'loaded');
      } catch (_) {
        if (job.cancelled) {
          if (loader.isConnected) {
            sectionState.set(loader, 'queued');
            if (!sectionQueue.includes(loader)) sectionQueue.push(loader);
            track.removeAttribute('aria-busy');
          }
          return;
        }
        sectionState.set(loader, 'error');
        if (!loader.isConnected) return;
        track.removeAttribute('aria-busy');
        track.querySelectorAll('.slyme-card-placeholder').forEach(node => node.remove());
        const status = create('p', 'slyme-section-status');
        status.setAttribute('role', 'status');
        status.append(create('span', '', 'Les produits n’ont pas pu être chargés. '));
        const retry = create('button', '', 'Réessayer'); retry.type = 'button';
        retry.addEventListener('click', () => { track.focus({preventScroll:true}); revealSection(loader, true); });
        status.append(retry); track.append(status);
      } finally { clearTimeout(timeout); sectionRequests.delete(loader); }
    };
    const scheduleSections = () => {
      if (!sectionFrame && sectionQueue.length) sectionFrame = requestAnimationFrame(drainSections);
    };
    const watchQueue = () => {
      const needed = !('IntersectionObserver' in window) && sectionQueue.length > 0;
      if (needed === watchingQueue) return;
      watchingQueue = needed;
      const method = needed ? 'addEventListener' : 'removeEventListener';
      window[method]('scroll', scheduleSections, {passive:true});
      window[method]('resize', scheduleSections, {passive:true});
    };
    const drainSections = () => {
      sectionFrame = 0;
      // Une seule lecture de géométrie par rangée, avant toute écriture du chargement.
      const nearby = sectionQueue.map(loader => {
        if (!loader.isConnected) return {loader, distance:Infinity, visible:false};
        const bounds = loader.parentElement.getBoundingClientRect();
        const visible = bounds.bottom > 0 && bounds.top < innerHeight;
        const distance = visible ? 0 : bounds.bottom <= 0 ? -bounds.bottom : bounds.top - innerHeight;
        return {loader, distance, visible};
      }).filter(item => item.distance <= sectionMargin).sort((a,b) => Number(b.visible)-Number(a.visible) || a.distance-b.distance);
      // Une rangée visible ne doit pas attendre deux anciennes lectures devenues lointaines.
      // Les places ne sont libérées qu’après règlement de fetch, jamais au moment d’abort().
      const opening = [...sectionRequests.values()].filter(job => job.controller.signal.aborted).length;
      let needed = Math.min(2, nearby.filter(item => item.visible).length) - (2 - loadingSections) - opening;
      if (needed > 0) {
        const distant = [...sectionRequests].filter(([, job]) => !job.controller.signal.aborted).map(([loader, job]) => {
          const bounds = loader.isConnected ? loader.parentElement.getBoundingClientRect() : null;
          const distance = !bounds ? Infinity : bounds.bottom <= 0 ? -bounds.bottom : Math.max(0, bounds.top - innerHeight);
          return {job, distance};
        }).filter(item => item.distance > sectionMargin).sort((a,b) => b.distance - a.distance);
        for (const {job} of distant) {
          if (needed-- <= 0) break;
          job.cancelled = true; job.controller.abort();
        }
      }
      while (loadingSections < 2 && nearby.length) {
        const item = nearby.shift(), loader = item.loader;
        // Une anticipation au maximum ; l’autre place reste libre pour ce qui est à l’écran.
        if (!item.visible && loadingSections > 0) break;
        const index = sectionQueue.indexOf(loader);
        if (index < 0 || !loader.isConnected) continue;
        sectionQueue.splice(index, 1); loadingSections++;
        loadSection(loader, item.visible).finally(() => { loadingSections--; scheduleSections(); });
      }
      // Un ancien template retiré par un autre rendu ne doit pas garder d’écouteur.
      for (let index=sectionQueue.length-1; index>=0; index--) if (!sectionQueue[index].isConnected) sectionQueue.splice(index,1);
      watchQueue();
    };
    const revealSection = (loader, retry = false) => {
      if (!loader?.isConnected) return;
      const state = sectionState.get(loader);
      if (state && !(state === 'error' && retry)) { if (state === 'queued') scheduleSections(); return; }
      if (loader.content.querySelector(productSelector)) { installSection(loader, loader.content); return; }
      sectionState.set(loader, 'queued'); sectionQueue.push(loader); watchQueue(); scheduleSections();
    };
    if ('IntersectionObserver' in window) {
      sectionObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) {
          revealSection(entry.target.querySelector('template.slyme-section-loader'));
        } else scheduleSections();
      }), {rootMargin:sectionMargin + 'px 0px'});
      // Le deuxième observateur détecte l’arrivée dans l’écran sans travail à chaque scroll.
      visibleSectionsObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) revealSection(entry.target.querySelector('template.slyme-section-loader'));
        else scheduleSections();
      }), {rootMargin:'0px'});
      root.querySelectorAll('template.slyme-section-loader').forEach(loader => { sectionObserver.observe(loader.parentElement); visibleSectionsObserver.observe(loader.parentElement); });
      root.addEventListener('focusin', event => {
        const section = event.target.closest('.slyme-carousel-section');
        if (section) revealSection(section.querySelector('template.slyme-section-loader'));
      });
    } else root.querySelectorAll('template.slyme-section-loader').forEach(loader => revealSection(loader));

    const prefetched = new Set();
    let prefetchTimer = 0, prefetchTarget = null;
    const cancelPrefetch = () => { clearTimeout(prefetchTimer); prefetchTimer = 0; prefetchTarget = null; };
    const warmLink = event => {
      const link = event.target.closest('.slyme-see-all,.slyme-category-card,.slyme-pagination a');
      if (link === prefetchTarget) return;
      cancelPrefetch();
      if (!link || prefetched.size >= 2 || document.hidden || navigator.connection?.saveData || /(^|-)2g$/.test(navigator.connection?.effectiveType || '')) return;
      const url = new URL(link.href, location.href);
      if (url.origin !== location.origin || prefetched.has(url.href)) return;
      prefetchTarget = link;
      prefetchTimer = setTimeout(() => {
        prefetchTimer = 0; prefetchTarget = null;
        if (!link.isConnected || document.hidden || prefetched.has(url.href) || prefetched.size >= 2 || navigator.connection?.saveData || /(^|-)2g$/.test(navigator.connection?.effectiveType || '')) return;
        prefetched.add(url.href);
        const hint = document.createElement('link'); hint.rel = 'prefetch'; hint.as = 'document'; hint.href = url.href; document.head.append(hint);
      }, 180);
    };
    const leaveLink = event => { if (prefetchTarget && !prefetchTarget.contains(event.relatedTarget)) cancelPrefetch(); };
    root.addEventListener('pointerover', event => { if (event.pointerType === 'mouse') warmLink(event); }, {passive:true});
    root.addEventListener('pointerout', leaveLink, {passive:true});
    root.addEventListener('focusin', warmLink);
    root.addEventListener('focusout', leaveLink);
    window.addEventListener('pagehide', cancelPrefetch);
    document.addEventListener('visibilitychange', () => { if (document.hidden) cancelPrefetch(); });

  }));
})();
