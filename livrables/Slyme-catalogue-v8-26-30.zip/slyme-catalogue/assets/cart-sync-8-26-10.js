/* Server-owned cart count. No polling, local cart clone or guessed quantities. */
(()=>{
 'use strict';
 let state={},inFlight=null,revision=0,busy=false;
 const paint=()=>{
  const count=Number(state.count);
  if(Number.isFinite(count)&&count>=0)document.querySelectorAll('[data-sls-header-cart]').forEach(link=>{
   const badge=link.querySelector('.sls-header-cart-count');
   if(badge)badge.textContent=count>99?'99+':String(count);
   link.setAttribute('aria-label','Panier — '+count+(count>1?' articles':' article'));
   if(state.cart)link.href=state.cart;
  });
 };
 const apply=data=>{
  if(!data||typeof data!=='object')return state;
  revision++;state={...state,...data};paint();
  document.body?.dispatchEvent(new CustomEvent('slyme:cart-synced',{bubbles:true,detail:state}));
  return state;
 };
 const read=async(url,options)=>{
  let response;
  try{response=await fetch(url,{credentials:'same-origin',cache:'no-store',...options});}
  catch{throw new Error('Connexion interrompue. Vérifiez votre panier avant de réessayer.');}
  let result;try{result=await response.json();}catch{throw new Error('Réponse du panier indisponible. Vérifiez votre panier avant de réessayer.');}
  if(!response.ok||!result.success){const error=new Error(result.data?.message||'Le panier n’a pas pu être mis à jour.');error.status=response.status;error.cartState=result.data?.cartState;throw error;}
  return result.data;
 };
 const refresh=()=>{
  if(inFlight)return inFlight;
  const config=window.slymeCartConfig||{},requested=++revision;
  if(!config.state)return Promise.reject(new Error('Ouvrez le panier pour vérifier son contenu.'));
  inFlight=read(config.state).then(data=>requested===revision?apply(data):state).finally(()=>{inFlight=null;});
  return inFlight;
 };
 const undo=async token=>{
  if(busy)throw new Error('Une suppression est déjà en cours.');
  if(!/^[a-f0-9]{32}$/.test(token||''))throw new Error('Cet ajout ne peut pas être retrouvé. Ouvrez le panier pour le supprimer.');
  const config=window.slymeCartConfig||{};
  if(!config.undo)throw new Error('Ouvrez le panier pour supprimer ce produit.');
  busy=true;
  try{
   if(!state.nonce)await refresh();
   const remove=()=>read(config.undo,{method:'POST',body:new URLSearchParams({security:state.nonce,token})});
   let data;
   try{data=await remove();}catch(error){if(error.status!==403)throw error;await refresh();data=await remove();}
   apply(data);
   if(window.jQuery)window.jQuery(document.body).trigger('wc_fragment_refresh');
   document.body.dispatchEvent(new CustomEvent('slyme:cart-removed',{bubbles:true,detail:data}));
   return data;
  }finally{busy=false;}
 };
 const add=async data=>{
  if(busy)throw new Error('Une mise à jour du panier est déjà en cours.');
  const config=window.slymeCartConfig||{},token=data.get('sls_cart_token');
  if(!config.add||!/^[a-f0-9]{32}$/.test(token||''))throw new Error('Rechargez la fiche produit avant de réessayer.');
  // Keep the automatic wp_loaded form handler dormant before our endpoint.
  data.set('sls_product_id',data.get('add-to-cart')||data.get('product_id')||data.get('sls_product_id')||'');
  data.delete('add-to-cart');
  busy=true;
  try{
   if(!state.nonce)await refresh();
   const send=()=>{data.set('security',state.nonce);return read(config.add,{method:'POST',body:data,headers:{Accept:'application/json'}});};
   let result;
   try{result=await send();}catch(error){
    // Only this explicit response proves no cart mutation has happened yet.
    if(error.status!==403)throw error;
    await refresh();result=await send();
   }
   if(result?.token!==token||!result.cartState||!Number.isFinite(Number(result.cartState.count)))throw new Error('L’ajout n’a pas été confirmé. Vérifiez votre panier avant de réessayer.');
   return result;
  }catch(error){if(error.cartState)apply(error.cartState);throw error;}
  finally{busy=false;}
 };
 const prepare=()=>state.nonce?Promise.resolve(state):refresh();
 window.slymeCart={apply,refresh,undo,add,prepare,get busy(){return busy;}};
 const needsInitialRefresh=()=>{
  if(window.slymeCartConfig?.authenticated)return true;
  // Woo's cart/session cookies indicate an existing customer state. A fresh
  // anonymous visit with an empty server badge needs no WooCommerce bootstrap.
  try{
   if(/(?:^|;\s*)(?:woocommerce_(?:items_in_cart|cart_hash)|wp_woocommerce_session_[^=;]+)=/.test(document.cookie))return true;
  }catch(_){return true;}
  return [...document.querySelectorAll('[data-sls-header-cart]')].some(link=>parseInt(link.querySelector('.sls-header-cart-count')?.textContent||'0',10)>0);
 };
 const start=()=>{
  const quietRefresh=()=>refresh().catch(()=>{});
  if(needsInitialRefresh())quietRefresh();else apply({count:0});
  window.addEventListener('pageshow',event=>{if(event.persisted)quietRefresh();});
  document.body.addEventListener('slyme:cart-added',event=>{if(event.detail?.cartState)apply(event.detail.cartState);else quietRefresh();});
  document.addEventListener('wc-blocks_added_to_cart',quietRefresh);
  document.addEventListener('wc-blocks_removed_from_cart',quietRefresh);
  if(window.jQuery){
   const body=window.jQuery(document.body);
   body.on('added_to_cart.slsCart removed_from_cart.slsCart updated_wc_div.slsCart',quietRefresh);
   // Fragment replacement redraws the latest verified count without another request.
   body.on('wc_fragments_loaded.slsCart wc_fragments_refreshed.slsCart',paint);
  }
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
