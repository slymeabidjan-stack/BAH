/* Diagnostic local, uniquement chargé sur demande pour un administrateur. */
(() => {
  const supported=window.PerformanceObserver?.supportedEntryTypes || [], observers=[];
  let longCount=0,longDuration=0,lcp=null,cls=0,clsWindow=0,clsStart=0,clsLast=0,stopped=false;
  const observe=(type,callback)=>{
    if(!supported.includes(type)) return;
    const observer=new PerformanceObserver(list=>callback(list.getEntries()));
    observer.observe({type,buffered:true});observers.push(observer);
  };
  observe('longtask',entries=>entries.forEach(e=>{longCount++;longDuration+=e.duration;}));
  observe('largest-contentful-paint',entries=>{lcp=entries.at(-1)?.startTime ?? lcp;});
  observe('layout-shift',entries=>entries.forEach(e=>{
    if(e.hadRecentInput)return;
    if(e.startTime-clsLast>1000 || e.startTime-clsStart>5000){clsWindow=0;clsStart=e.startTime;}
    clsWindow+=e.value;clsLast=e.startTime;cls=Math.max(cls,clsWindow);
  }));
  const start=()=>{
    const panel=document.createElement('aside');panel.setAttribute('aria-label','Diagnostic Slyme');
    Object.assign(panel.style,{position:'fixed',right:'12px',bottom:'12px',width:'min(440px,calc(100vw - 24px))',maxHeight:'70vh',overflow:'auto',zIndex:'2147483647',padding:'18px',boxSizing:'border-box',background:'#fff',color:'#111',boxShadow:'0 6px 32px #0003',border:'1px solid #ddd',borderRadius:'16px',font:'13px/1.5 system-ui'});
    const title=document.createElement('strong');title.textContent='Diagnostic Slyme — cette visite';
    const info=document.createElement('p');info.textContent='Aucune donnée envoyée. Défile sur la page, puis actualise les mesures. Les fichiers lents à charger ne sont pas nécessairement responsables des blocages JavaScript.';
    const output=document.createElement('pre');Object.assign(output.style,{whiteSpace:'pre-wrap',overflowWrap:'anywhere',font:'12px/1.6 monospace',background:'#f6f7f9',padding:'12px',color:'#111'});
    const detail=document.createElement('ol'),actions=document.createElement('div');
    const button=(label,click)=>{const b=document.createElement('button');b.type='button';b.textContent=label;Object.assign(b.style,{padding:'8px',margin:'4px',cursor:'pointer',color:'#111',background:'#f2f3f5',border:'1px solid #ddd',borderRadius:'8px'});b.onclick=click;actions.append(b);};
    const snapshot=()=>{
      const nav=performance.getEntriesByType('navigation')[0],server=document.querySelector('#slyme-server-metrics');
      const resources=performance.getEntriesByType('resource');
      const top=resources.filter(e=>['img','script','link','css','fetch'].includes(e.initiatorType)).sort((a,b)=>b.duration-a.duration).slice(0,8).map(e=>{
        const u=new URL(e.name,location.href);
        return {file:u.hostname+u.pathname,type:e.initiatorType,loadMs:Math.round(e.duration),transferBytes:e.transferSize || null};
      });
      const images=[...document.images].filter(e=>e.complete && e.naturalWidth && e.clientWidth>0 && !(/^data:image\/svg\+xml/.test(e.currentSrc||e.src) && e.dataset.src));
      return {version:document.querySelector('meta[name="slyme-version"]')?.content || 'inconnue',time:new Date().toISOString(),path:location.pathname,ttfbMs:nav?Math.round(nav.responseStart-nav.startTime):null,serverWaitMs:nav?Math.round(nav.responseStart-nav.requestStart):null,documentDownloadMs:nav?Math.round(nav.responseEnd-nav.responseStart):null,htmlAgeSeconds:(()=>{const time=Number(document.querySelector('[data-slyme-rendered]')?.dataset.slymeRendered || 0);return time?Math.max(0,Math.round(Date.now()/1000-time)):null;})(),loadedCatalogueVersions:[...new Set([...document.scripts,...document.querySelectorAll('link[rel=stylesheet]')].map(node=>(node.src||node.href||'').match(/\/slyme-catalogue\/assets\/[^/?]+-(\d+-\d+-\d+)\.(?:js|css)/)?.[1]).filter(Boolean))],lcpMs:lcp===null?null:Math.round(lcp),cls:supported.includes('layout-shift')?Number(cls.toFixed(3)):null,longTasks:supported.includes('longtask')?{count:longCount,totalMs:Math.round(longDuration)}:null,catalogueServerMs:server?Number(server.dataset.ms):null,catalogueQueries:server?Number(server.dataset.queries):null,loadedImages:images.length,oversizedImages:images.filter(e=>e.naturalWidth>e.clientWidth*Math.max(1,devicePixelRatio)*1.5).length,remainingSections:document.querySelectorAll('.slyme-section-loader').length,slowestResources:top};
    };
    const refresh=()=>{
      const r=snapshot();
      output.textContent=`Version de la page : ${r.version}\nVersions des fichiers : ${r.loadedCatalogueVersions.join(', ') || 'non détectées'}\nÂge du HTML du catalogue : ${r.htmlAgeSeconds === null ? 'non mesuré' : r.htmlAgeSeconds+' s'}\nRéponse serveur (TTFB) : ${r.ttfbMs ?? 'indisponible'} ms\nAttente après la requête : ${r.serverWaitMs ?? 'indisponible'} ms\nTéléchargement du HTML : ${r.documentDownloadMs ?? 'indisponible'} ms\nGrand contenu (LCP) : ${r.lcpMs ?? 'non disponible sur ce navigateur'}${r.lcpMs===null?'':' ms'}\nDécalages visuels (CLS) : ${r.cls ?? 'non disponible'}\nTâches > 50 ms : ${r.longTasks ? r.longTasks.count+' ('+r.longTasks.totalMs+' ms)' : 'non disponible sur ce navigateur'}\nPréparation du catalogue : ${r.catalogueServerMs ?? 'non mesurée'} ms / ${r.catalogueQueries ?? '?'} requêtes\nImages chargées : ${r.loadedImages}\nImages potentiellement trop grandes : ${r.oversizedImages}\nRangées encore différées : ${r.remainingSections}${stopped?'\nObservation arrêtée.':''}`;
      detail.replaceChildren();r.slowestResources.forEach(e=>{const li=document.createElement('li');li.textContent=e.loadMs+' ms — '+e.type+' — '+e.file;li.style.overflowWrap='anywhere';detail.append(li);});
    };
    const stop=()=>{stopped=true;observers.forEach(o=>o.disconnect());};
    button('Actualiser',refresh);
    button('Exporter le rapport',()=>{const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(snapshot(),null,2)],{type:'application/json'}));a.href=url;a.download='slyme-diagnostic.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
    button('Arrêter',()=>{stop();refresh();});button('Fermer',()=>{stop();panel.remove();});
    panel.append(title,info,output,detail,actions);document.body.append(panel);refresh();
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
