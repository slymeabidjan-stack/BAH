/* Slyme : mouvement natif du navigateur, sans boucle JS ni copie de produit. */
(() => {
  const SPEED = 200; // Pixels/seconde : mouvement régulier, indépendant de l’écran.
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const ready = callback => document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', callback, {once:true}) : callback();
  ready(() => document.querySelectorAll('.slyme-offers-section .slyme-product-grid').forEach(track => {
    if (track.dataset.slymeOffersReady) return;
    track.dataset.slymeOffersReady = '2';
    const section = track.closest('.slyme-offers-section');
    const actions = section.querySelector('.slyme-header-actions');
    if (!actions) return;
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'slyme-offers-motion';
    if (track.id) button.setAttribute('aria-controls', track.id);
    button.innerHTML = '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true" focusable="false"><path class="slyme-offers-pause-icon" d="M6 4v12M14 4v12"/><path class="slyme-offers-play-icon" d="m6 3 10 7-10 7z"/></svg><span></span>';
    const label = button.querySelector('span');
    actions.insertBefore(button, actions.querySelector('.slyme-carousel-controls'));
    let paused = reduced.matches, hovered = false, focused = false, visible = false;
    let layer = null, animation = null, direction = 1, limit = 0, animationLimit = 0, usable = false;
    const clamp = value => Math.max(0, Math.min(limit, value));
    const stop = () => {
      if (!animation) return;
      const timing = animation.effect.getComputedTiming();
      const position = clamp((timing.progress || 0) * animationLimit + track.scrollLeft);
      direction = (timing.currentIteration || 0) % 2 ? -1 : 1;
      animation.cancel(); animation = null;
      track.classList.remove('slyme-offers-scrolling');
      // Même position visible : le navigateur reprend le défilement tactile natif.
      track.scrollLeft = position;
    };
    const allowed = () => usable && visible && !document.hidden && !paused && !hovered && !focused;
    const sync = () => {
      if (!allowed()) { stop(); return; }
      if (animation) return;
      const position = clamp(track.scrollLeft);
      if (position >= limit) direction = -1;
      else if (position <= 0) direction = 1;
      animationLimit = limit;
      const duration = limit / SPEED * 1000;
      track.classList.add('slyme-offers-scrolling');
      track.scrollLeft = 0;
      animation = layer.animate([
        {transform:'translate3d(0,0,0)'},
        {transform:`translate3d(${-limit}px,0,0)`}
      ], {duration, iterations:Infinity, direction:'alternate', easing:'linear'});
      animation.currentTime = (direction > 0 ? position / limit : 2 - position / limit) * duration;
    };
    const renderButton = () => {
      button.hidden = !usable;
      button.dataset.paused = paused ? 'true' : 'false';
      label.textContent = paused ? 'Défiler' : 'Pause';
      button.setAttribute('aria-label', paused ? 'Lancer le défilement des offres' : 'Mettre le défilement des offres en pause');
    };
    const measure = () => {
      stop();
      const loaded = !track.querySelector('.slyme-section-loader');
      const cards = track.querySelectorAll('.slyme-product-card[data-product-id]:not([hidden])');
      if (loaded && cards.length > 1 && (!layer || !track.contains(layer))) {
        layer = document.createElement('div');
        layer.className = 'slyme-offers-lane';
        // Les mêmes nœuds restent présents : aucun lien ni produit n’est dupliqué.
        while (track.firstChild) layer.append(track.firstChild);
        track.append(layer);
      }
      limit = Math.max(0, track.scrollWidth - track.clientWidth);
      usable = loaded && cards.length > 1 && limit > 2 && !!layer && typeof layer.animate === 'function';
      renderButton(); sync();
    };
    const pause = () => { paused = true; renderButton(); stop(); };
    button.addEventListener('click', () => { paused = !paused; renderButton(); sync(); });
    // Capture avant les gestionnaires de drag/flèches : un seul mouvement à la fois.
    track.addEventListener('pointerdown', pause, {passive:true, capture:true});
    track.addEventListener('wheel', pause, {passive:true, capture:true});
    track.addEventListener('keydown', event => { if (event.key !== 'Tab') pause(); }, true);
    section.addEventListener('click', event => {
      if (event.target.closest('[data-slyme-prev],[data-slyme-next]')) pause();
    }, true);
    track.addEventListener('pointerenter', event => {
      if (event.pointerType === 'mouse') { hovered = true; sync(); }
    }, {passive:true});
    track.addEventListener('pointerleave', event => {
      if (event.pointerType === 'mouse') { hovered = false; sync(); }
    }, {passive:true});
    track.addEventListener('focusin', () => { focused = true; sync(); });
    track.addEventListener('focusout', () => {
      queueMicrotask(() => { focused = track.contains(document.activeElement); sync(); });
    });
    track.addEventListener('slyme:refresh', measure);
    document.addEventListener('visibilitychange', sync);
    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', sync);
    reduced.addEventListener('change', () => { if (reduced.matches) pause(); });
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(track);
    else window.addEventListener('resize', measure, {passive:true});
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => { visible = entries[0].isIntersecting; sync(); }).observe(track);
    } else {
      let frame = 0;
      const checkVisible = () => {
        frame = 0;
        const bounds = track.getBoundingClientRect();
        visible = bounds.bottom > 0 && bounds.top < innerHeight; sync();
      };
      const schedule = () => { if (!frame) frame = requestAnimationFrame(checkVisible); };
      window.addEventListener('scroll', schedule, {passive:true});
      window.addEventListener('resize', schedule, {passive:true});
      checkVisible();
    }
    measure();
  }));
})();
