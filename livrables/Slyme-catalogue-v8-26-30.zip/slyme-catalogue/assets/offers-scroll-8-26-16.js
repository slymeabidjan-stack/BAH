/* Slyme : offres en mouvement, sans copies de cartes ni requêtes supplémentaires. */
(() => {
  const SPEED = 240; // Pixels par seconde, indépendamment de la fréquence de l’écran.
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const ready = callback => document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', callback, {once:true}) : callback();
  ready(() => document.querySelectorAll('.slyme-offers-section .slyme-product-grid').forEach(track => {
    if (track.dataset.slymeOffersReady) return;
    track.dataset.slymeOffersReady = '1';
    const section = track.closest('.slyme-offers-section');
    const actions = section.querySelector('.slyme-header-actions');
    if (!actions) return;

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'slyme-offers-motion';
    if (track.id) button.setAttribute('aria-controls', track.id);
    button.innerHTML = '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true" focusable="false"><path class="slyme-offers-pause-icon" d="M6 4v12M14 4v12"/><path class="slyme-offers-play-icon" d="m6 3 10 7-10 7z"/></svg><span></span>';
    const label = button.querySelector('span');
    actions.insertBefore(button, actions.querySelector('.slyme-carousel-controls'));

    let paused = reduced.matches, hovered = false, focused = false, visible = false;
    let frame = 0, lastTime = 0, position = 0, direction = 1, limit = 0, usable = false;
    const stop = () => {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0;
      track.classList.remove('slyme-offers-scrolling');
    };
    const allowed = () => usable && visible && !document.hidden && !paused && !hovered && !focused;
    const tick = now => {
      frame = 0;
      if (!allowed()) { stop(); return; }
      const elapsed = lastTime ? Math.min(40, now - lastTime) / 1000 : 0;
      lastTime = now;
      // Un seul déplacement par image. Les extrémités ralentissent avant le retour.
      const remaining = direction > 0 ? limit - position : position;
      const speed = Math.min(SPEED, Math.max(55, remaining * 3));
      position = Math.max(0, Math.min(limit, position + direction * speed * elapsed));
      track.scrollLeft = position;
      if (position >= limit) direction = -1;
      else if (position <= 0) direction = 1;
      frame = requestAnimationFrame(tick);
    };
    const sync = () => {
      if (!allowed()) { stop(); return; }
      if (!frame) {
        position = Math.max(0, Math.min(limit, track.scrollLeft));
        if (position >= limit) direction = -1;
        else if (position <= 0) direction = 1;
        lastTime = 0;
        track.classList.add('slyme-offers-scrolling');
        frame = requestAnimationFrame(tick);
      }
    };
    const renderButton = () => {
      button.hidden = !usable;
      button.dataset.paused = paused ? 'true' : 'false';
      label.textContent = paused ? 'Défiler' : 'Pause';
      button.setAttribute('aria-label', paused ? 'Lancer le défilement des offres' : 'Mettre le défilement des offres en pause');
    };
    const measure = () => {
      stop();
      // Géométrie lue seulement à l’arrivée des cartes et au redimensionnement.
      limit = Math.max(0, track.scrollWidth - track.clientWidth);
      usable = limit > 2 && !track.querySelector('.slyme-section-loader')
        && track.querySelectorAll('.slyme-product-card[data-product-id]:not([hidden])').length > 1;
      renderButton(); sync();
    };
    const pause = () => {
      paused = true;
      renderButton(); stop();
    };
    button.addEventListener('click', () => { paused = !paused; renderButton(); sync(); });
    // Un geste manuel garde la priorité jusqu’à un appui explicite sur « Défiler ».
    track.addEventListener('pointerdown', pause, {passive:true});
    track.addEventListener('wheel', pause, {passive:true});
    track.addEventListener('keydown', event => { if (event.key !== 'Tab') pause(); });
    section.addEventListener('click', event => {
      if (event.target.closest('[data-slyme-prev],[data-slyme-next]')) pause();
    }, true);
    track.addEventListener('pointerenter', event => {
      if (event.pointerType === 'mouse') { hovered = true; sync(); }
    }, {passive:true});
    track.addEventListener('pointerleave', event => {
      if (event.pointerType === 'mouse') { hovered = false; sync(); }
    }, {passive:true});
    track.addEventListener('focusin', () => { focused = true; sync(); });
    track.addEventListener('focusout', () => {
      queueMicrotask(() => { focused = track.contains(document.activeElement); sync(); });
    });
    track.addEventListener('slyme:refresh', measure);
    document.addEventListener('visibilitychange', sync);
    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', sync);
    reduced.addEventListener('change', () => { if (reduced.matches) pause(); });
    if ('ResizeObserver' in window) new ResizeObserver(measure).observe(track);
    else window.addEventListener('resize', measure, {passive:true});
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => {
        visible = entries[0].isIntersecting;
        sync();
      }).observe(track);
    } else {
      let visibilityFrame = 0;
      const checkVisible = () => {
        visibilityFrame = 0;
        const bounds = track.getBoundingClientRect();
        visible = bounds.bottom > 0 && bounds.top < innerHeight;
        sync();
      };
      const scheduleVisibility = () => {
        if (!visibilityFrame) visibilityFrame = requestAnimationFrame(checkVisible);
      };
      window.addEventListener('scroll', scheduleVisibility, {passive:true});
      window.addEventListener('resize', scheduleVisibility, {passive:true});
      checkVisible();
    }
    measure();
  }));
})();
