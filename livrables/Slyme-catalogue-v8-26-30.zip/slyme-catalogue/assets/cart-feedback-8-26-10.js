/* Confirmation follows an actual server-confirmed WooCommerce addition. */
(()=>{
 'use strict';
 const start=()=>{
  let panel,product,token='',removing=false;
  const close=()=>{if(removing)return;const focused=panel?.contains(document.activeElement);panel?.remove();panel=null;product?.classList.remove('sls-has-confirmation');if(focused)(product?.querySelector('.woocommerce-product-gallery a')||product?.querySelector('.single_add_to_cart_button'))?.focus({preventScroll:true});};
  const show=async event=>{
   if(!event?.detail?.token){
    const marker=document.querySelector('.sls-cart-confirmed');
    if(marker){token=marker.dataset.slsConfirm;try{window.slymeCart?.apply(JSON.parse(marker.dataset.slsCartState));}catch(e){}marker.remove();}
    else {try{token=(await window.slymeCart?.refresh())?.token||'';}catch(e){return;}}
   }else token=event.detail.token;
   if(!token)return;
   const links=window.slymeCartFeedback||{};
   product=event?.detail?.product||document.querySelector('div.product[id^="product-"]');
   const host=product||document.querySelector('.woocommerce')||document.querySelector('main')||document.body;
   if(!panel){
    panel=document.createElement('section');panel.className='sls-inline-confirmation';panel.setAttribute('aria-label','Confirmation de l’ajout au panier');
    const header=document.createElement('div');header.className='sls-confirmation-header';
    const icon=document.createElement('span');icon.className='sls-confirmation-icon';icon.setAttribute('aria-hidden','true');icon.innerHTML='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 12 4 4 8-9"/></svg>';
    const copy=document.createElement('div');copy.className='sls-confirmation-copy';copy.setAttribute('role','status');
    const title=document.createElement('p');title.className='sls-confirmation-title';title.textContent='Produit ajouté au panier !';
    const description=document.createElement('p');description.className='sls-confirmation-description';description.textContent='Poursuivez vers le panier pour continuer votre commande.';
    const error=document.createElement('p');error.className='sls-confirmation-error';error.hidden=true;error.setAttribute('role','alert');
    copy.append(title,description,error);header.append(icon,copy);panel.append(header);
    const actions=document.createElement('div');actions.className='sls-confirmation-actions';
    const keep=document.createElement('button');keep.type='button';keep.className='sls-confirmation-keep';keep.textContent='Continuer mes achats';keep.addEventListener('click',close);actions.append(keep);
    if(links.cart){const cart=document.createElement('a');cart.className='sls-confirmation-cart';cart.textContent='Continuer vers le panier';cart.href=links.cart;actions.append(cart);}
    const remove=document.createElement('button');remove.type='button';remove.className='sls-confirmation-remove';remove.textContent='Supprimer';
    remove.addEventListener('click',async()=>{
     if(removing)return;
     removing=true;remove.disabled=true;keep.disabled=true;remove.textContent='Suppression…';error.hidden=true;
     try{if(!window.slymeCart)throw new Error('Ouvrez le panier pour supprimer cet article.');await window.slymeCart.undo(token);removing=false;close();}
     catch(e){error.textContent=e.message||'La suppression n’a pas été confirmée. Réessayez.';error.hidden=false;}
     finally{removing=false;remove.disabled=false;keep.disabled=false;remove.textContent='Supprimer';}
    });actions.append(remove);
    panel.append(actions);host.prepend(panel);product?.classList.add('sls-has-confirmation');
   }
   const previousError=panel.querySelector('.sls-confirmation-error');previousError.hidden=true;previousError.textContent='';
   requestAnimationFrame(()=>window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'}));
  };
  document.body.addEventListener('slyme:cart-added',show);
  if(document.querySelector('.sls-cart-confirmed'))show();
  if(window.jQuery)window.jQuery(document.body).on('added_to_cart.slsFeedback',show);
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
