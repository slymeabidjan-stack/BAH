/* Extensions de l’interface native : WooCommerce garde les variantes, le stock et le panier. */
(() => {
 'use strict';
 const start=()=>{
  if(!document.body.classList.contains('slyme-product-shopping'))return;
  const product=document.querySelector('div.product[id^="product-"]');
  const form=product?.querySelector('form.cart');
  if(!product||!form||form.dataset.slsReady)return;
  form.dataset.slsReady='1';
  const config=window.slymeShopping||{},$=window.jQuery;
  const variable=form.classList.contains('variations_form');
  const selects=[...form.querySelectorAll('.variations select[name^="attribute_"]')];
  const groups=[];
  const normalize=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const colors={noir:'#000',black:'#000',blanc:'#fff',white:'#fff',bleu:'#0184c8',blue:'#0184c8',rouge:'#e51b23',red:'#e51b23',vert:'#008b45',green:'#008b45',violet:'#8224e3',purple:'#8224e3',rose:'#ed5c9c',pink:'#ed5c9c',orange:'#ff6b00',gris:'#969b9f',grey:'#969b9f',gray:'#969b9f',argent:'#c3c9ce',silver:'#c3c9ce',or:'#c6ad7b',gold:'#c6ad7b',beige:'#d8cbb6',marron:'#503727',brown:'#503727'};
  Object.entries(config.colors||{}).forEach(([name,hex])=>{if(/^#(?:[a-f0-9]{3}|[a-f0-9]{6})$/i.test(hex))colors[normalize(name)]=hex;});
  const kindFor=select=>{
   const name=normalize(select.name+' '+(select.closest('tr')?.querySelector('label')?.textContent||''));
   if(/\b(couleurs?|colou?rs?|coloris)\b/.test(name))return 'color';
   if(/\b(ram|memoire vive)\b/.test(name))return 'memory';
   if(/\b(stockage|capacite|capacity|storage|memoire)\b/.test(name))return 'storage';
   return '';
  };
  const summaries=[...product.querySelectorAll('[data-sls-spec]')].map(node=>({node,text:node.textContent}));
  const syncSummary=()=>summaries.forEach(({node,text})=>{
   const select=selects.find(s=>kindFor(s)===node.dataset.slsSpec);
   node.textContent=select?.value?select.selectedOptions[0].textContent:text;
  });
  const syncGroups=()=>{
   groups.forEach(({select,buttons})=>{
    const options=new Map([...select.options].map(o=>[o.value,o]));
    buttons.forEach(button=>{
     const option=options.get(button.dataset.value),selected=select.value===button.dataset.value;
     button.disabled=select.disabled||!option||option.disabled;
     button.setAttribute('aria-checked',String(selected));
     button.tabIndex=-1;
     button.title=button.textContent+(button.disabled?' — Indisponible avec ces options':'');
    });
    const target=buttons.find(b=>!b.disabled&&b.getAttribute('aria-checked')==='true')||buttons.find(b=>!b.disabled);
    if(target)target.tabIndex=0;
   });
   syncSummary();
  };
  if(variable&&$&&$.fn.wc_variation_form&&config.visual){
   selects.forEach((select,index)=>{
    const kind=kindFor(select);if(!kind)return;
    const reference=document.createElement('select');
    reference.innerHTML=$(select).data('attribute_html')||select.innerHTML;
    const options=[...reference.options].filter(o=>o.value);
    if(!options.length||options.length>24)return;
    // Si une autre extension transforme déjà ce champ, garder son interface.
    if(select.hidden||getComputedStyle(select).display==='none')return;
    const label=select.closest('tr')?.querySelector('label');
    const group=document.createElement('div');group.className='sls-options';group.setAttribute('role','radiogroup');
    if(label){if(!label.id)label.id='sls-label-'+index;group.setAttribute('aria-labelledby',label.id);}else group.setAttribute('aria-label',select.name.replace(/^attribute_(pa_)?/,''));
    const buttons=options.map((option,i)=>{
     const button=document.createElement('button');button.type='button';button.className='sls-option';button.id='sls-option-'+index+'-'+i;button.dataset.value=option.value;button.setAttribute('role','radio');button.setAttribute('aria-label',option.textContent.trim());
     if(kind==='color'&&colors[normalize(option.textContent)]){
      const dot=document.createElement('span');dot.className='sls-color';dot.setAttribute('aria-hidden','true');dot.style.backgroundColor=colors[normalize(option.textContent)];button.append(dot);
     }
     const text=document.createElement('span');text.textContent=option.textContent;button.append(text);
     button.addEventListener('click',()=>{if(button.disabled)return;select.value=option.value;select.dispatchEvent(new Event('change',{bubbles:true}));syncGroups();});
     group.append(button);return button;
    });
    group.addEventListener('keydown',event=>{
     if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
     const enabled=buttons.filter(b=>!b.disabled);if(!enabled.length)return;
     event.preventDefault();let i=enabled.indexOf(document.activeElement);
     if(event.key==='Home')i=0;else if(event.key==='End')i=enabled.length-1;else i=(i+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+enabled.length)%enabled.length;
     enabled[i].focus();enabled[i].click();
    });
    select.after(group);select.hidden=true;select.classList.add('sls-native-select');
    if(label)label.htmlFor=buttons[0].id;
    groups.push({select,buttons});
   });
   $(form).on('woocommerce_update_variation_values.sls wc_variation_form.sls reset_data.sls woocommerce_variation_has_changed.sls',syncGroups);
   // WooCommerce demande parfois le focus sur le select natif après une remise à zéro.
   $(form).on('reset_focus.sls',()=>groups[0]?.buttons.find(b=>!b.disabled)?.focus());
  }
  if(groups.length)form.classList.add('sls-visual-options');
  form.addEventListener('change',syncSummary);
  if(variable&&$)$(form).on('woocommerce_variation_has_changed.slsSummary reset_data.slsSummary',syncSummary);
  syncGroups();
  const bar=document.querySelector('[data-sls-bar]');
  if(!bar)return;
  const nativeButton=form.querySelector('.single_add_to_cart_button');
  if(!nativeButton||variable&&(!$||!$.fn.wc_variation_form))return;
  const price=bar.querySelector('.sls-buybar-price'),caption=bar.querySelector('.sls-buybar-caption'),status=bar.querySelector('.sls-buybar-status'),action=bar.querySelector('.sls-buybar-action');
  const actionLabel=action.querySelector('span'),photo=bar.querySelector('.sls-buybar-image');
  const originalPhoto=photo?{src:photo.getAttribute('src'),srcset:photo.getAttribute('srcset')||''}:null;
  const originalPrice=price.innerHTML,reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let current=null,ready=false,busy=false,pending=false,visibilityFrame=0,lastScroll=Math.max(0,window.scrollY),barActive=false;
  const complete=()=>selects.length>0&&selects.every(s=>s.value);
  const matches=v=>v&&complete()&&selects.every(s=>!v.attributes?.[s.name]||v.attributes[s.name]===s.value)&&String(form.querySelector('[name="variation_id"]')?.value)===String(v.variation_id);
  const canBuy=()=>!busy&&!nativeButton.disabled&&!nativeButton.classList.contains('disabled')&&(!variable||(ready&&matches(current)&&current.is_purchasable&&current.is_in_stock&&current.variation_is_visible));
  const textFrom=html=>{const div=document.createElement('div');div.innerHTML=html||'';return div.textContent.trim();};
  const selectedPrice=variation=>{
   if(variation.price_html)return variation.price_html;
   // WooCommerce peut ne pas fournir de HTML lorsque les variantes ont le même prix.
   if(typeof variation.display_price!=='number'||!Number.isFinite(variation.display_price))return originalPrice;
   const money=config.money||{decimals:0,decimal:',',thousand:' ',format:'%2$s %1$s',symbol:'FCFA'};
   const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
   const parts=variation.display_price.toFixed(Math.max(0,Math.min(6,Number(money.decimals)||0))).split('.');
   const amount=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,()=>money.thousand)+(parts.length>1?money.decimal+parts[1]:'');
   return '<span class="woocommerce-Price-amount amount"><bdi>'+escape(textFrom(money.format)).replace('%1$s','<span class="woocommerce-Price-currencySymbol">'+escape(textFrom(money.symbol))+'</span>').replace('%2$s',escape(amount))+'</bdi></span>';
  };
  const render=()=>{
   const valid=variable&&matches(current);
   const nextPrice=valid?selectedPrice(current):originalPrice;
   if(price.innerHTML!==nextPrice){price.innerHTML=nextPrice;if(!bar.hidden)price.dispatchEvent(new CustomEvent('slyme:price',{bubbles:true}));}
   const qty=Number(form.querySelector('input.qty')?.value||1);
   caption.textContent=valid?'Option sélectionnée'+(qty>1?' · prix unitaire':''):variable?'Sélectionne tes options':qty>1?'Prix unitaire · '+qty+' articles':'Prix unitaire';
   status.textContent=busy?'Ajout en cours…':valid?(textFrom(current.availability_html)||(current.is_in_stock?'Disponible':'Indisponible')):pending?'Vérification de la disponibilité…':variable?'Sélectionne tes options':(textFrom(product.querySelector('.summary .stock')?.innerHTML||'')||'En stock');
   const unavailable=valid&&(!current.is_in_stock||!current.is_purchasable||!current.variation_is_visible);
   actionLabel.textContent=busy?'Ajout en cours…':pending?'Vérification…':unavailable?'Indisponible':'Je l’achète';
   action.disabled=busy||pending||unavailable;
   bar.dataset.stock=unavailable?'out':valid||!variable?'in':'choose';
   if(photo&&originalPhoto){
    const image=valid&&current.image?.src?current.image:null;
    const nextSrc=image?.gallery_thumbnail_src||image?.thumb_src||image?.src||originalPhoto.src;
    const nextSet=image?(image.srcset||''):originalPhoto.srcset;
    if(photo.getAttribute('src')!==nextSrc)photo.setAttribute('src',nextSrc);
    if(nextSet)photo.setAttribute('srcset',nextSet);else photo.removeAttribute('srcset');
   }
  };
  const updateVisibility=()=>{
   visibilityFrame=0;
   const position=Math.max(0,window.scrollY);
   if(position>lastScroll+.5)barActive=true;
   else if(position<lastScroll-.5){
    const bounds=nativeButton.getBoundingClientRect();
    if(bounds.bottom>0&&bounds.top<window.innerHeight)barActive=false;
   }
   lastScroll=position;
   if(position<=1)barActive=false;
   const visible=position>1&&barActive;
   const wasHidden=bar.hidden;
   if(wasHidden===!visible)return;
   bar.hidden=!visible;
   if(visible&&wasHidden)bar.dispatchEvent(new CustomEvent('slyme:enter',{bubbles:true}));
   document.body.classList.toggle('sls-has-buybar',visible);
   if(visible&&wasHidden)document.body.style.setProperty('--sls-bar-height',bar.offsetHeight+'px');
  };
  const scheduleVisibility=()=>{if(!visibilityFrame)visibilityFrame=requestAnimationFrame(updateVisibility);};
  // One update per frame; button geometry is read only while scrolling upward.
  window.addEventListener('scroll',scheduleVisibility,{passive:true});
  if('ResizeObserver' in window)new ResizeObserver(scheduleVisibility).observe(bar);
  window.addEventListener('resize',scheduleVisibility,{passive:true});
  document.addEventListener('focusin',scheduleVisibility);document.addEventListener('focusout',scheduleVisibility);
  window.addEventListener('pageshow',()=>{busy=false;barActive=false;lastScroll=window.scrollY;render();scheduleVisibility();});
  form.addEventListener('change',event=>{
   if(event.target.matches('select[name^="attribute_"]')){current=null;ready=false;pending=complete();render();}
  },true);
  if(variable){
   $(form).on('found_variation.sls',(event,variation)=>{current=variation;ready=false;pending=false;render();});
   $(form).on('show_variation.sls',(event,variation,purchasable)=>{if(matches(variation)){current=variation;ready=!!purchasable;pending=false;render();}});
   $(form).on('reset_data.sls hide_variation.sls',()=>{current=null;ready=false;pending=false;render();});
   $(form).on('woocommerce_variation_has_changed.sls',()=>{if(!matches(current)){current=null;ready=false;pending=complete();}render();});
   // Une requête échouée ne doit pas laisser la barre bloquée.
   $(document).on('ajaxError.sls',(event,xhr,settings)=>{if(pending&&String(settings.url).includes('wc-ajax=get_variation')){pending=false;status.textContent='Choisis à nouveau tes options.';action.disabled=false;}});
  }
  form.addEventListener('change',render);
  let targetTimer=0;
  const guidance=document.createElement('p');guidance.className='sls-buy-guidance';guidance.hidden=true;guidance.setAttribute('role','status');form.prepend(guidance);
  const optionLabel=s=>({color:'la couleur',storage:'la capacité',memory:'la mémoire vive'}[kindFor(s)]||s.closest('tr')?.querySelector('label')?.textContent.trim()||s.name.replace(/^attribute_(pa_)?/,''));
  // Continuous compositor animation, with no scroll timers or layout animation.
  nativeButton.classList.add('sls-buy-pulse');
  const visibleTarget=node=>{
   if(!node||node.hidden||node.disabled||node.getAttribute('aria-disabled')==='true')return false;
   const style=getComputedStyle(node),rect=node.getBoundingClientRect();
   return style.display!=='none'&&style.visibility!=='hidden'&&rect.width>0&&rect.height>0;
  };
  const optionTarget=select=>{
   const own=groups.find(g=>g.select===select)?.buttons.find(visibleTarget);
   if(own)return own;
   if(visibleTarget(select))return select;
   // WPC and other swatch plugins hide the native select. Guide the customer
   // to their visible controls instead of scrolling to an invisible field.
   const row=select.closest('tr')||select.parentElement;
   const control=[...row.querySelectorAll('button,[role="radio"],[role="option"],[tabindex]')].find(node=>node!==select&&visibleTarget(node));
   if(control)return control;
   const label=row.querySelector('label');
   const fallback=visibleTarget(label)?label:visibleTarget(row)?row:nativeButton;
   if(!fallback.hasAttribute('tabindex'))fallback.tabIndex=-1;
   return fallback;
  };
  const goToForm=()=>{
   const select=selects.find(s=>!s.value);
   const target=select?optionTarget(select):nativeButton;
   if(!target)return;
   form.querySelectorAll('.sls-buy-target').forEach(node=>node.classList.remove('sls-buy-target'));
   clearTimeout(targetTimer);
   const missing=selects.filter(s=>!s.value);
   guidance.textContent=missing.length?'Choisissez '+missing.map(optionLabel).join(' et ')+', puis ajoutez le produit au panier.':'Vos options sont prêtes. Vous pouvez ajouter ce produit au panier.';
   guidance.hidden=false;
   target.classList.add('sls-buy-target');
   target.scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'center'});
   target.focus({preventScroll:true});
   targetTimer=setTimeout(()=>{target.classList.remove('sls-buy-target');guidance.hidden=true;},7000);
  };
  action.addEventListener('click',()=>{
   if(action.disabled)return;
   goToForm();
   scheduleVisibility();
  });
  // Prepare the existing session request on purchase intent, never on page load.
  const prepareCart=()=>{if(window.slymeCartConfig?.add)window.slymeCart?.prepare?.().catch(()=>{});};
  form.addEventListener('pointerdown',prepareCart,{once:true,passive:true});
  form.addEventListener('focusin',prepareCart,{once:true});
  form.addEventListener('submit',async event=>{
   if(busy||window.slymeCart?.busy){event.preventDefault();return;}
   // An old cached configuration keeps the standard WooCommerce form route.
   if(!window.slymeCart?.add||!window.slymeCartConfig?.add)return;
   if(event.defaultPrevented||!canBuy()||!form.checkValidity())return;
   event.preventDefault();busy=true;render();
   const bytes=new Uint8Array(16);crypto.getRandomValues(bytes);
   const token=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
   const data=new FormData(form);data.set('sls_cart_token',token);
   if(nativeButton.name)data.set(nativeButton.name,nativeButton.value);
   if(!data.has('add-to-cart'))data.set('add-to-cart',form.querySelector('[name="product_id"]')?.value||product.id.replace('product-',''));
   try{
    const result=await window.slymeCart.add(data);
    document.body.dispatchEvent(new CustomEvent('slyme:cart-added',{bubbles:true,detail:{product,token:result.token,cartState:result.cartState}}));
    // WooCommerce refreshes mini-cart fragments without leaving this product page.
    if($)$(document.body).trigger('wc_fragment_refresh');
   }catch(error){guidance.textContent=error.message||'Connexion interrompue. Vérifiez votre panier avant de réessayer.';guidance.hidden=false;guidance.scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'center'});}
   finally{busy=false;render();}
  });
  if($)$(document.body).on('added_to_cart.sls wc_add_to_cart_error.sls',()=>{busy=false;form.querySelector('[name="sls_go_cart"]')?.remove();render();});
  if('MutationObserver' in window)new MutationObserver(render).observe(nativeButton,{attributes:true,attributeFilter:['class','disabled']});
  render();scheduleVisibility();
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
