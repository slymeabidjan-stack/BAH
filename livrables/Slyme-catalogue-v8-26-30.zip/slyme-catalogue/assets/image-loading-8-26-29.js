/* Slyme : prépare une portion de rangée avant son arrivée, sans charger tout le catalogue. */
(() => {
  const ready = callback => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', callback, {once:true}) : callback();
  ready(() => {
    const economical = !!navigator.connection?.saveData;
    const verticalLead = economical ? 200 : 650;
    const horizontalLead = economical ? 120 : 240;
    const warmed = new WeakSet();
    const prepare = image => {
      if (warmed.has(image) || !image.isConnected || image.matches('.show-on-hover') || image.closest('[hidden]')) return;
      // Les src/srcset natifs restent inchangés ; aucun téléchargement séparé ni attente de decode().
      image.loading = 'eager';
      if (image.fetchPriority === 'low') image.fetchPriority = 'auto';
      if (!image.hasAttribute('decoding')) image.decoding = 'async';
      warmed.add(image);
    };
    const visible = image => {
      const bounds = image.getBoundingClientRect();
      const track = image.closest('.slyme-product-grid');
      const clip = track ? track.getBoundingClientRect() : {top:0, bottom:innerHeight, left:0, right:innerWidth};
      return bounds.width > 0 && bounds.height > 0 && bounds.bottom > Math.max(0, clip.top) && bounds.top < Math.min(innerHeight, clip.bottom) && bounds.right > Math.max(0, clip.left) && bounds.left < Math.min(innerWidth, clip.right);
    };
    const tracks = [...document.querySelectorAll('.slyme-products-grid .slyme-product-grid')];
    const verticalImages = [...document.querySelectorAll('.slyme-products-grid .slyme-collection-grid .slyme-product-card[data-product-id] img:not(.show-on-hover),body.theme-sinatra.single-product .related.products ul.products img:not(.show-on-hover)')];
    if (!('IntersectionObserver' in window)) {
      // Les anciens navigateurs gardent leur lazy loading. Préparer seulement ce qui est réellement visible.
      verticalImages.filter(visible).forEach(prepare);
      tracks.forEach(track => {
        let frame = 0;
        const refresh = () => {
          frame = 0;
          track.querySelectorAll('.slyme-product-card[data-product-id] img:not(.show-on-hover)').forEach(image => { if (!warmed.has(image) && visible(image)) prepare(image); });
        };
        track.addEventListener('slyme:refresh', refresh);
        track.addEventListener('scroll', () => { if (!frame) frame = requestAnimationFrame(refresh); }, {passive:true});
        refresh();
      });
      return;
    }
    const states = new WeakMap();
    const rowObserver = new IntersectionObserver(entries => entries.forEach(entry => {
      const state = states.get(entry.target);
      if (!state) return;
      state.active = entry.isIntersecting;
      if (state.active) state.refresh();
      else { state.observer?.disconnect(); state.observer = null; }
    }), {rootMargin:verticalLead + 'px 0px'});
    tracks.forEach(track => {
      const state = {active:false, observer:null, refresh:null};
      state.refresh = () => {
        if (!state.active) return;
        if (!state.observer) state.observer = new IntersectionObserver(entries => entries.forEach(entry => {
          // La racine est la rangée : la marge anticipe aussi les cartes masquées par son overflow.
          if (state.active && entry.isIntersecting) { prepare(entry.target); state.observer?.unobserve(entry.target); }
        }), {root:track, rootMargin:'0px ' + horizontalLead + 'px'});
        track.querySelectorAll('.slyme-product-card[data-product-id] img:not(.show-on-hover)').forEach(image => {
          if (!warmed.has(image) && !image.closest('[hidden]')) state.observer.observe(image);
        });
      };
      states.set(track, state);
      // Le catalogue émet déjà cet événement après l'insertion d'une collection différée.
      track.addEventListener('slyme:refresh', state.refresh);
      rowObserver.observe(track);
    });
    // Les produits apparentés et les collections en grille ne sont pas des carrousels horizontaux.
    const imageObserver = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { prepare(entry.target); imageObserver.unobserve(entry.target); }
    }), {rootMargin:verticalLead + 'px 0px'});
    verticalImages.forEach(image => imageObserver.observe(image));
  });
})();
