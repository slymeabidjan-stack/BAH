/* Header search: same product search endpoint, loaded without the catalogue controller. */
(()=>{
'use strict';
  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
const start=()=>{
const config=window.slymeHeaderSearch||{};if(!config.api||!config.home)return;
const home=new URL(config.home,location.href),api=new URL(config.api,location.href);
    const safeURL = (value, image = false) => {
      try {
        if (typeof value !== 'string' || !value.trim()) return '';
        const url = new URL(value, home);
        return /^https?:$/.test(url.protocol) && (image || url.origin === home.origin) ? url.href : '';
      } catch (_) { return ''; }
    };
    const request = async (route, parameters, signal) => {
      const url = api.searchParams.has('rest_route') ? new URL(api) : new URL(route, api);
      if (url.searchParams.has('rest_route')) url.searchParams.set('rest_route', api.searchParams.get('rest_route').replace(/\/?$/, '/') + route);
      Object.entries(parameters).forEach(([key, value]) => url.searchParams.set(key, value));
      const response = await fetch(url, {signal, credentials:'same-origin', cache:'no-store', priority:route === 'search' ? 'high' : 'low', headers:{Accept:'application/json'}});
      if (!response.ok) throw new Error('Catalogue indisponible');
      const result = await response.json();
      if (!Array.isArray(result)) throw new Error('Réponse invalide');
      return result;
    };
    const priceText = price => price && price.amount !== '' ? [price.label, price.amount, price.currency].filter(Boolean).join(' ') : 'Prix sur demande';

    const form = document.querySelector('#slyme-header-search-source .slyme-search');
    if (!form) return;
    const input = form.querySelector('input[type=search]');
    const results = form.querySelector('.slyme-search-results');
    const status = form.querySelector('.slyme-search-status');
    const cache = new Map();
    const keyFor = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()
      .replace(/\b(galaxy|iphone|pixel|note)(?=[a-z]?\d)/g,'$1 ')
      .replace(/\b([samfz])[\s-]+(\d{1,3})\b/g,'$1$2')
      .replace(/\b([a-z]+\d{1,3})\s*\+(?=\s|$)/g,'$1 plus ')
      .replace(/(\d)(ultra|plus|fe|edge|promax|pro|max|mini|lite|fold|flip)\b/g,'$1 $2')
      .replace(/\bpromax\b/g,'pro max')
      .replace(/\b(?:telephones?|smartphones?)\b/g,'smartphone').replace(/\bordinateurs?\b/g,'ordinateur')
      .replace(/\bmontres?\b/g,'montre').replace(/\btablettes?\b/g,'tablette')
      .replace(/(\d+)\s*(?:gb|go)\b/g,'$1go').replace(/(\d+)\s*(?:tb|to)\b/g,'$1to')
      .replace(/[^a-z0-9]+/g,' ').trim();
    const fresh = saved => saved && Date.now()-saved.time<30000;
    const accessory = value => /\b(?:coques?|housses?|etuis?|cases?|covers?|films?|antichocs?|protecteurs?|protections?|protege|verre trempe|chargeurs?|cables?|adaptateurs?|claviers?|keyboards?|pencil|stylets?|bracelets?|straps?|supports?|pieces?|telecommandes?|remote|remplacement|rechange|spare|replacement|batteries?|battery|vitres?|ecran (?:lcd|oled|amoled|pour|de remplacement))\b/.test(value);
    const previewFor = key => {
      const tokens=key.split(' '), products=[], accessories=[], seen=new Set(), wantsAccessory=accessory(key);
      // Only reuse fresh server responses; previews never become cached responses.
      for(const saved of [...cache.values()].reverse()){
        if(!fresh(saved))continue;
        for(const product of saved.products){
          const url=safeURL(product.url);
          const identity=product.id ? 'id:'+String(product.id) : url;
          if(!url||typeof product.name!=='string'||seen.has(identity)||seen.has(url))continue;
          const title=keyFor(product.name),words=title.split(' ');
          if(!tokens.every(token=>words.some(word=>/\d/.test(token)||token.length<3 ? word===token : word.startsWith(token))))continue;
          seen.add(identity);seen.add(url);
          (wantsAccessory||!accessory(title)?products:accessories).push(product);
          if(products.length===8)return products;
        }
      }
      return products.concat(accessories).slice(0,8);
    };
    let debounce = 0, controller = null, sequence = 0, selected = -1, composing = false, shownTerm = '', selecting = false, pendingKey = '', shownPreview = false;
    const close = () => {
      results.hidden = true; selected = -1;
      input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant');
      status.textContent = '';shownPreview=false;
    };
    const cancel = () => {
      clearTimeout(debounce); debounce=0; pendingKey=''; sequence++;
      if (controller) { controller.abort(); controller=null; }
      form.removeAttribute('aria-busy');
    };
    let renderedResults = '';
    const show = (products, term, preview = false) => {
      const nextTerm=keyFor(term), keepPosition=!results.hidden && shownTerm===nextTerm;
      const previousScroll=keepPosition?results.scrollTop:0;
      const items=products.slice(0,8).filter(product=>safeURL(product.url)&&typeof product.name==='string');
      const signature=JSON.stringify(items.map(product=>[safeURL(product.url),product.name,safeURL(product.image,true),product.srcset||'',priceText(product.price)]));
      const unchanged=signature===renderedResults;
      const entering=results.hidden;
      shownTerm=nextTerm;shownPreview=preview;
      status.textContent=preview?'Premiers résultats. Recherche en cours…':items.length?items.length+' produit'+(items.length>1?'s proposés.':' proposé.'):'Aucun produit trouvé.';
      // Keep decoded images, focused links and reading position when validation
      // confirms the same visible results. Prices remain part of the comparison.
      if(unchanged){
        results.hidden=false;input.setAttribute('aria-expanded','true');
        if(!keepPosition){selected=-1;input.removeAttribute('aria-activedescendant');results.querySelectorAll('[aria-selected=true]').forEach(node=>node.setAttribute('aria-selected','false'));results.scrollTop=0;}
        if(entering)results.dispatchEvent(new CustomEvent('slyme:enter',{bubbles:true}));
        return;
      }
      renderedResults=signature;
      const fragment=document.createDocumentFragment();
      selected = -1; shownTerm = nextTerm;shownPreview=preview;
      input.removeAttribute('aria-activedescendant');
      items.forEach((product, index) => {
        const url = safeURL(product.url);
        if (!url || typeof product.name !== 'string') return;
        const option = create('li');
        option.id = results.id + '-' + index;
        option.setAttribute('role', 'option'); option.setAttribute('aria-selected', 'false');
        const link = create('a', 'slyme-search-result'); link.href = url;
        const photo = create('img'); if (product.srcset) {photo.srcset=product.srcset;photo.sizes='54px';} const photoURL=safeURL(product.image, true);if(photoURL)photo.src=photoURL;else photo.hidden=true; photo.alt = ''; photo.width = 48; photo.height = 48; photo.loading = 'lazy'; photo.addEventListener('error',()=>{photo.style.visibility='hidden';},{once:true});
        const description = create('span');
        description.append(create('span', 'slyme-search-name', product.name), create('span', 'slyme-search-price', priceText(product.price)));
        link.append(photo, description); option.append(link); fragment.append(option);
      });
      const count = fragment.children.length;
      if (!count) { const empty = create('li', 'slyme-search-empty', 'Aucun produit trouvé. Essaie un autre nom.'); empty.setAttribute('role', 'presentation'); fragment.append(empty); }
      results.replaceChildren(fragment);
      results.hidden = false; input.setAttribute('aria-expanded', 'true');
      results.scrollTop=previousScroll;
      if(entering)results.dispatchEvent(new CustomEvent('slyme:enter',{bubbles:true}));
    };
    const search = async () => {
      const term = input.value.trim(), key = keyFor(term);
      if (key.length < 2) { close(); return; }
      const saved=cache.get(key);
      if(fresh(saved)){show(saved.products,term);return;}
      const current = ++sequence;
      controller = new AbortController();
      const active = controller;
      // Some valid shop responses take over 8 seconds; keep the partial results usable.
      const timeout = setTimeout(() => active.abort(), 12000);
      form.setAttribute('aria-busy', 'true');status.textContent=shownPreview?'Premiers résultats. Recherche en cours…':'Recherche en cours…';
      try {
        const products = await request('search', {search:term}, active.signal);
        if(current!==sequence||keyFor(input.value)!==key)return;
        cache.delete(key);cache.set(key,{time:Date.now(),products});
        if(cache.size>12)cache.delete(cache.keys().next().value);
        if(sheet?.open||form.contains(document.activeElement)||selecting)show(products,term);
      } catch (_) {
        if (current === sequence && keyFor(input.value)===key && (sheet?.open||form.contains(document.activeElement)||selecting)) {
          if(shownPreview && !results.hidden && shownTerm===key){status.textContent='Résultats partiels. Validez la recherche pour voir tous les produits.';}
          else {close(); renderedResults='';results.replaceChildren(create('li','slyme-search-empty','Suggestions indisponibles. Utilisez le bouton de recherche pour afficher les résultats.')); results.hidden=false; input.setAttribute('aria-expanded','true'); status.textContent='Suggestions indisponibles.';}
        }
      } finally {
        clearTimeout(timeout);
        if (current === sequence) { form.removeAttribute('aria-busy'); controller=null; pendingKey=''; }
      }
    };
    const schedule = () => {
      const key=keyFor(input.value);
      // Repeated focus/input events and trailing spaces must not restart the same request.
      if (!composing && key.length>=2 && key===pendingKey && (debounce || controller)) return;
      const saved=cache.get(key);
      if (!composing && !results.hidden && shownTerm===key && fresh(saved)) return;
      cancel(); close(); selected=-1;input.removeAttribute('aria-activedescendant');
      results.querySelectorAll('[aria-selected=true]').forEach(e=>e.setAttribute('aria-selected','false'));
      if(key.length<2){close();return;}
      if(!composing){
        status.textContent='Recherche en cours…';
        if(fresh(saved)){search();}
        else {
          const preview=previewFor(key);if(preview.length)show(preview,input.value,true);
          pendingKey=key;debounce=setTimeout(()=>{debounce=0;search();},180);
        }
      }
    };
    input.addEventListener('compositionstart', () => { composing = true; cancel(); });
    input.addEventListener('compositionend', () => { composing = false; schedule(); });
    input.addEventListener('input', schedule);
    let trigger = null, sheet = null, marker = null, sheetClosing = false, scrollLock = null;
    const managedStyle = name => /^(?:overflow(?:-[xy])?|scrollbar-gutter|padding(?:-.+)?)$/.test(name);
    const lockBackground = () => {
      const root=document.documentElement, before=root.clientWidth, computed=getComputedStyle(root);
      const original=[];
      for(let i=0;i<root.style.length;i++){const name=root.style[i];if(managedStyle(name))original.push([name,root.style.getPropertyValue(name),root.style.getPropertyPriority(name)]);}
      const body=document.body, bodyNames=['position','top','left','width','overflow'];
      const bodyOriginal=bodyNames.map(name=>[name,body.style.getPropertyValue(name),body.style.getPropertyPriority(name)]);
      scrollLock={original,bodyOriginal,x:window.scrollX,y:window.scrollY};
      const paddingRight=parseFloat(computed.paddingRight)||0;
      // Reserve only an existing scrollbar. Pages without one must not gain an empty gutter.
      if(innerWidth>before && window.CSS?.supports('scrollbar-gutter','stable') && !computed.scrollbarGutter?.includes('stable'))root.style.setProperty('scrollbar-gutter','stable','important');
      root.style.setProperty('overflow','hidden','important');
      const lostGutter=Math.max(0,root.clientWidth-before);
      // Older browsers without stable gutters keep the same content width through padding.
      if(lostGutter)root.style.setProperty('padding-right',(paddingRight+lostGutter)+'px','important');
      // Keep the document still while the mobile keyboard reduces the visible viewport.
      body.style.setProperty('position','fixed','important');
      body.style.setProperty('top',-scrollLock.y+'px','important');
      body.style.setProperty('left',-scrollLock.x+'px','important');
      body.style.setProperty('width','100%','important');
      body.style.setProperty('overflow','hidden','important');
    };
    const unlockBackground = () => {
      if(!scrollLock)return;
      const root=document.documentElement, state=scrollLock;scrollLock=null;
      state.bodyOriginal.forEach(([name,value,priority])=>{if(value)document.body.style.setProperty(name,value,priority);else document.body.style.removeProperty(name);});
      const names=[];for(let i=0;i<root.style.length;i++)if(managedStyle(root.style[i]))names.push(root.style[i]);
      names.forEach(name=>root.style.removeProperty(name));
      state.original.forEach(([name,value,priority])=>root.style.setProperty(name,value,priority));
      if(window.scrollX!==state.x||window.scrollY!==state.y)window.scrollTo({left:state.x,top:state.y,behavior:'instant'});
    };
    let viewportFrame=0, viewportHeight=-1, viewportTop=-1;
    const resizeSheet = () => {
      viewportFrame=0;
      if (!sheet?.open) return;
      const height=window.visualViewport?.height || innerHeight;
      const top=window.visualViewport?.offsetTop || 0;
      if(height!==viewportHeight){sheet.style.setProperty('--slyme-search-height',height+'px');viewportHeight=height;}
      if(top!==viewportTop){sheet.style.setProperty('--slyme-search-top',top+'px');viewportTop=top;}
    };
    const scheduleViewport = () => {if(sheet?.open&&!viewportFrame)viewportFrame=requestAnimationFrame(resizeSheet);};
    const closeSheet = () => {
      if (!sheet?.open) return;
      sheetClosing = true; cancel(); close(); input.blur(); sheet.close();
      cancelAnimationFrame(viewportFrame);viewportFrame=0;
      marker.replaceWith(form); marker = null;
      unlockBackground();
      setTimeout(() => { sheetClosing = false; trigger?.focus({preventScroll:true}); }, 0);
    };
    const openSheet = () => {
      if (sheetClosing || sheet?.open || !('HTMLDialogElement' in window)) return;
      if (!sheet) {
        sheet = create('dialog','slyme-search-sheet');
        sheet.setAttribute('aria-labelledby', input.id + '-sheet-title');
        const header = create('header','slyme-search-sheet-header');
        const title = create('h2','slyme-search-sheet-title','Rechercher un produit'); title.id=input.id+'-sheet-title';
        const button = create('button','slyme-search-sheet-close','×'); button.type='button'; button.setAttribute('aria-label','Fermer la recherche');
        button.addEventListener('click',closeSheet); header.append(title,button); sheet.append(header); document.body.append(sheet);
        sheet.addEventListener('cancel', event => { event.preventDefault(); closeSheet(); });
        sheet.addEventListener('click', event => { if(event.target===sheet){const r=sheet.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeSheet();} });
        window.visualViewport?.addEventListener('resize',scheduleViewport,{passive:true});
        window.visualViewport?.addEventListener('scroll',scheduleViewport,{passive:true});
        window.addEventListener('pagehide',closeSheet);
      }
      marker=document.createComment('slyme-search-position'); form.before(marker); sheet.append(form);
      lockBackground(); sheet.showModal(); resizeSheet(); input.focus({preventScroll:true});
    };
    input.addEventListener('focus', () => {if(sheetClosing)return;openSheet();if(input.value.trim().length>=2)schedule();});
    input.addEventListener('keydown', event => {
      if (event.isComposing) return;
      if (event.key === 'Escape') { event.preventDefault();cancel(); close(); if(sheet?.open)closeSheet(); return; }
      const options = [...results.querySelectorAll('[role=option]')];
      if (!results.hidden && shownTerm===keyFor(input.value) && options.length && ['ArrowDown','ArrowUp'].includes(event.key)) {
        event.preventDefault();
        selected = selected < 0 ? (event.key === 'ArrowDown' ? 0 : options.length-1) : (selected + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length;
        options.forEach((option, index) => option.setAttribute('aria-selected', String(index === selected)));
        input.setAttribute('aria-activedescendant', options[selected].id);
        const row=options[selected];if(row.offsetTop<results.scrollTop)results.scrollTop=row.offsetTop;else if(row.offsetTop+row.offsetHeight>results.scrollTop+results.clientHeight)results.scrollTop=row.offsetTop+row.offsetHeight-results.clientHeight;
      } else if (event.key === 'Enter' && !results.hidden && shownTerm===keyFor(input.value) && selected >= 0 && options[selected]) {
        event.preventDefault(); options[selected].querySelector('a').click();
      }
    });
    // Garder la suggestion sous le doigt jusqu’au clic ; le flou ne doit pas la supprimer.
    results.addEventListener('pointerdown', event => {
      selecting=true;
      if(event.pointerType==='mouse'&&event.target.closest('a'))event.preventDefault();
    });
    results.addEventListener('pointerup', () => setTimeout(()=>{selecting=false;if(!sheet?.open&&!form.contains(document.activeElement))close();},300));
    results.addEventListener('pointercancel',()=>{selecting=false;});
    results.addEventListener('click',event=>{if(event.target.closest('a'))cancel();});
    form.addEventListener('submit', () => { cancel();  });
    form.addEventListener('focusout', event => {
      if(!sheet?.open&&!selecting&&!form.contains(event.relatedTarget)){cancel();close();}
    });
    document.addEventListener('pointerdown', event => {
      // La recherche fermée ne doit pas modifier le DOM à chaque geste sur la page.
      if(sheet?.open||(results.hidden&&!controller&&!debounce))return;
      if (!form.contains(event.target)) { selecting=false;cancel();close(); }
    }, {passive:true});
    // Handles delayed script execution after the customer's first tap.
    if(document.activeElement===input){openSheet();if(input.value.trim().length>=2)schedule();}
    document.addEventListener('click', event=>{
      const icon=event.target.closest('[data-slyme-search-open]');
      if(!icon||event.button||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||!('HTMLDialogElement' in window))return;
      event.preventDefault();trigger=icon;openSheet();
    });
};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
