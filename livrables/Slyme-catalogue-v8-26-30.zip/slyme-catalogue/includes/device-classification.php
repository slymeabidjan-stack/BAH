<?php
/** Famille réelle prioritaire sur les catégories erronées ; aucune taxonomie créée. */
defined('ABSPATH') || exit;
final class Slyme_Device_Classification {
    public static function patterns() {
        static $patterns = null;
        if ($patterns !== null) return $patterns;
        // Syntaxe commune aux REGEXP MySQL/MariaDB et à PCRE : aucun lookbehind ni \b.
        $models = array(
            'cartouches-encres' => 'cartouche[s]?|toner[s]?|encre[s]?|epson[[:space:]-]*10[123]|canon[[:space:]-]*(gi[[:space:]-]*[0-9]+|papier[[:space:]-]*photo[[:space:]-]*encre)',
            'imprimantes' => 'imprimante[s]?|printer[s]?|canon[[:space:]-]*(selphy|imagerunner)|epson[[:space:]-]*(ecotank|lx[[:space:]-]*[0-9]+)|hp[[:space:]-]*(color[[:space:]-]*)?laser(jet)?',
            'bureautique' => 'dymo[[:space:]-]*labelmanager|[ée]tiqueteuse[s]?|scanner[s]?',
            'logiciels-informatiques' => 'kaspersky|antivirus',
            'memoire-ram' => '^ram[[:space:]-]*[0-9]+([[:space:]-]*(gb|go))?|^m[ée]moire[[:space:]-]*(vive|ram)',
            'aspirateurs' => 'aspirateur[s]?|xiaomi[[:space:]-]*(vacuum[[:space:]-]*cleaner|robot[[:space:]-]*vacuum)|robot[[:space:]-]*vacuum',
            'serveurs-nas' => 'synology[[:space:]-]*(diskstation|rackstation)|serveur[s]?[[:space:]-]*nas',
            'serveurs' => 'serveur[s]?|hpe?[[:space:]-]*proliant|lenovo[[:space:]-]*thinksystem|dell[[:space:]-]*poweredge',
            'accessoires' => '^(coque[s]?|housse[s]?|[ée]tui[s]?|case[s]?|cover[s]?|film[s]?|antichoc[s]?|protecteur[s]?|protection[s]?|prot[èe]ge|verre[[:space:]-]*tremp[ée]|chargeur[s]?|c[aâ]ble[s]?|adaptateur[s]?|clavier[s]?|keyboard[s]?|pencil|stylet[s]?|focus[[:space:]-]*pen|bracelet[s]?|strap[s]?|support[s]?|pi[èe]ce[s]?|t[ée]l[ée]commande[s]?|remote|remplacement|rechange|spare|replacement|batterie[s]?|battery|vitre[s]?|[ée]cran[[:space:]-]*(lcd|oled|amoled|pour|de[[:space:]-]*remplacement)|hub[[:space:]-]*usb|((samsung[[:space:]-]*)?galaxy[[:space:]-]*)?smarttag[[:space:]-]*[0-9]*|airtag[[:space:]-]*[0-9]*|xiaomi[[:space:]-]*focus[[:space:]-]*pen|redmi[[:space:]-]*pad[[:space:]-]*pro[[:space:]-]*keyboard|((samsung[[:space:]-]*)?galaxy|ipad)[[:space:]-]*.*[[:space:]-]keyboard)',
            'stockage' => '^(ssd|disque[s]?[[:space:]-]*dur[s]?|cl[ée][[:space:]-]*usb|sandisk[[:space:]-]*(extreme|ultra[[:space:]-]*flair)|seagate[[:space:]-]*expansion|teamgroup[[:space:]-]*cx2[[:space:]-]*ssd|kingston[[:space:]-]*dc[0-9]+[a-z]?|seagate[[:space:]-]*exos)',
            'tablettes' => 'ipad([[:space:]-]*(pro|air|mini|m[0-9]+|[0-9]+))*|(samsung[[:space:]-]*)?galaxy[[:space:]-]*tab|(samsung[[:space:]-]*)?galaxy[[:space:]-]*s(9|10)[[:space:]-]*fe|lenovo[[:space:]-]*everypad[[:space:]-]*[0-9]*|lenovo[[:space:]-]*(tab|yoga[[:space:]-]*tab)|xiaomi[[:space:]-]*pad|redmi[[:space:]-]*pad|honor[[:space:]-]*(magic[[:space:]-]*)?pad[[:space:]-]*[0-9]*|huawei[[:space:]-]*matepad|oneplus[[:space:]-]*pad|google[[:space:]-]*pixel[[:space:]-]*tablet|tablette[s]?',
            'ordinateurs-bureau' => 'imac|mac[[:space:]-]*(mini|studio|pro)|ordinateur[s]?[[:space:]-]*(de[[:space:]-]*)?bureau|pc[[:space:]-]*(de[[:space:]-]*)?bureau|desktop|mini[[:space:]-]*pc|all[[:space:]-]*in[[:space:]-]*one|tout[[:space:]-]*en[[:space:]-]*un|hp[[:space:]-]*(elite[[:space:]-]*(desk|mini)|pro[[:space:]-]*desk|pro[[:space:]-]*tower|pro[[:space:]-]*(3500|sff[[:space:]-]*[0-9]+|mini[[:space:]-]*[0-9]+)|290[[:space:]-]*g9|bureau[[:space:]-]*290)|lenovo[[:space:]-]*(ideacentre|thinkcentre|thinkstation)|dell[[:space:]-]*optiplex|alienware[[:space:]-]*aurora[[:space:]-]*r[0-9]+',
            'ordinateurs-portables' => 'ordinateur[s]?[[:space:]-]*portable[s]?|pc[[:space:]-]*portable[s]?|laptop[s]?|macbook|surface[[:space:]-]*(laptop|pro)|thinkpad|zenbook|vivobook|dell[[:space:]-]*(1[4567][[:space:]-]*dc[0-9]+|vostro[[:space:]-]*([0-9]{2}[[:space:]-]*)?[0-9]{4}|xps|latitude|precision[[:space:]-]*[357][0-9]{3}|inspiron[[:space:]-]*[0-9]{4})|acer[[:space:]-]*(swift|aspire|nitro|predator)|alienware[[:space:]-]*[0-9]{2}[[:space:]-]*aurora|asus[[:space:]-]*(tuf[[:space:]-]*gaming|rog[[:space:]-]*(strix|zephyrus))|hp[[:space:]-]*(zbook|elitebook|probook|omnibook|spectre|envy[[:space:]-]*(x360|ultra|1[34567])|pavilion[[:space:]-]*(x360|1[4567][a-z]?|intel|ryzen)|omen[[:space:]-]*(slim|max|1[45678])|victus[[:space:]-]*(1[56]|intel)|1[4567][[:space:]-]*(pouces|ef[0-9]+[a-z]*|fd[0-9]+[a-z]*))|lenovo[[:space:]-]*(thinkbook|ideapad|legion[[:space:]-]*[579]|v1[45]|yoga[[:space:]-]*([679]|ultra))|msi[[:space:]-]*(cyborg|thin|katana|sword|stealth|modern|prestige|vector|raider)',
            'smartphones' => 'iphone[[:space:]-]*([0-9]+([[:space:]-]*(pro|max|plus|mini|air|e))*|se)|(google[[:space:]-]*)?pixel[[:space:]-]*([0-9]+[a]?([[:space:]-]*(pro|xl|fold))*|fold)|((samsung[[:space:]-]*)?galaxy[[:space:]-]*|samsung[[:space:]-]*)([samf][[:space:]-]*[0-9]+([[:space:]-]*(ultra|plus|fe|edge))*|(z[[:space:]-]*)?tri[[:space:]-]*fold([[:space:]-]*[0-9]+)?|z[[:space:]-]*(fold|flip)[[:space:]-]*[0-9]+([[:space:]-]*(ultra|fe))*)|z[[:space:]-]*(fold|flip)[[:space:]-]*[0-9]+([[:space:]-]*(ultra|fe))*|(xiaomi|redmi[[:space:]-]*note|redmi[[:space:]-]*[a]?|poco[[:space:]-]*[fmx])[[:space:]-]*[0-9]+[a-z]?([[:space:]-]*(pro|max|ultra|plus|lite|power))*|huawei[[:space:]-]*(mate[[:space:]-]*x[t]?|mate|pura|nova)[[:space:]-]*[0-9]*[a-z]?([[:space:]-]*(pro|max|ultra|plus|lite))*|honor[[:space:]-]*(magic[[:space:]-]*v?[[:space:]-]*[0-9]+|[0-9]+|x[[:space:]-]*[0-9]+)[a-z]?([[:space:]-]*(pro|lite|plus))*|oneplus[[:space:]-]*[0-9]+[a-z]?|blackview[[:space:]-]*bv[0-9]+',
            'montres' => '(apple|galaxy|redmi|xiaomi|huawei|oneplus|honor([[:space:]-]*choice)?|google[[:space:]-]*pixel)[[:space:]-]*watch[0-9]*|mibro[[:space:]-]*(watch[[:space:]-]*)?lite[[:space:]-]*[0-9]+|(xiaomi|huawei|honor|redmi)[[:space:]-]*(smart[[:space:]-]*)?band[[:space:]-]*[0-9]+[a-z]?|amazfit[[:space:]-]*(bip|gtr|gts|balance|t[[:space:]-]*rex)|google[[:space:]-]*fitbit[[:space:]-]*air|montre[s]?[[:space:]-]*connect[ée]e[s]?',
            'audio' => 'airpods|aipods|((galaxy|redmi|google[[:space:]-]*pixel)[[:space:]-]*buds[0-9]*)|huawei[[:space:]-]*(freebu(ds|s)|freeclip)|honor([[:space:]-]*choice)?[[:space:]-]*earbuds|xiaomi[[:space:]-]*(earbuds|buds|sound[[:space:]-]*pocket)|sony[[:space:]-]*(wh|wf)[[:space:]-]*[0-9]+[a-z0-9]*|jbl[[:space:]-]*(flip|charge|xtreme|boombox)[[:space:]-]*[0-9]+|[ée]couteur[s]?|enceinte[s]?|casque[s]?',
            'televisions' => 't[ée]l[ée]viseur[s]?|smart[[:space:]-]*tv|(xiaomi|samsung|lg|tcl|hisense)[[:space:]-]*tv|tv[[:space:]-]*(box|stick)',
            'ecrans' => 'moniteur[s]?|[ée]cran[s]?[[:space:]-]*(hp|gamer|gaming|incurv[ée]|samsung|lg|aoc|dell|asus|lenovo|philips)|[ée]cran[s]?[[:space:]-]*(d[[:space:]-]*)?ordinateur|monitor[s]?',
            'cameras' => 'cam[ée]ra[s]?[[:space:]-]*(de[[:space:]-]*)?surveillance|xiaomi[[:space:]-]*(smart|outdoor)[[:space:]-]*camera|webcam[s]?',
            'reseau' => 'routeur[s]?|router[s]?|switch[[:space:]-]*[0-9]+|cl[ée][[:space:]-]*wi[[:space:]-]*fi|huawei[[:space:]-]*(wifi[[:space:]-]*ax[0-9]+|b315|ws5200)|tp[[:space:]-]*link[[:space:]-]*(eap[0-9]+|tl[[:space:]-]*(sg|mr)[0-9]+[a-z]*)',
            'onduleurs' => 'onduleur[s]?|ups[[:space:]-]*[0-9]+|smart[[:space:]-]*ups'
        );
        $patterns = array();
        foreach ($models as $key => $model) $patterns[$key] = '(^|[^[:alnum:]])(' . $model . ')([^[:alnum:]]|$)';
        return $patterns;
    }

    public static function accessory_pattern() {
        // Prudence : un titre contenant un modèle peut désigner sa coque ou une pièce.
        return '(^|[^[:alnum:]])(coque[s]?|housse[s]?|[ée]tui[s]?|case[s]?|cover[s]?|film[s]?|antichoc[s]?|protecteur[s]?|protection[s]?|prot[èe]ge|verre[[:space:]-]*tremp[ée]|chargeur[s]?|c[aâ]ble[s]?|adaptateur[s]?|clavier[s]?|keyboard[s]?|pencil|stylet[s]?|bracelet[s]?|strap[s]?|support[s]?|pi[èe]ce[s]?|t[ée]l[ée]commande[s]?|remote|remplacement|rechange|spare|replacement|batterie[s]?|battery|vitre[s]?|[ée]cran[[:space:]-]*(lcd|oled|amoled|pour|de[[:space:]-]*remplacement))([^[:alnum:]]|$)';
    }

    /** Exact slugs for catalogue names that omit their device family. No guessed ID. */
    private static function reviewed_slugs() {
        return array(
            'hp-intel-core-i7-16-go' => 'ordinateurs-portables',
            'hp-intel-core-i7-tactile-16-go-ram' => 'ordinateurs-portables',
            'hp-core-i3-12gb-ram-512gb-ssd' => 'ordinateurs-portables',
            'hp-intel-core-i5' => 'ordinateurs-portables',
            'pack-2-en-1-du-redmi-note-14-pro-4g' => 'accessoires'
        );
    }

    public static function classification_sql() {
        global $wpdb;
        static $sql = array();
        $table = $wpdb->posts;
        if (isset($sql[$table])) return $sql[$table];
        $title_column = $table . '.post_title';
        foreach (array('–','—','‑','−') as $dash) $title_column = $wpdb->prepare('REPLACE(' . $title_column . ', %s, %s)', $dash, '-');
        $cases = array();
        foreach (self::reviewed_slugs() as $slug => $section) {
            $cases[] = $wpdb->prepare('WHEN ' . $table . '.post_name = %s THEN %s', $slug, $section);
        }
        // Same first-match order as PHP, including consumables/accessories before devices.
        foreach (self::patterns() as $section => $pattern) {
            $cases[] = $wpdb->prepare('WHEN LOWER(' . $title_column . ') REGEXP %s THEN %s', $pattern, $section);
        }
        return $sql[$table] = '(CASE ' . implode(' ', $cases) . " ELSE '' END)";
    }

    public static function recognized_sql($key) {
        global $wpdb;
        if (!isset(self::patterns()[$key])) return '0=1';
        return $wpdb->prepare(self::classification_sql() . ' = %s', $key);
    }

    public static function classify_title($title, $slug = '') {
        if (!is_scalar($title) || !is_scalar($slug)) return '';
        $title = str_replace(array('–','—','‑','−'), '-', html_entity_decode((string) $title, ENT_QUOTES, 'UTF-8'));
        $reviewed = self::reviewed_slugs();
        if (isset($reviewed[(string) $slug])) return $reviewed[(string) $slug];
        foreach (self::patterns() as $key => $pattern) {
            if (preg_match('~' . $pattern . '~iu', (string) $title)) return $key;
        }
        return '';
    }
}
