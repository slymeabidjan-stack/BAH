<?php
/** Un seul panier WooCommerce, partagé par l'en-tête et la confirmation. */
defined('ABSPATH') || exit;
final class Slyme_Cart_Sync {
    const SESSION = 'slyme_cart_additions';
    private static $request_token = '';
    public static function boot() {
        add_action('woocommerce_add_to_cart', array(__CLASS__, 'record_addition'), 25, 6);
        add_action('wc_ajax_slyme_cart_state', array(__CLASS__, 'state_endpoint'));
        add_action('wc_ajax_slyme_cart_undo', array(__CLASS__, 'undo_endpoint'));
        add_action('wc_ajax_slyme_cart_add', array(__CLASS__, 'add_endpoint'));
        add_action('wp_loaded', array(__CLASS__, 'guard_add_endpoint'), 0);
        add_action('sinatra_header_widgets_before_right', array(__CLASS__, 'header'));
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_filter('woocommerce_add_to_cart_fragments', array(__CLASS__, 'fragments'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 20);
        add_shortcode('slyme_header_cart', array(__CLASS__, 'header_html'));
    }
    private static function cart() {
        return function_exists('WC') && WC()->cart ? WC()->cart : null;
    }
    private static function session() {
        return function_exists('WC') && WC()->session ? WC()->session : null;
    }
    private static function token($value) {
        return is_string($value) && preg_match('/^[a-f0-9]{32}$/', $value) ? $value : '';
    }
    private static function additions() {
        $session = self::session();
        $saved = $session ? $session->get(self::SESSION, array()) : array();
        $saved = is_array($saved) ? $saved : array();
        // Historique court par client, jamais un cache global de paniers.
        foreach ($saved as $key => $item) {
            if (!is_array($item) || empty($item['time']) || $item['time'] < time() - DAY_IN_SECONDS) unset($saved[$key]);
        }
        return $saved;
    }
    public static function record_addition($key, $product_id, $quantity, $variation_id = 0, $variation = array(), $data = array()) {
        $cart = self::cart(); $session = self::session();
        if (!$cart || !$session || !$cart->get_cart_item($key)) return;
        $requested = isset($_POST['sls_cart_token']) ? wp_unslash($_POST['sls_cart_token']) : '';
        $token = self::token($requested);
        if (!$token) {
            if (!self::$request_token) self::$request_token = bin2hex(random_bytes(16));
            $token = self::$request_token;
        }
        self::$request_token = $token;
        $saved = self::additions();
        if (!isset($saved[$token])) $saved[$token] = array('time' => time(), 'items' => array(), 'used' => false);
        $item = $cart->get_cart_item($key); $amount = max(0, (float) $quantity);
        if (isset($saved[$token]['items'][$key])) $saved[$token]['items'][$key]['quantity'] += $amount;
        else $saved[$token]['items'][$key] = array('quantity' => $amount, 'before' => max(0, (float) $item['quantity'] - $amount));
        // Les premières opérations peuvent expirer sans toucher au contenu du panier.
        $session->set(self::SESSION, array_slice($saved, -30, null, true));
        $session->set('slyme_cart_latest', $token);
    }
    public static function confirmation_token() {
        $requested = isset($_POST['sls_cart_token']) ? wp_unslash($_POST['sls_cart_token']) : '';
        return self::token($requested) ?: self::$request_token;
    }
    public static function addition($token) {
        $saved = self::additions();
        return isset($saved[$token]) && empty($saved[$token]['used']) ? $saved[$token] : null;
    }
    /** This route calls the native handler once, only after verifying the request. */
    public static function guard_add_endpoint() {
        if (isset($_GET['wc-ajax']) && is_string($_GET['wc-ajax']) && 'slyme_cart_add' === sanitize_text_field(wp_unslash($_GET['wc-ajax']))) {
            remove_action('wp_loaded', array('WC_Form_Handler', 'add_to_cart_action'), 20);
        }
    }
    public static function add_endpoint() {
        nocache_headers();
        if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? '')) wp_send_json_error(array('message' => 'Méthode non autorisée.'), 405);
        $nonce = isset($_POST['security']) && is_string($_POST['security']) ? wp_unslash($_POST['security']) : '';
        // A 403 is returned strictly before the native cart handler can run.
        if (!wp_verify_nonce($nonce, 'slyme_cart_change')) wp_send_json_error(array('message' => 'Votre session a expiré. Réessayez.'), 403);
        $result = self::add_from_form($_POST);
        if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message(), 'cartState' => self::state()), 409);
        wp_send_json_success($result);
    }
    /** Lightweight response; WooCommerce still owns validation and the actual addition. */
    public static function add_from_form($data) {
        $cart = self::cart(); $session = self::session();
        if (!$cart || !$session || !is_callable(array('WC_Form_Handler', 'add_to_cart_action'))) return new WP_Error('cart_unavailable', 'Le panier est momentanément indisponible. Réessayez.');
        $token = self::token(isset($data['sls_cart_token']) ? wp_unslash($data['sls_cart_token']) : '');
        $id = $data['sls_product_id'] ?? '';
        if (!$token || !is_scalar($id) || !preg_match('/^[1-9][0-9]*$/', (string) $id)) return new WP_Error('invalid_addition', 'Rechargez la fiche produit avant de réessayer.');
        $saved = self::additions();
        if (isset($saved[$token])) {
            if (!empty($saved[$token]['used'])) return new WP_Error('already_removed', 'Cet ajout a déjà été supprimé. Vérifiez votre panier.');
            foreach ($saved[$token]['items'] as $key => $item) {
                if (!$cart->get_cart_item($key)) return new WP_Error('already_removed', 'Cet article a déjà été retiré. Vérifiez votre panier.');
            }
            return array('token' => $token, 'cartState' => self::state());
        }
        $product = wc_get_product(absint($id));
        if (!$product || !$product->is_type(array('simple', 'variable')) || 'publish' !== $product->get_status() || post_password_required($product->get_id())) return new WP_Error('unavailable_product', 'Ce produit n’est plus disponible à la commande.');
        if (isset($data['quantity']) && (!is_scalar($data['quantity']) || !is_numeric($data['quantity']) || !is_finite((float) $data['quantity']) || (float) $data['quantity'] <= 0)) return new WP_Error('invalid_quantity', 'Choisissez une quantité valide.');
        if (isset($data['variation_id']) && (!is_scalar($data['variation_id']) || !preg_match('/^[0-9]+$/', (string) $data['variation_id']))) return new WP_Error('invalid_variation', 'Choisissez à nouveau les options du produit.');
        foreach ($data as $key => $value) {
            if (0 === strpos($key, 'attribute_') && !is_scalar($value)) return new WP_Error('invalid_attribute', 'Choisissez à nouveau les options du produit.');
        }
        $previous_request = $_REQUEST; $previous_post = $_POST;
        $previous_notices = wc_get_notices();
        $no_redirect = static function () { return false; };
        $no_cart_redirect = static function () { return 'no'; };
        $errors = array(); $failed = false;
        try {
            $_POST = $data; $_REQUEST = $data;
            $_POST['add-to-cart'] = $_REQUEST['add-to-cart'] = absint($id);
            wc_clear_notices();
            add_filter('woocommerce_add_to_cart_redirect', $no_redirect, PHP_INT_MAX);
            add_filter('pre_option_woocommerce_cart_redirect_after_add', $no_cart_redirect, PHP_INT_MAX);
            WC_Form_Handler::add_to_cart_action();
            $errors = wc_get_notices('error');
        } catch (Throwable $error) {
            $failed = true;
        } finally {
            remove_filter('woocommerce_add_to_cart_redirect', $no_redirect, PHP_INT_MAX);
            remove_filter('pre_option_woocommerce_cart_redirect_after_add', $no_cart_redirect, PHP_INT_MAX);
            $_REQUEST = $previous_request; $_POST = $previous_post;
            wc_set_notices($previous_notices);
        }
        // A hook may throw after adding: report the recorded cart change, never guess.
        if (self::addition($token)) return array('token' => $token, 'cartState' => self::state());
        $message = 'L’ajout n’a pas été confirmé. Vérifiez votre panier avant de réessayer.';
        if (!$failed && $errors) {
            $messages = array();
            foreach ($errors as $error) {
                $notice = is_array($error) ? ($error['notice'] ?? '') : $error;
                if (is_string($notice)) $messages[] = html_entity_decode(wp_strip_all_tags($notice), ENT_QUOTES, 'UTF-8');
            }
            if ($messages) $message = implode(' ', $messages);
        }
        return new WP_Error('addition_unconfirmed', $message);
    }
    public static function state() {
        $cart = self::cart(); $session = self::session();
        $latest = $session ? self::token($session->get('slyme_cart_latest', '')) : '';
        return array('count' => $cart ? $cart->get_cart_contents_count() : 0,
            'cart' => wc_get_cart_url(), 'hash' => $cart ? $cart->get_cart_hash() : '',
            'nonce' => wp_create_nonce('slyme_cart_change'),
            'token' => $latest && self::addition($latest) ? $latest : '');
    }
    public static function state_endpoint() {
        nocache_headers();
        wp_send_json_success(self::state());
    }
    /** Return an error code or success; mutation only accepts this customer's operation. */
    public static function undo($token) {
        $token = self::token($token); $cart = self::cart(); $session = self::session();
        $saved = self::additions();
        if (!$token || !$cart || !$session || !isset($saved[$token])) return new WP_Error('unknown_addition', 'Cet ajout ne peut pas être retrouvé. Ouvrez le panier pour vérifier son contenu.');
        if (!empty($saved[$token]['used'])) return true;
        foreach ($saved[$token]['items'] as $key => $added) {
            $item = $cart->get_cart_item($key);
            if (!$item) continue;
            $current = (float) $item['quantity'];
            // Garder les quantités qui étaient présentes avant cet ajout.
            $remove = min((float) $added['quantity'], max(0, $current - (float) $added['before']));
            if ($remove <= 0) continue;
            $next = $current - $remove;
            $removed = $next <= 0 ? $cart->remove_cart_item($key) : $cart->set_quantity($key, $next, false);
            if (!$removed) return new WP_Error('remove_failed', 'La suppression n’a pas été confirmée. Vérifiez votre panier.');
            $after_operation = false;
            foreach ($saved as $other_token => &$other) {
                if ($other_token === $token) { $after_operation = true; continue; }
                if ($after_operation && empty($other['used']) && isset($other['items'][$key])) $other['items'][$key]['before'] = max(0, (float) $other['items'][$key]['before'] - $remove);
            }
            unset($other);
        }
        $saved[$token]['used'] = true;
        $session->set(self::SESSION, $saved);
        $cart->calculate_totals();
        return true;
    }
    public static function undo_endpoint() {
        nocache_headers();
        if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? '')) wp_send_json_error(array('message' => 'Méthode non autorisée.'), 405);
        $nonce = isset($_POST['security']) && is_string($_POST['security']) ? wp_unslash($_POST['security']) : '';
        if (!wp_verify_nonce($nonce, 'slyme_cart_change')) wp_send_json_error(array('message' => 'Votre session a expiré. Réessayez.'), 403);
        $token = isset($_POST['token']) ? wp_unslash($_POST['token']) : '';
        $result = self::undo($token);
        if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()), 409);
        wp_send_json_success(self::state());
    }
    public static function body_class($classes) {
        if (function_exists('WC')) $classes[] = 'slyme-cart-header';
        return $classes;
    }
    public static function header_html($attributes = array()) {
        if (!function_exists('WC')) return '';
        $cart = self::cart(); $count = $cart ? $cart->get_cart_contents_count() : 0;
        $label = 'Panier — ' . $count . ($count > 1 ? ' articles' : ' article');
        return '<a class="sls-header-cart-link" data-sls-header-cart href="' . esc_url(wc_get_cart_url()) . '" aria-label="' . esc_attr($label) . '"><svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3h2l2.4 11.5a2 2 0 0 0 2 1.5H18a2 2 0 0 0 2-1.6L22 7H6"/><circle cx="10" cy="21" r="1"/><circle cx="19" cy="21" r="1"/></svg><span class="sls-header-cart-count" aria-hidden="true">' . esc_html($count > 99 ? '99+' : $count) . '</span></a>';
    }
    public static function header() {
        if (function_exists('WC')) echo '<div class="si-header-widget sls-header-cart">' . Slyme_Catalogue_V6::header_search_icon() . self::header_html() . '</div>';
    }
    public static function fragments($fragments) {
        $fragments['a.sls-header-cart-link'] = self::header_html();
        return $fragments;
    }
    private static function search_url() { return Slyme_Catalogue_V6::search_home(); }
    public static function assets() {
        if (!function_exists('WC')) return;
        $base = plugin_dir_url(dirname(__FILE__)) . 'assets/';
        wp_enqueue_style('slyme-header-search', $base . 'header-search-8-26-29.css', array(), Slyme_Catalogue_V6::VERSION);
        wp_enqueue_script('slyme-header-search', $base . 'header-search-8-26-29.js', array(), Slyme_Catalogue_V6::VERSION, array('in_footer'=>true, 'strategy'=>'defer'));
        wp_add_inline_script('slyme-header-search', 'window.slymeHeaderSearch=' . wp_json_encode(array('home'=>self::search_url(), 'api'=>rest_url('slyme/v1/'))) . ';', 'before');
        wp_enqueue_style('slyme-cart-sync', $base . 'cart-sync-8-26-29.css', array(), Slyme_Catalogue_V6::VERSION);
        wp_enqueue_script('slyme-cart-sync', $base . 'cart-sync-8-26-29.js', array(), Slyme_Catalogue_V6::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_add_inline_script('slyme-cart-sync', 'window.slymeCartConfig=' . wp_json_encode(array('state' => WC_AJAX::get_endpoint('slyme_cart_state'), 'undo' => WC_AJAX::get_endpoint('slyme_cart_undo'), 'add' => WC_AJAX::get_endpoint('slyme_cart_add'), 'authenticated' => is_user_logged_in())) . ';', 'before');
    }
}
