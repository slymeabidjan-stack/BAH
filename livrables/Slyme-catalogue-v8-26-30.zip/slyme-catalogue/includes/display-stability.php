<?php
/** Same font weights on every device; critical logo rendered without deferred loading. */
defined('ABSPATH') || exit;
final class Slyme_Display_Stability {
    public static function boot() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 30);
        add_action('wp_head', array(__CLASS__, 'preload'), 2);
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_filter('sinatra_logo_img_output', array(__CLASS__, 'logo'), 99);
        add_filter('get_custom_logo', array(__CLASS__, 'logo'), 99);
    }
    private static function base() { return plugin_dir_url(dirname(__FILE__)) . 'assets/'; }
    public static function body_class($classes) { $classes[] = 'slyme-stable-ui'; return $classes; }
    public static function assets() {
        wp_enqueue_style('slyme-display-stability', self::base() . 'display-stability-8-26-29.css', array(), Slyme_Catalogue_V6::VERSION);
        if (function_exists('is_product') && is_product()) {
            // Flexslider expands its strip before assigning slide widths (100 ms).
            // Reserve the real first-photo ratio during that interval only.
            wp_add_inline_script('wc-single-product', <<<'JS'
(function($){
    if(!$)return;
    $(document).on('wc-product-gallery-before-init.slymeStableGallery','body.theme-sinatra.single-product .woocommerce-product-gallery',function(){
        var image=this.querySelector('.woocommerce-product-gallery__wrapper .wp-post-image');
        var width=Number(image && image.getAttribute('width'));
        var height=Number(image && image.getAttribute('height'));
        if(Number.isFinite(width) && Number.isFinite(height) && width>0 && height>0){
            this.style.setProperty('--sls-gallery-ratio',width+'/'+height);
        }else{
            this.style.removeProperty('--sls-gallery-ratio');
        }
    });
})(window.jQuery);
JS
            , 'before');
        }
    }
    public static function preload() {
        echo '<link data-no-optimize="1" rel="preload" href="' . esc_url(self::base() . 'fonts/slyme-ui-latin-v1.woff2') . '" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    }
    public static function logo($html) {
        if (!is_string($html) || !class_exists('WP_HTML_Tag_Processor')) return $html;
        $tags = new WP_HTML_Tag_Processor($html);
        while ($tags->next_tag('IMG')) {
            $tags->set_attribute('loading', 'eager');
            $tags->set_attribute('fetchpriority', 'high');
            $tags->set_attribute('data-no-lazy', '1');
            $tags->add_class('slyme-critical-logo');
            $tags->add_class('skip-lazy');
            // Preserve the theme's source, srcset, dimensions, alternative text and link.
        }
        return $tags->get_updated_html();
    }
}
