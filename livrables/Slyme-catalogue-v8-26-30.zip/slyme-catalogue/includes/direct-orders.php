<?php
/** Commandes sur place : prix et stock vérifiés par WooCommerce, notification asynchrone. */
defined('ABSPATH') || exit;
class Slyme_Order_Price_Changed extends Exception {
    public $amount;
    public function __construct($amount, $display) { $this->amount = (float) $amount; parent::__construct('Le total actualisé est de ' . $display . '. Vérifiez ce montant puis cliquez à nouveau sur Commander pour le confirmer.'); }
}
final class Slyme_Direct_Orders {
    public static function boot() {
        add_action('wc_ajax_slyme_direct_session', array(__CLASS__, 'session_endpoint'));
        add_action('wc_ajax_slyme_direct_order', array(__CLASS__, 'order_endpoint'));
        add_action('slyme_direct_notify', array(__CLASS__, 'notify'), 10, 1);
        add_action('slyme_direct_unlock', array(__CLASS__, 'unlock'), 10, 1);
        add_action('admin_init', array(__CLASS__, 'settings'));
        add_action('slyme_catalogue_settings_fields', array(__CLASS__, 'fields'));
        add_action('admin_notices', array(__CLASS__, 'notice'));
    }
    private static function session() {
        if (!function_exists('WC') || !WC()->session) throw new Exception('La commande est momentanément indisponible. Réessayez.');
        WC()->session->set_customer_session_cookie(true);
        return (string) WC()->session->get_customer_id();
    }
    public static function session_endpoint() {
        nocache_headers();
        try { $id = self::session(); wp_send_json_success(array('nonce' => wp_create_nonce('slyme_direct_' . $id))); }
        catch (Exception $e) { wp_send_json_error(array('message' => $e->getMessage()), 503); }
    }
    private static function text($data, $key, $max = 500) {
        $value = isset($data[$key]) && is_scalar($data[$key]) ? sanitize_textarea_field((string) $data[$key]) : '';
        return function_exists('mb_substr') ? mb_substr(trim($value), 0, $max) : substr(trim($value), 0, $max);
    }
    /** Validate identifiers, attributes and quantity without trusting any browser price. */
    public static function selection($data) {
        $id = absint(self::text($data, 'product_id', 20));
        $parent = wc_get_product($id);
        if (!$parent || 'publish' !== $parent->get_status() || post_password_required($id) || get_post_field('post_password', $id) || !in_array($parent->get_catalog_visibility(), array('visible','catalog'), true)) throw new Exception('Ce produit n’est plus disponible.');
        if (!$parent->is_type(array('simple', 'variable'))) throw new Exception('Utilisez le panier pour commander ce produit.');
        $product = $parent; $attributes = array();
        if ($parent->is_type('variable')) {
            $product = wc_get_product(absint(self::text($data, 'variation_id', 20)));
            if (!$product || !$product->is_type('variation') || $product->get_parent_id() !== $id || !$product->variation_is_active() || !$product->variation_is_visible()) throw new Exception('Choisissez une capacité et une couleur disponibles.');
            $posted = isset($data['attributes']) && is_array($data['attributes']) ? $data['attributes'] : array();
            foreach ($parent->get_variation_attributes() as $name => $options) {
                $key = 'attribute_' . sanitize_title($name);
                $value = self::text($posted, $key, 200);
                if ('' === $value || !in_array($value, $options, true)) throw new Exception('Choisissez toutes les options du produit.');
                $attributes[$key] = $value;
            }
            foreach ($product->get_variation_attributes() as $key => $value) {
                if ('' !== $value && (!isset($attributes[$key]) || $attributes[$key] !== $value)) throw new Exception('Les options sélectionnées ne correspondent plus. Sélectionnez-les à nouveau.');
            }
        }
        $qty = self::text($data, 'customer_quantity', 10);
        if (!preg_match('/^[1-9][0-9]*$/', $qty) || (int) $qty > 999) throw new Exception('Choisissez une quantité entière entre 1 et 999.');
        $qty = (int) $qty;
        if (!$product->is_purchasable() || !$product->is_in_stock() || !$product->has_enough_stock($qty) || ($product->is_sold_individually() && $qty !== 1)) throw new Exception('La quantité demandée n’est plus disponible.');
        return array($product, $qty, $attributes);
    }
    public static function delivery($key) {
        $modes = array('abidjan' => array('Abidjan', 2000), 'express' => array('Express Abidjan', 3000), 'expedition' => array('Expédition — frais à confirmer', 0));
        if (!isset($modes[$key])) throw new Exception('Choisissez le mode de livraison.');
        return $modes[$key];
    }
    public static function unlock($key) {
        if (is_string($key) && preg_match('/^slyme_do_[a-f0-9]{64}$/', $key)) delete_option($key);
    }
    private static function result($order) {
        $quote = 'expedition' === $order->get_meta('_slyme_delivery');
        return array('number' => $order->get_order_number(), 'total' => html_entity_decode(wp_strip_all_tags(wc_price($order->get_total(), array('currency' => $order->get_currency()))), ENT_QUOTES, 'UTF-8'), 'expedition' => $quote);
    }
    public static function order_endpoint() {
        nocache_headers(); $lock = ''; $order = null; $accepted = false;
        try {
            if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') throw new Exception('Requête invalide.');
            $session = self::session(); $data = wp_unslash($_POST);
            if (!wp_verify_nonce(self::text($data, 'nonce', 100), 'slyme_direct_' . $session)) throw new Exception('Votre session a expiré. Fermez puis rouvrez le formulaire.');
            if ('XOF' !== get_woocommerce_currency()) throw new Exception('La commande directe nécessite les tarifs en FCFA. Veuillez utiliser le panier.');
            $token = self::text($data, 'request_id', 100);
            if (!preg_match('/^[a-f0-9]{32}$/', $token)) throw new Exception('Veuillez rouvrir le formulaire de commande.');
            $hash = hash_hmac('sha256', $session . '|' . $token, wp_salt('nonce'));
            // Durable idempotency: a retry after a lost response returns the same order.
            $existing = wc_get_orders(array('limit' => 1, 'meta_key' => '_slyme_direct_request', 'meta_value' => $hash));
            if ($existing) {
                if ($existing[0]->get_meta('_slyme_direct_accepted')) wp_send_json_success(self::result($existing[0]));
                throw new Exception('Cette commande est en cours de vérification. Réessayez dans quelques instants.');
            }
            $lock = 'slyme_do_' . $hash;
            if (!add_option($lock, time(), '', false)) { $lock = ''; throw new Exception('Commande en cours d’enregistrement. Réessayez dans quelques instants.'); }
            wp_schedule_single_event(time() + 300, 'slyme_direct_unlock', array($lock));
            // Check again inside the lock: another request may have finished while we waited.
            $existing = wc_get_orders(array('limit' => 1, 'meta_key' => '_slyme_direct_request', 'meta_value' => $hash));
            if ($existing) {
                self::unlock($lock); $lock = '';
                if ($existing[0]->get_meta('_slyme_direct_accepted')) wp_send_json_success(self::result($existing[0]));
                throw new Exception('Cette commande est en cours de vérification. Réessayez dans quelques instants.');
            }
            list($product, $quantity, $attributes) = self::selection($data);
            $delivery_key = self::text($data, 'customer_delivery', 30);
            list($delivery_name, $fee) = self::delivery($delivery_key);
            $last = self::text($data, 'customer_lastname', 80); $first = self::text($data, 'customer_firstname', 80);
            $phone = self::text($data, 'customer_phone', 24); $address = self::text($data, 'customer_address');
            if (!$last || !$first || !$address || !preg_match('/^(?:\+|00)?[\d\s().-]{7,24}$/', $phone) || !preg_match('/^\d{7,15}$/', preg_replace('/\D/', '', $phone))) throw new Exception('Vérifiez votre nom, prénom, téléphone et adresse.');
            // Rate limit is independent of a guest's session cookie; no raw IP is stored.
            $rate_key = 'slyme_do_rate_' . hash_hmac('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? ''), wp_salt());
            $count = (int) get_transient($rate_key);
            if ($count >= 5) throw new Exception('Plusieurs commandes ont déjà été reçues. Patientez quelques minutes avant de recommencer.');
            set_transient($rate_key, $count + 1, 10 * MINUTE_IN_SECONDS);
            $order = wc_create_order(array('customer_id' => get_current_user_id(), 'created_via' => 'slyme-direct', 'status' => 'pending'));
            if (is_wp_error($order)) { $order = null; throw new Exception('Impossible d’enregistrer la commande. Réessayez.'); }
            $order->set_currency('XOF');
            $contact = array('first_name' => $first, 'last_name' => $last, 'phone' => $phone, 'address_1' => $address, 'country' => 'CI');
            $order->set_address($contact, 'billing'); $order->set_address($contact, 'shipping');
            $order->set_customer_note(self::text($data, 'customer_note'));
            $order->add_product($product, $quantity, array('variation' => $attributes));
            $shipping = new WC_Order_Item_Shipping(); $shipping->set_method_title($delivery_name); $shipping->set_method_id('slyme_direct'); $shipping->set_total($fee);
            $order->add_item($shipping);
            $order->update_meta_data('_slyme_delivery', $delivery_key);
            $order->update_meta_data('_slyme_direct_request', $hash);
            if ('expedition' === $delivery_key) $order->add_order_note('Frais d’expédition à confirmer avec le client. Le total est provisoire, hors expédition.');
            $order->calculate_totals();
            // Shipping amounts are the advertised final fees, including any applicable shipping tax.
            if ($fee && (float) $shipping->get_total_tax() > 0) {
                $shipping->set_total($fee - (float) $shipping->get_total_tax()); $shipping->save(); $order->calculate_totals(false);
            }
            $expected = self::text($data, 'expected_total', 30);
            if (!is_numeric($expected) || abs((float) $expected - (float) $order->get_total()) > 0.01) {
                $total = self::result($order)['total'];
                throw new Slyme_Order_Price_Changed($order->get_total(), $total);
            }
            // Atomic WooCommerce stock reservation also checks competing purchases.
            wc_reserve_stock_for_order($order);
            $order->update_meta_data('_slyme_direct_accepted', 1);
            $order->save(); $accepted = true;
            $order->update_status('on-hold', 'Commande directe reçue. Aucun paiement en ligne ; confirmation par le service client.');
            wc_release_stock_for_order($order);
            $order->update_meta_data('_slyme_wa_state', 'queued'); $order->save();
            // API notification runs off the customer's critical path.
            if (function_exists('as_enqueue_async_action')) as_enqueue_async_action('slyme_direct_notify', array('order_id' => $order->get_id()), 'slyme');
            else wp_schedule_single_event(time() + 1, 'slyme_direct_notify', array($order->get_id()));
            self::unlock($lock); $lock = '';
            wp_send_json_success(self::result($order));
        } catch (Throwable $e) {
            if ($order && !$accepted) { wc_release_stock_for_order($order); $order->delete(true); }
            if ($lock) self::unlock($lock);
            if ($accepted && $order) { $order->add_order_note('Commande enregistrée. Vérifier le statut et la notification WhatsApp dans les notes.'); wp_send_json_success(self::result($order)); }
            $message = $e instanceof Exception && !($e instanceof Error) ? $e->getMessage() : 'Impossible d’enregistrer la commande. Réessayez.';
            $error = array('message' => $message);
            if ($e instanceof Slyme_Order_Price_Changed) $error['expected_total'] = $e->amount;
            wp_send_json_error($error, 400);
        }
    }
    private static function config() {
        return array('token' => defined('SLYME_WA_TOKEN') ? SLYME_WA_TOKEN : get_option('slyme_wa_token', ''), 'sender' => get_option('slyme_wa_sender', ''), 'version' => get_option('slyme_wa_version', 'v23.0'), 'template' => get_option('slyme_wa_template', ''), 'language' => get_option('slyme_wa_language', 'fr'), 'recipient' => get_option('slyme_whatsapp_number', '2250703283286'));
    }
    private static function configured() {
        $c = self::config();
        return $c['token'] && preg_match('/^\d+$/', $c['sender']) && preg_match('/^v\d+\.0$/', $c['version']) && preg_match('/^[a-z0-9_]+$/', $c['template']) && preg_match('/^[a-z]{2,3}(?:_[A-Z]{2})?$/', $c['language']) && preg_match('/^[1-9]\d{9,14}$/', $c['recipient']);
    }
    public static function notify($order_id) {
        $order = wc_get_order($order_id);
        if (!$order || !$order->get_meta('_slyme_direct_accepted') || $order->get_meta('_slyme_wa_state') !== 'queued') return;
        if (!self::configured()) { $order->update_meta_data('_slyme_wa_state', 'not_configured'); $order->save(); $order->add_order_note('WhatsApp non envoyé : configurez l’API dans Réglages → Slyme Catalogue. La commande est bien enregistrée.'); return; }
        $c = self::config();
        $products = array();
        foreach ($order->get_items() as $item) $products[] = $item->get_name() . ' × ' . $item->get_quantity() . ' ' . wc_display_item_meta($item, array('echo' => false, 'separator' => ' / '));
        $shipping = self::delivery($order->get_meta('_slyme_delivery'));
        $values = array($order->get_order_number(), trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()), $order->get_billing_phone(), implode(' ; ', $products), $order->get_shipping_address_1(), $shipping[0], self::result($order)['total'] . ('expedition' === $order->get_meta('_slyme_delivery') ? ' hors expédition' : ' livraison incluse'), $order->get_customer_note() ?: 'Aucune précision');
        $parameters = array_map(function($v) { $v = preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags((string) $v), ENT_QUOTES, 'UTF-8')); return array('type' => 'text', 'text' => function_exists('mb_substr') ? mb_substr($v, 0, 800) : substr($v, 0, 800)); }, $values);
        $order->update_meta_data('_slyme_wa_state', 'sending'); $order->save();
        $response = wp_remote_post('https://graph.facebook.com/' . $c['version'] . '/' . $c['sender'] . '/messages', array('timeout' => 15, 'headers' => array('Authorization' => 'Bearer ' . $c['token'], 'Content-Type' => 'application/json'), 'body' => wp_json_encode(array('messaging_product' => 'whatsapp', 'to' => $c['recipient'], 'type' => 'template', 'template' => array('name' => $c['template'], 'language' => array('code' => $c['language']), 'components' => array(array('type' => 'body', 'parameters' => $parameters)))))));
        $body = is_wp_error($response) ? array() : json_decode(wp_remote_retrieve_body($response), true);
        $ok = !is_wp_error($response) && wp_remote_retrieve_response_code($response) >= 200 && wp_remote_retrieve_response_code($response) < 300 && !empty($body['messages'][0]['id']);
        $order->update_meta_data('_slyme_wa_state', $ok ? 'accepted_by_meta' : 'failed'); $order->save();
        $order->add_order_note($ok ? 'Notification WhatsApp acceptée par Meta. La livraison effective n’est pas confirmée par ce plugin.' : 'Notification WhatsApp non confirmée. Vérifiez les identifiants, le modèle approuvé et le destinataire dans Meta. La commande reste disponible ici.');
    }
    public static function token_setting($value) { return is_string($value) && trim($value) ? sanitize_text_field(trim($value)) : get_option('slyme_wa_token', ''); }
    public static function settings() {
        foreach (array('sender','version','template','language') as $name) register_setting('slyme_catalogue', 'slyme_wa_' . $name, array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('slyme_catalogue', 'slyme_wa_token', array('sanitize_callback' => array(__CLASS__, 'token_setting')));
    }
    public static function fields() {
        echo '<h2>Commande directe et notification WhatsApp</h2><p>Les commandes sont enregistrées dans WooCommerce, sans quitter le site et sans paiement immédiat. L’envoi au magasin nécessite votre API WhatsApp Business et un modèle approuvé. Le destinataire est le numéro WhatsApp renseigné plus haut ; utilisez un destinataire distinct du numéro émetteur API.</p><table class="form-table">';
        $fields = array('sender' => array('ID du numéro émetteur Meta', ''), 'version' => array('Version Graph API de votre application', 'v23.0'), 'template' => array('Nom du modèle approuvé (8 variables de corps)', ''), 'language' => array('Langue exacte du modèle', 'fr'));
        foreach ($fields as $name => $field) echo '<tr><th><label for="slyme-wa-' . esc_attr($name) . '">' . esc_html($field[0]) . '</label></th><td><input id="slyme-wa-' . esc_attr($name) . '" class="regular-text" name="slyme_wa_' . esc_attr($name) . '" value="' . esc_attr(get_option('slyme_wa_' . $name, $field[1])) . '"></td></tr>';
        echo '<tr><th>Jeton d’accès Meta</th><td><input type="password" autocomplete="new-password" class="regular-text" name="slyme_wa_token" value="" placeholder="Laisser vide pour conserver le jeton"><p>Jamais envoyé au navigateur client. Vous pouvez aussi définir SLYME_WA_TOKEN dans wp-config.php.</p></td></tr></table><p>Corps du modèle à faire approuver (8 variables positionnelles, sans en-tête ni boutons obligatoires) :</p><pre>Nouvelle commande {{1}}. Client : {{2}}. Téléphone : {{3}}. Produit et quantité : {{4}}. Adresse : {{5}}. Livraison : {{6}}. Montant : {{7}}. Précisions : {{8}}.</pre><p>Le destinataire du magasin doit accepter ces notifications. L’envoi est traité en arrière-plan par les actions planifiées WooCommerce (ou WP-Cron). Consultez les notes de chaque commande pour son résultat.</p>';
    }
    public static function notice() {
        if (current_user_can('manage_options') && !self::configured()) echo '<div class="notice notice-warning"><p><strong>Slyme :</strong> les commandes directes sont enregistrées dans WooCommerce. Les notifications WhatsApp automatiques ne sont pas encore configurées : <a href="' . esc_url(admin_url('options-general.php?page=slyme-catalogue')) . '">connecter votre API WhatsApp Business</a>.</p></div>';
    }
}
