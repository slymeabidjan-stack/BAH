<?php
/** Achat sur les fiches WooCommerce classiques. Les calculs restent à WooCommerce. */
defined('ABSPATH') || exit;
final class Slyme_Product_Shopping {
    const OPTION = 'slyme_shopping_v1';
    public static function boot() {
        add_filter('wc_add_to_cart_message_html', array(__CLASS__, 'cart_message'));
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 25);
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'services'), 32);
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'store_location'), 33);
        add_action('wp_footer', array(__CLASS__, 'bar'), 20);
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('slyme_catalogue_settings_fields', array(__CLASS__, 'settings_fields'));
        add_action('slyme_presentation_extra_fields', array(__CLASS__, 'product_fields'), 10, 2);
        add_filter('slyme_presentation_sanitized', array(__CLASS__, 'sanitize_product'), 10, 2);
    }
    public static function cart_message($message) {
        $token=Slyme_Cart_Sync::confirmation_token();
        if(!$token||!Slyme_Cart_Sync::addition($token))return $message;
        return $message.'<span class="sls-cart-confirmed" data-sls-confirm="'.esc_attr($token).'" data-sls-cart-state="'.esc_attr(wp_json_encode(Slyme_Cart_Sync::state())).'" aria-hidden="true"></span>';
    }
    private static function settings() {
        $saved=get_option(self::OPTION,array());
        $saved=is_array($saved)?$saved:array();
        $services=is_array($saved['services']??null)?$saved['services']:array();
        // Mise à jour des seules valeurs livrées par défaut : les champs personnalisés
        // ou volontairement vidés restent inchangés, sans écriture dans les options.
        if('82620'!==($saved['services_version']??'')){
            if(($services['standard_delay']??null)==='Délai confirmé par le service client')$services['standard_delay']='4 h';
            if(($services['delay']??null)==='En moins d’1 h')$services['delay']='Moins d’1 h';
        }
        $saved['services']=wp_parse_args($services,self::service_defaults());
        return wp_parse_args($saved,array('bar'=>'1','visual'=>'1','summary'=>'0','color_map'=>'','services'=>array()));
    }
    private static function product() {
        if(!function_exists('is_product')||!is_product())return null;
        $product=wc_get_product(get_queried_object_id());
        return Slyme_Product_Presentation::enabled($product)?$product:null;
    }
    private static function clean($value,$limit=350) {
        if(!is_scalar($value))return '';
        $value=sanitize_text_field((string)$value);
        return function_exists('mb_substr')?mb_substr($value,0,$limit):substr($value,0,$limit);
    }
    private static function service_defaults() {
        return array('authenticity'=>'Produits authentiques','support'=>'Service après-vente','warranty'=>'12 mois','standard_delay'=>'4 h','delay'=>'Moins d’1 h','payment'=>'Espèces ou Mobile Money');
    }
    public static function service_schema() {
        return array(
            'authenticity'=>array('Authenticité','Engagement sur les produits affiché dans les avantages.','shield'),
            'support'=>array('Service après-vente','Accompagnement proposé après l’achat.','support'),
            'warranty'=>array('Garantie','Durée ou conditions de garantie affichées.','shield'),
            'standard_delay'=>array('Livraison standard','Délai standard commun aux blocs et au formulaire de commande.','charge'),
            'delay'=>array('Livraison express','Délai express commun aux blocs et au formulaire de commande.','charge'),
            'payment'=>array('Modes de paiement','Moyens de paiement annoncés. Ne change pas les passerelles WooCommerce.','payment')
        );
    }
    private static function clean_services($input) {
        $out=array();$input=is_array($input)?$input:array();
        foreach(self::service_schema() as $key=>$field)$out[$key]=self::clean($input[$key]??'');
        return $out;
    }
    public static function sanitize_settings($input) {
        $input=is_array($input)?$input:array();$out=array();
        foreach(array('bar','visual') as $key)$out[$key]=isset($input[$key])&&'1'===$input[$key]?'1':'0';
        $lines=is_string($input['color_map']??null)?preg_split('/\R/u',$input['color_map']):array();$valid=array();
        foreach(array_slice($lines,0,80) as $line){$pair=explode('|',$line,2);if(count($pair)!==2)continue;$name=self::clean(trim($pair[0]),80);$hex=sanitize_hex_color(trim($pair[1]));if($name!==''&&$hex)$valid[]=$name.' | '.$hex;}
        $out['color_map']=implode("\n",$valid);$out['services']=self::clean_services($input['services']??array());$out['services_version']='82620';return $out;
    }
    public static function sanitize_product($out,$input) {
        $input=is_array($input['services']??null)?$input['services']:array();
        $out['services']=self::clean_services($input);
        $out['services']['version']='82620';
        $out['services']['mode']=in_array($input['mode']??'',array('inherit','custom','off'),true)?$input['mode']:'inherit';
        return $out;
    }
    public static function register() {
        register_setting('slyme_catalogue',self::OPTION,array('type'=>'array','sanitize_callback'=>array(__CLASS__,'sanitize_settings'),'default'=>array()));
    }
    public static function settings_fields() {
        $settings=self::settings();
        echo '<h2>Achat et informations sur les fiches</h2>';
        foreach(array('bar'=>'Barre d’achat flottante sur mobile et ordinateur','visual'=>'Pastilles de couleur et boutons de capacité') as $key=>$label)echo '<p><input type="hidden" name="'.self::OPTION.'['.$key.']" value="0"><label><input type="checkbox" name="'.self::OPTION.'['.$key.']" value="1"'.checked($settings[$key],'1',false).'> '.esc_html($label).'</label></p>';
        echo '<h3>Les avantages Slyme — valeurs communes</h3><p>Par défaut : produits authentiques, service après-vente, garantie de 12 mois, livraison standard en 4 h, express en moins d’1 h, paiement en espèces ou Mobile Money. Un champ vidé reste masqué. Les informations personnalisées de chaque produit restent prioritaires. Ces textes ne changent pas les frais ni les moyens de paiement configurés dans WooCommerce.</p><table class="form-table">';
        foreach(self::service_schema() as $key=>$field)echo '<tr><th><label for="slyme-service-'.$key.'">'.esc_html($field[0]).'</label></th><td><input class="large-text" id="slyme-service-'.$key.'" type="text" maxlength="350" name="'.self::OPTION.'[services]['.$key.']" value="'.esc_attr($settings['services'][$key]??'').'"><p class="description">'.esc_html($field[1]).'</p></td></tr>';
        echo '</table><h3>Teintes des pastilles (facultatif)</h3><label for="slyme-color-map">Une teinte par ligne : nom exact de la couleur | code hexadécimal</label><p><textarea id="slyme-color-map" class="large-text code" rows="4" name="'.self::OPTION.'[color_map]">'.esc_textarea($settings['color_map']).'</textarea></p><p>Les couleurs usuelles sont reconnues. Les noms inconnus restent affichés en texte. Tu peux préciser ici tes teintes exactes. Les variantes, prix, stocks et photos se configurent dans WooCommerce, pas dans ces champs.</p>';
    }
    public static function product_fields($product,$data) {
        $services=$data['services']??array();$mode=$services['mode']??'inherit';
        if('custom'!==$mode||!in_array($services['version']??'',array('71','82620'),true))$services=self::settings()['services'];
        echo '<h3>Les avantages Slyme</h3><label class="slp-admin-wide">Informations à afficher<select name="slyme_presentation[services][mode]" data-sls-service-mode>';
        foreach(array('inherit'=>'Utiliser les informations communes de la boutique','custom'=>'Renseigner les informations de ce produit','off'=>'Masquer sur ce produit') as $value=>$label)echo '<option value="'.$value.'"'.selected($mode,$value,false).'>'.esc_html($label).'</option>';
        echo '</select></label><p>Les valeurs communes se règlent dans Réglages → Slyme Catalogue. En mode personnalisé, seuls les champs remplis ci-dessous apparaissent. Ces textes ne changent pas les frais WooCommerce.</p><div class="slp-admin-grid" data-sls-service-fields>';
        foreach(self::service_schema() as $key=>$field)echo '<label>'.esc_html($field[0]).'<input type="text" maxlength="350" name="slyme_presentation[services]['.$key.']" value="'.esc_attr($services[$key]??'').'"><span>'.esc_html($field[1]).'</span></label>';
        echo '</div>';
    }
    public static function body_class($classes) {
        if(self::product())$classes[]='slyme-product-shopping';
        return $classes;
    }
    public static function assets() {
        if(function_exists('is_woocommerce') && (is_woocommerce() || is_cart() || is_checkout())) {
            $feedback=plugin_dir_url(dirname(__FILE__)).'assets/';
            wp_enqueue_style('slyme-cart-feedback',$feedback.'cart-feedback-8-26-29.css',array(),Slyme_Catalogue_V6::VERSION);
            wp_enqueue_script('slyme-cart-feedback',$feedback.'cart-feedback-8-26-29.js',array('jquery','slyme-cart-sync'),Slyme_Catalogue_V6::VERSION,array('in_footer'=>true,'strategy'=>'defer'));
            wp_add_inline_script('slyme-cart-feedback','window.slymeCartFeedback='.wp_json_encode(array('cart'=>wc_get_cart_url(),'checkout'=>wc_get_checkout_url(),'shop'=>wc_get_page_permalink('shop'))).';','before');
        }
        if (function_exists('is_product') && is_product()) wp_enqueue_style('slyme-store-location', plugin_dir_url(dirname(__FILE__)).'assets/store-location-8-26-29.css', array(), Slyme_Catalogue_V6::VERSION);
        $product=self::product();if(!$product)return;
        $base=plugin_dir_url(dirname(__FILE__)).'assets/';$settings=self::settings();
        wp_enqueue_style('slyme-product-description',$base.'product-description-8-26-29.css',array(),Slyme_Catalogue_V6::VERSION);
        wp_enqueue_style('slyme-product-shopping',$base.'product-shopping-8-26-29.css',array(),Slyme_Catalogue_V6::VERSION);
        if('1'!==$settings['visual']&&'1'!==$settings['bar'])return;
        $deps=$product->is_type('variable')?array('jquery','wc-add-to-cart-variation','slyme-cart-sync'):array('slyme-cart-sync');
        wp_enqueue_script('slyme-product-shopping',$base.'product-shopping-8-26-29.js',$deps,Slyme_Catalogue_V6::VERSION,array('in_footer'=>true,'strategy'=>'defer'));
        $colors=array();foreach(explode("\n",$settings['color_map']) as $line){$pair=explode('|',$line,2);if(count($pair)===2)$colors[trim($pair[0])]=trim($pair[1]);}
        wp_add_inline_script('slyme-product-shopping','window.slymeShopping='.wp_json_encode(array('visual'=>'1'===$settings['visual'],'colors'=>$colors,'money'=>array('decimals'=>wc_get_price_decimals(),'decimal'=>wc_get_price_decimal_separator(),'thousand'=>wc_get_price_thousand_separator(),'format'=>get_woocommerce_price_format(),'symbol'=>get_woocommerce_currency_symbol()))).';','before');
    }
    /** Single source for service blocks, legacy delivery copy and order form delays. */
    public static function effective_services($product=null) {
        $data=$product?$product->get_meta(Slyme_Product_Presentation::META,true):array();
        $custom=is_array($data)&&is_array($data['services']??null)?$data['services']:array();
        $mode=$custom['mode']??'inherit';
        if('off'===$mode)return array();
        $services='custom'===$mode&&in_array($custom['version']??'',array('71','82620'),true)?$custom:self::settings()['services'];
        return self::clean_services($services);
    }
    public static function delivery_info($product=null) {
        $services=self::effective_services($product);
        return array('abidjan'=>$services['standard_delay']??'', 'express'=>$services['delay']??'', 'expedition'=>empty($services)?'':'Délai et frais confirmés par le service client.');
    }
    private static function benefit_icon($name) {
        $paths=array(
            'authenticity'=>'<path d="m12 3 7 3v6c0 4-7 9-7 9S5 16 5 12V6Z"/><path d="m8.5 11.5 2.5 2.5 4.5-5"/>',
            'support'=>'<path d="M4 13v-1a8 8 0 0 1 16 0v1M4 13H3v5h4v-7H4Zm16 0h1v5h-4v-7h3ZM20 18c0 2-2 3-5 3h-3"/>',
            'warranty'=>'<circle cx="12" cy="9" r="6"/><path d="m8 14-1 7 5-3 5 3-1-7m-7-5 2 2 4-4"/>',
            'delivery'=>'<path d="M3 5h11v12H3zM14 10h4l3 4v3h-7M3 9h7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
            'payment'=>'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M7 15h3"/>'
        );
        return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'.($paths[$name]??$paths['authenticity']).'</svg>';
    }
    public static function services() {
        $product=self::product();if(!$product)return;
        $services=self::effective_services($product);
        if(!array_filter($services,'strlen'))return;
        echo '<section class="sls-services sls-benefits" aria-labelledby="sls-benefits-title"><h2 id="sls-benefits-title">Les avantages d’acheter chez <span>Slyme Abidjan CI</span></h2>';
        $benefits=array();
        foreach(array('authenticity','support','warranty') as $key){
            if(empty($services[$key]))continue;
            $label=$services[$key];
            if('warranty'===$key)$label=preg_match('/^[0-9]/u',$label)?'Garantie de '.$label:'Garantie : '.$label;
            $benefits[$key]=$label;
        }
        if($benefits){
            echo '<ul class="sls-benefit-list">';
            foreach($benefits as $key=>$label)echo '<li><span class="sls-benefit-icon">'.self::benefit_icon($key).'</span><strong>'.esc_html($label).'</strong></li>';
            echo '</ul>';
        }
        $has_delivery=!empty($services['standard_delay'])||!empty($services['delay']);
        if($has_delivery||!empty($services['payment'])){
            echo '<div class="sls-benefit-details">';
            if($has_delivery){
                echo '<div class="sls-benefit-detail"><h3><span class="sls-benefit-mini-icon">'.self::benefit_icon('delivery').'</span>Délais de livraison</h3><dl class="sls-delivery-times">';
                foreach(array('standard_delay'=>'Standard','delay'=>'Express') as $key=>$label)if(!empty($services[$key]))echo '<div><dt>'.esc_html($label).' :</dt><dd>'.esc_html($services[$key]).'</dd></div>';
                echo '</dl></div>';
            }
            if(!empty($services['payment']))echo '<div class="sls-benefit-detail"><h3><span class="sls-benefit-mini-icon">'.self::benefit_icon('payment').'</span>Paiement à la livraison</h3><p class="sls-benefit-payment">'.esc_html($services['payment']).'</p></div>';
            echo '</div>';
        }
        echo '</section>';
    }
    public static function store_location() {
        if (!function_exists('is_product') || !is_product() || !wc_get_product(get_queried_object_id())) return;
        $url = 'https://maps.app.goo.gl/iWbDntKxwQAmWCKK8?g_st=ic';
        echo '<section class="sls-store-location" aria-label="Localisation du magasin"><span class="sls-store-pin" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg></span><div class="sls-store-copy"><h2>Localisation du magasin</h2><p>Retrouve-nous sur Google Maps.</p><a class="sls-store-map" href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">Voir sur Google Maps <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3h7v7M21 3l-11 11M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5"/></svg></a></div></section>';
    }

    public static function bar() {
        $product=self::product();if(!$product||'1'!==self::settings()['bar']||!$product->is_type(array('simple','variable')))return;
        if($product->is_type('simple')&&(!$product->is_purchasable()||!$product->is_in_stock()))return;
        $bar_price=$product->get_price_html();
        if($product->is_type('variable')){
            $min=$product->get_variation_price('min',true);$max=$product->get_variation_price('max',true);
            if(''!==$min&&''!==$max)$bar_price=(float)$min===(float)$max?wc_price($min):'<strong class="sls-from">À partir de</strong> '.wc_price($min);
        }
        // Inline et limité à la barre : reste présent même si un cache sert un ancien CSS externe.
        $bar_css=file_get_contents(dirname(__DIR__).'/assets/buybar-8-26-29.css');
        if(false!==$bar_css)echo '<style id="slyme-buybar-critical" data-no-optimize="1">'.$bar_css.'</style>';
        $rating='';
        if($product->get_rating_count()>0){$average=(float)$product->get_average_rating();$rating='<span class="sls-buybar-rating" style="--sls-rating:'.esc_attr(min(100,max(0,$average*20))).'%" role="img" aria-label="'.esc_attr('Note : '.$average.' sur 5, '.$product->get_rating_count().' avis').'">★★★★★</span>';}
        $image=$product->get_image('woocommerce_gallery_thumbnail',array('class'=>'sls-buybar-image','loading'=>'lazy','decoding'=>'async','sizes'=>'(min-width:768px) 112px, 48px','data-no-lazy'=>'1'));
        echo '<aside class="sls-buybar" data-sls-bar hidden aria-label="Achat rapide"><div class="sls-buybar-product">'.$image.'<div class="sls-buybar-info"><span class="sls-buybar-name">'.esc_html($product->get_name()).'</span><span class="sls-buybar-caption">'.($product->is_type('variable')?'Sélectionne tes options':'Ton prochain coup de cœur').'</span><span class="sls-buybar-status" role="status" aria-live="polite"></span>'.$rating.'</div></div><div class="sls-buybar-purchase"><div class="sls-buybar-price">'.wp_kses_post($bar_price).'</div><button type="button" class="sls-buybar-action"><svg width="17" height="17" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h2l2.4 11.5a2 2 0 0 0 2 1.5H18a2 2 0 0 0 2-1.6L22 7H6"/><circle cx="10" cy="21" r="1"/><circle cx="19" cy="21" r="1"/></svg><span>Je l’achète</span><svg class="sls-buybar-chevron" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg></button></div></aside>';
    }
}
