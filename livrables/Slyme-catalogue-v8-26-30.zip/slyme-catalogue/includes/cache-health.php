<?php
/** Visible build identity and a deliberate, authenticated cache refresh. */
defined('ABSPATH') || exit;
final class Slyme_Cache_Health {
    public static function boot() {
        add_action('send_headers', array(__CLASS__, 'headers'));
        add_action('wp_head', array(__CLASS__, 'meta'), 2);
        add_action('admin_post_slyme_refresh_cache', array(__CLASS__, 'refresh'));
        add_action('slyme_catalogue_after_settings_form', array(__CLASS__, 'settings'));
    }
    public static function headers() {
        if (!headers_sent()) header('X-Slyme-Version: ' . Slyme_Catalogue_V6::VERSION);
    }
    public static function meta() {
        echo '<meta name="slyme-version" content="' . esc_attr(Slyme_Catalogue_V6::VERSION) . '">' . "\n";
    }
    public static function refresh() {
        if (!current_user_can('manage_options')) wp_die('Accès non autorisé.', '', array('response'=>403));
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') wp_die('Requête non autorisée.', '', array('response'=>405));
        check_admin_referer('slyme_refresh_cache');
        Slyme_Catalogue_V6::clear_lists_cache();
        do_action('litespeed_purge_all');
        wp_safe_redirect(add_query_arg(array('page'=>'slyme-catalogue','slyme_cache_refreshed'=>'1'), admin_url('options-general.php')));
        exit;
    }
    public static function settings() {
        if (!current_user_can('manage_options')) return;
        echo '<h2>Accueil du magasin</h2><p>« À la une » affiche jusqu’à 5 cartes, dans cet ordre : iPhone 18 Pro Max, Galaxy Z TriFold, HONOR Magic V6, Google Pixel 11 Pro Fold, puis Xiaomi 17 Ultra. Les fiches choisies restent soumises aux règles de publication, de visibilité et de disponibilité de cette rubrique.</p><p>Dans « Smartphones », juste sous le cadre bleu des offres, les cinq premières cartes restent : Google Pixel 11, Samsung Galaxy Z Flip 8, Samsung Galaxy Z Fold 8, Samsung Galaxy S26 Ultra, puis iPhone 17 Pro Max. Les autres modèles suivent par prix décroissant, jusqu’à 12 cartes.</p><p>Les produits choisis pour une rubrique sont réservés avant que les autres rangées se complètent. Les modèles de « À la une » ne sont donc pas repris dans Smartphones, Nouveautés ou les offres. Chaque produit apparaît une seule fois sur l’accueil ; le grand slider reste prioritaire. Si une fiche manque ou ne peut pas être affichée, les autres gardent leur ordre et une autre fiche admissible peut compléter la rangée.</p><p>« Nouveautés du magasin » utilise jusqu’à 12 des 60 publications les plus récentes, toutes familles confondues, hors produits réservés. Les pages « Voir tout » restent complètes. Le cache, les images adaptées et le chargement progressif sont conservés.</p>';
        echo '<h2>Catégories et appareils</h2><p>La rangée sous le slider conserve ses quatre cartes et ajoute les rubriques configurées dont les catégories contiennent des produits, ainsi que les catégories principales WooCommerce manquantes. Aucune catégorie WooCommerce n’est créée. Les noms de modèles reconnus permettent aussi de retrouver les iPad dans Tablettes et les iPhone dans Smartphones, sans analyser leurs images ni modifier leurs catégories enregistrées.</p>';
        echo '<h2>Version et cache</h2><p>Version installée : <strong>' . esc_html(Slyme_Catalogue_V6::VERSION) . '</strong>. Le diagnostic affiche aussi la version de la page et de ses fichiers : une différence aide à repérer un ancien cache.</p>';
        if (isset($_GET['slyme_cache_refreshed'])) echo '<p>Les listes Slyme ont été réinitialisées et une demande de purge a été envoyée à LiteSpeed. Un cache externe à WordPress peut nécessiter une purge séparée.</p>';
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post"><input type="hidden" name="action" value="slyme_refresh_cache">';
        wp_nonce_field('slyme_refresh_cache');
        submit_button('Rafraîchir le cache du catalogue', 'secondary', 'submit', false);
        echo '</form><p>Une modification de produit actualise automatiquement les listes et demande une purge des pages du catalogue dans LiteSpeed. La mise à jour de l’extension demande une purge générale une seule fois. Utilise ce bouton si une ancienne version reste visible. Les paniers et commandes ne sont pas mis en cache par ce module.</p>';
    }
}
