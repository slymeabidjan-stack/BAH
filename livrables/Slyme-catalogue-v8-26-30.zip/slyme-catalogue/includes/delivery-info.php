<?php
/** Harmonise only the old delivery sentences, without changing stored descriptions. */
defined('ABSPATH') || exit;
final class Slyme_Delivery_Info {
    public static function boot() {
        add_filter('the_content',array(__CLASS__,'content'),25);
        add_filter('woocommerce_short_description',array(__CLASS__,'content'),25);
    }
    public static function content($html) {
        if(!is_string($html)||is_admin()||!class_exists('Slyme_Product_Shopping'))return $html;
        $is_product=function_exists('is_product')&&is_product();
        if(!$is_product&&!is_front_page())return $html;
        $product=$is_product?wc_get_product(get_queried_object_id()):null;
        $info=Slyme_Product_Shopping::delivery_info($product);
        // An individual product configured with hidden services stays hidden.
        if(!array_filter($info))return $html;
        return self::rewrite($html,$info,$is_product);
    }
    public static function rewrite($html,$info,$is_product=false) {
        if(stripos($html,'livraison')===false&&stripos($html,'Recevez')===false)return $html;
        $rules=array();
        if($is_product&&!empty($info['express'])) {
            $rules['~\bLivraison\s+express\s+en\s+moins\s+de\s+(?:2|deux)\s+heures\b~iu']='Livraison express : '.$info['express'];
        }
        if(!$is_product) {
            $parts=array();
            if(!empty($info['abidjan']))$parts[]='Livraison normale à Abidjan : '.rtrim($info['abidjan'],' .').'.';
            if(!empty($info['express']))$parts[]='Express à Abidjan : '.rtrim($info['express'],' .').'.';
            $parts[]='Expédition possible ; délai et frais confirmés par le service client.';
            $rules['~Recevez\s+votre\s+commande\s+sous\s+24\s+à\s+48\s+heures\s+à\s+Abidjan,\s+avec\s+un\s+suivi\s+clair\s+à\s+chaque\s+étape\.~u']=implode(' ',$parts);
        }
        if(!$rules)return $html;
        // Work only on visible text runs. Retain all tags, attributes and unrelated bytes.
        // Inline strong/span tags may split a sentence; block boundaries may not.
        $tokens=wp_html_split($html);$run=array();$blocked=0;
        foreach($tokens as $index=>$token) {
            if(isset($token[0])&&'<'===$token[0]) {
                if(preg_match('~^<(script|style|textarea|template)\b~i',$token))$blocked++;
                if(preg_match('~^</(?:script|style|textarea|template)\b~i',$token))$blocked=max(0,$blocked-1);
                if($blocked||!preg_match('~^</?(?:strong|b|em|i|span|small|u)\b[^>]*>$~i',$token))self::replace_run($tokens,$run,$rules);
            } elseif(!$blocked) {
                $run[$index]=html_entity_decode($token,ENT_QUOTES|ENT_HTML5,'UTF-8');
            }
        }
        self::replace_run($tokens,$run,$rules);
        return implode('',$tokens);
    }
    private static function replace_run(&$tokens,&$run,$rules) {
        if(!$run)return;
        $plain=implode('',$run);$segments=array();$offset=0;
        foreach($run as $index=>$text){$segments[$index]=array($offset,strlen($text));$offset+=strlen($text);}
        $matches=array();
        foreach($rules as $pattern=>$replacement) {
            if(preg_match_all($pattern,$plain,$found,PREG_OFFSET_CAPTURE))foreach($found[0] as $match)$matches[]=array($match[1],strlen($match[0]),$replacement);
        }
        usort($matches,static function($a,$b){return $b[0]<=>$a[0];});
        $changed=array();
        foreach($matches as $match) {
            foreach($segments as $index=>$segment) {
                $start=max($segment[0],$match[0]);$end=min($segment[0]+$segment[1],$match[0]+$match[1]);
                if($end<=$start)continue;
                $run[$index]=substr_replace($run[$index],$start===$match[0]?$match[2]:'',$start-$segment[0],$end-$start);
                $changed[$index]=true;
            }
        }
        foreach($changed as $index=>$unused)$tokens[$index]=esc_html($run[$index]);
        $run=array();
    }
}
