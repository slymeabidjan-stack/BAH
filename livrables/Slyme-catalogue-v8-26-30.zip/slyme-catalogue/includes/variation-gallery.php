<?php
/** Repair the verified Pixel 10 colour/photo assignments; WooCommerce owns the gallery. */
defined('ABSPATH') || exit;

final class Slyme_Variation_Gallery {
    const REPAIR_OPTION = 'slyme_pixel10_photo_repair_8265';
    const NOTICE_TRANSIENT = 'slyme_pixel10_photo_repair_notice_8265';

    public static function boot() {
        add_action('admin_init', array(__CLASS__, 'repair_verified_pixel'), 30);
        add_action('admin_notices', array(__CLASS__, 'repair_notice'));
        add_action('woocommerce_product_after_variable_attributes', array(__CLASS__, 'variation_note'), 10, 3);
    }

    /** No filename guessing: each photograph was visually checked against its colour. */
    private static function verified_map() {
        return array(
            3053 => array('colour' => 'bleu', 'image' => 3559, 'file' => '2025/09/img_5954.jpeg'),
            3054 => array('colour' => 'gris', 'image' => 3560, 'file' => '2025/09/img_5956.jpeg'),
            3055 => array('colour' => 'noir', 'image' => 3562, 'file' => '2025/09/img_5955.jpeg'),
            3056 => array('colour' => 'vert', 'image' => 3561, 'file' => '2025/09/img_5957.jpeg'),
        );
    }

    public static function repair_verified_pixel() {
        if (!function_exists('wc_get_product') || wp_doing_ajax()) return;
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) return;
        if (get_option(self::REPAIR_OPTION, false)) return;

        $product = wc_get_product(3052);
        if (!$product || !$product->is_type('variable') || $product->get_slug() !== 'google-pixel-10') return;
        if (!current_user_can('edit_post', 3052) || (int) $product->get_image_id('edit') !== 3561) return;

        $map = self::verified_map();
        $gallery = array_map('intval', array_merge(array($product->get_image_id('edit')), $product->get_gallery_image_ids()));
        $children = array_map('intval', $product->get_children());
        $variations = array();
        // Validate the whole known product before changing even one variation.
        foreach ($map as $id => $item) {
            if (!in_array($item['image'], $gallery, true) || !in_array($id, $children, true)) return;
            if (get_post_meta($item['image'], '_wp_attached_file', true) !== $item['file']) return;
            if (!wp_attachment_is_image($item['image'])) return;
            $variation = wc_get_product($id);
            if (!$variation || !$variation->is_type('variation') || (int) $variation->get_parent_id() !== 3052) return;
            $attributes = $variation->get_attributes();
            if (!isset($attributes['pa_couleur']) || $attributes['pa_couleur'] !== $item['colour']) return;
            if (!isset($attributes['pa_choisissez-la-capacite']) || $attributes['pa_choisissez-la-capacite'] !== '256-go') return;
            $variations[$id] = $variation;
        }

        $changed = array();
        $preserved = array();
        foreach ($map as $id => $item) {
            $variation = $variations[$id];
            // The edit context reads the actual assignment, not the inherited parent image.
            $before = (int) $variation->get_image_id('edit');
            if ($before !== 0 && $before !== 3561) {
                $preserved[$id] = $before;
                continue;
            }
            if ($before === $item['image']) continue;
            $variation->set_image_id($item['image']);
            $variation->save();
            $changed[$id] = array('before' => $before, 'after' => $item['image']);
        }
        if ($changed) {
            wc_delete_product_transients(3052);
            // Invalidate this product's HTML, never a customer's cart/session cache.
            do_action('litespeed_purge_post', 3052);
        }
        $report = array('product_id' => 3052, 'changed' => $changed, 'preserved' => $preserved, 'time' => time());
        // A bounded record also preserves the previous image IDs for manual rollback.
        update_option(self::REPAIR_OPTION, $report, false);
        set_transient(self::NOTICE_TRANSIENT, $report, HOUR_IN_SECONDS);
    }

    public static function repair_notice() {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) return;
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->id, array('plugins', 'product', 'edit-product'), true)) return;
        $report = get_transient(self::NOTICE_TRANSIENT);
        if (!is_array($report)) return;
        $count = count($report['changed']);
        $preserved = count($report['preserved']);
        echo '<div class="notice notice-success is-dismissible"><p><strong>Slyme — Photos des variantes :</strong> ';
        echo esc_html('Google Pixel 10 : ' . $count . ' association(s) de couleur corrigée(s). ');
        if ($preserved) echo esc_html($preserved . ' photo(s) déjà différente(s) conservée(s). ');
        echo esc_html('La galerie WooCommerce utilise maintenant les photos affectées à chaque variante.');
        echo '</p></div>';
        delete_transient(self::NOTICE_TRANSIENT);
    }

    /** Help avoid this data error on future colours without adding frontend JavaScript. */
    public static function variation_note($loop, $data, $post) {
        if (!isset($post->ID)) return;
        $variation = wc_get_product($post->ID);
        if (!$variation || !$variation->is_type('variation')) return;
        $has_colour = false;
        foreach ($variation->get_attributes() as $name => $value) {
            if ($value !== '' && preg_match('/(?:^|[_-])(couleurs?|colou?rs?|coloris)(?:$|[_-])/i', $name)) {
                $has_colour = true;
                break;
            }
        }
        if (!$has_colour || (int) $variation->get_image_id('edit') > 0) return;
        echo '<p class="form-row form-row-full description">';
        echo esc_html('Photo de cette couleur manquante : cliquez sur la photo de la variante ci-dessus pour choisir la bonne image. Sans cette association, WooCommerce affiche la photo générale du produit.');
        echo '</p>';
    }
}
