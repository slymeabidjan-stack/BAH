<?php
/** Une caractéristique courte et factuelle pour les cartes, sans charger les variantes. */
defined('ABSPATH') || exit;
final class Slyme_Card_Benefits {
    private static function labels() {
        return array('storage'=>'Stockage','memory'=>'Mémoire vive','battery'=>'Batterie','autonomy'=>'Autonomie','display'=>'Écran','processor'=>'Processeur','camera'=>'Photo','compatibility'=>'Compatibilité','material'=>'Matière','charging'=>'Recharge','connection'=>'Connectivité','capacity'=>'Capacité','protection'=>'Protection','finish'=>'Finition','graphics'=>'Carte graphique');
    }
    private static function key($label) {
        $label = strtolower(remove_accents(self::clean($label)));
        $label = trim(preg_replace('/[^a-z0-9]+/', ' ', $label));
        static $lookup = null;
        if (null === $lookup) {
            $aliases = array(
                'storage'=>'stockage|stockage interne|capacite de stockage|stockage rom|rom',
                'memory'=>'ram|memoire vive|memoire ram',
                'battery'=>'batterie|capacite de la batterie', 'autonomy'=>'autonomie',
                'display'=>'ecran|taille de l ecran|taille ecran principal|ecran principal|affichage',
                'processor'=>'processeur|puce', 'camera'=>'camera principale|appareil photo|capteur principal|photo et video',
                'compatibility'=>'compatibilite|modeles compatibles', 'material'=>'matiere|materiau|materiaux',
                'charging'=>'recharge|charge rapide|puissance de charge', 'connection'=>'connectivite|connexion|connectique',
                'capacity'=>'capacite', 'protection'=>'protection', 'finish'=>'finition', 'graphics'=>'carte graphique|gpu'
            );
            $lookup = array();
            // These fixed aliases are shared by every line and card in this request.
            foreach ($aliases as $key=>$names) foreach (explode('|', $names) as $name) {
                if (!isset($lookup[$name])) $lookup[$name] = $key;
            }
        }
        return $lookup[$label] ?? '';
    }
    private static function length($value) {
        // Unicode-safe even on servers without mbstring.
        return preg_match_all('/./us', $value, $unused);
    }
    private static function lines($html) {
        if (!is_scalar($html)) return array();
        $html = (string) $html;
        $html = preg_replace('/<(script|style|noscript)\b[^>]*>.*?<\/\1\s*>/is', '', $html);
        $html = preg_replace('/<\/(?:td|th)>\s*<(?:td|th)\b[^>]*>/i', ': ', $html);
        $html = preg_replace('/<\/?(?:p|li|tr|h[1-6]|div|ul|ol|table|tbody|thead|section)\b[^>]*>|<br\b[^>]*>/i', "\n", $html);
        // A space at every inline-tag boundary prevents « GoStockage » and « G5Coprocesseur ».
        $html = preg_replace('/<[^>]*>/', ' ', $html);
        $html = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $html = preg_replace('/[\x{00A0}\x{202F}\t ]+/u', ' ', $html);
        $html = preg_replace('/\r\n?/', "\n", $html);
        // Some older descriptions already contain joined labels after pasted HTML.
        $html = preg_replace('/(?<=[\p{L}\p{N}\)])\s*(?=(?:Stockage|Mémoire vive|Mémoire RAM|Mémoire|Processeur|Coprocesseur|Sécurité|Autonomie|Batterie|Recharge|Compatibilité)\s*:)/u', "\n", $html);
        return array_values(array_filter(array_map('trim', explode("\n", $html)), static function($line) { return $line !== ''; }));
    }
    private static function clean($value) {
        if (!is_scalar($value)) return '';
        return trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    }
    private static function collect(&$candidates, $source, $context = '') {
        $lines = self::lines($source);
        // Canonicalize explicit capacity attributes before description candidates are added.
        // A 256 Go offer must not inherit the model's generic 128/256 Go description.
        if ($context === 'capacity' && count($lines) === 1 && self::capacities($lines[0]) !== '') $context = 'storage';
        $heading = $context;
        foreach ($lines as $line) {
            $bare_key = self::key(rtrim($line, ': '));
            if ($bare_key) { $heading = $bare_key; continue; }
            if (preg_match('/^([^:]{2,65})\s*:\s*(.*)$/u', $line, $pair)) {
                $key = self::key($pair[1]);
                if ($key) {
                    $heading = $key;
                    if ($pair[2] !== '') $candidates[$key][] = $pair[2];
                } else {
                    // An unknown label starts a different field; do not borrow its value.
                    $heading = '';
                }
                continue;
            }
            if ($heading) { $candidates[$heading][] = $line; $heading = ''; }
        }
    }
    private static function capacities($value) {
        // Only an explicit list is eligible: no RAM/storage mix or expandable-storage promise.
        $list = preg_replace('/\b(?:ou|et|or|and)\b/iu', '/', $value);
        $list = preg_replace('/[|;]+/', '/', $list);
        $list = preg_replace('/(?<=[oObB])\s*,\s*(?=\d)/u', '/', $list);
        // « 128 / 256 Go » is an explicit shared-unit list.
        if (preg_match('/^(\d+(?:[.,]\d+)?(?:\s*\/\s*\d+(?:[.,]\d+)?)+)\s*(Go|To|GB|TB)$/iu', $list, $shared)) {
            $list = implode(' / ', array_map(static function($number) use ($shared) { return trim($number) . ' ' . $shared[2]; }, explode('/', $shared[1])));
        }
        if (!preg_match('/^\d+(?:[.,]\d+)?\s*(?:Go|To|GB|TB)(?:\s*\/\s*\d+(?:[.,]\d+)?\s*(?:Go|To|GB|TB))*$/iu', trim($list))) return '';
        preg_match_all('/(\d+(?:[.,]\d+)?)\s*(Go|To|GB|TB)/iu', $list, $matches, PREG_SET_ORDER);
        $sizes = array();
        foreach ($matches as $match) {
            $number = (float) str_replace(',', '.', $match[1]);
            if ($number <= 0) return '';
            $terabyte = in_array(strtolower($match[2]), array('to','tb'), true);
            $size = $number * ($terabyte ? 1024 : 1);
            $sizes[(string) $size] = str_replace('.', ',', $match[1]) . ($terabyte ? ' To' : ' Go');
        }
        ksort($sizes, SORT_NUMERIC);
        return (count($sizes) > 1 ? 'à partir de ' : '') . reset($sizes);
    }
    private static function compact($key, $raw) {
        $value = self::clean($raw);
        if ($value === '' || self::key(rtrim($value, ': ')) || preg_match('/https?:|\[[^\]]*\]|:\s*$|</u', $value)) return '';
        if (preg_match('/^(?:oui|non|n\/?a|non renseign[eé]|[àa] renseigner|variable|inconnu|non disponible|voir description)$/iu', $value)) return '';
        $label = self::labels()[$key];
        if (in_array($key, array('storage','capacity'), true)) {
            $capacity = self::capacities($value);
            if ($capacity !== '') { $value = $capacity; $label = 'Stockage'; }
        }
        $limit = 72 - self::length($label) - 3;
        // Keep a complete clause, never cut a measurement or concatenate the next field.
        $clauses = preg_split('/\s*(?:;|\s[•·]\s)\s*/u', $value);
        $value = $clauses[0];
        if (self::length($value) > $limit || preg_match('/:\s*[^ ]/u', $value)) return '';
        $value = trim($value, " \t\n\r\0\x0B.;");
        if ($value === '') return '';
        return $label . ' : ' . $value;
    }
    public static function get($product) {
        if (!is_object($product)) return '';
        $candidates = array();
        $meta = $product->get_meta('_slyme_presentation_v1', true);
        foreach (is_array($meta) && isset($meta['fields']) && is_array($meta['fields']) ? $meta['fields'] : array() as $key=>$value) {
            if (isset(self::labels()[$key]) && is_scalar($value)) self::collect($candidates, $value, $key);
        }
        foreach ($product->get_attributes() as $attribute) {
            if (!$attribute->get_visible()) continue;
            $key = self::key(wc_attribute_label($attribute->get_name()));
            if ($key) self::collect($candidates, $product->get_attribute($attribute->get_name()), $key);
        }
        $name = strtolower(remove_accents($product->get_name()));
        $order = array('storage','display','battery','autonomy','memory','processor','camera','capacity','charging','compatibility','material','connection','protection','finish','graphics');
        if (preg_match('/watch|montre|mibro/', $name)) $order = array('autonomy','battery','display','compatibility','connection','material');
        elseif (preg_match('/coque|etui|cable|chargeur|ecouteur|airpods|buds|power.?bank/', $name)) $order = array('compatibility','charging','capacity','autonomy','battery','material','connection','protection','finish');
        elseif (preg_match('/macbook|imac|ordinateur|thinkpad|latitude|elitebook|vivobook|probook|ideapad|inspiron/', $name)) $order = array('processor','memory','storage','graphics','display','battery');
        // Only the highest-priority field can skip description parsing without changing selection.
        foreach ($candidates[$order[0]] ?? array() as $candidate) {
            $result = self::compact($order[0], $candidate);
            if ($result !== '') return $result;
        }
        $description = $product->get_short_description() . "\n" . $product->get_description();
        // Bound work on catalogue requests; no remote, variation or gallery lookup.
        $description = function_exists('mb_strcut') ? mb_strcut($description, 0, 32000, 'UTF-8') : substr($description, 0, 32000);
        for ($trim = 0; $trim < 4 && !preg_match('//u', $description); $trim++) $description = substr($description, 0, -1);
        self::collect($candidates, $description);
        foreach ($order as $key) foreach ($candidates[$key] ?? array() as $candidate) {
            $result = self::compact($key, $candidate);
            if ($result !== '') return $result;
        }
        // No invented marketing sentence when no reliable compact characteristic exists.
        return '';
    }
}
