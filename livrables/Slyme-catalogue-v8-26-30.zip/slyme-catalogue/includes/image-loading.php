<?php
/** Responsive native related-product thumbnails, without a second lazy loader. */
defined('ABSPATH') || exit;

final class Slyme_Image_Loading {
    private static $related_card = false;

    public static function boot() {
        // The native loop name persists after loop-end.php. Bound this policy
        // to each card, so later footer or mini-cart photos cannot inherit it.
        add_action('woocommerce_before_shop_loop_item', array(__CLASS__, 'begin_card'), 0);
        add_action('woocommerce_after_shop_loop_item', array(__CLASS__, 'end_card'), PHP_INT_MAX);
        add_filter('wp_get_attachment_image_attributes', array(__CLASS__, 'related_thumbnail'), 99, 3);
    }

    public static function begin_card() {
        self::$related_card = function_exists('is_product') && is_product()
            && function_exists('wc_get_loop_prop') && wc_get_loop_prop('name') === 'related';
    }

    public static function end_card() {
        self::$related_card = false;
    }

    public static function related_thumbnail($attributes, $attachment, $size) {
        // WooCommerce sets the loop name before rendering related.php. Leave
        // the main gallery, shop archive, mini-cart and other loops untouched.
        if (!self::$related_card || !is_array($attributes) || !function_exists('is_product') || !is_product()
            || !function_exists('wc_get_loop_prop') || wc_get_loop_prop('name') !== 'related') return $attributes;

        $class = isset($attributes['class']) ? (string) $attributes['class'] : '';
        $thumbnail = in_array($size, array('woocommerce_thumbnail', 'shop_catalog'), true)
            || preg_match('/(?:^|\s)(?:attachment-woocommerce_thumbnail|attachment-shop_catalog|show-on-hover)(?:\s|$)/', $class);
        if (!$thumbnail) return $attributes;

        $attributes['data-no-lazy'] = '1';
        $attributes['loading'] = 'lazy';
        $attributes['decoding'] = 'async';
        // A hidden hover image should not compete with the card's first photo.
        $attributes['fetchpriority'] = preg_match('/(?:^|\s)show-on-hover(?:\s|$)/', $class) ? 'low' : 'auto';

        $id = is_object($attachment) && isset($attachment->ID) ? (int) $attachment->ID : 0;
        if (empty($attributes['srcset']) && $id > 0 && !empty($attributes['src'])) {
            $srcset = Slyme_Catalogue_V6::responsive_image($id, (string) $attributes['src']);
            if ($srcset !== '') $attributes['srcset'] = $srcset;
        }
        if (!empty($attributes['srcset'])) {
            // The related-product CSS uses the same compact two-card layout.
            $attributes['sizes'] = '(max-width:599px) 44vw, (max-width:1023px) 220px, 240px';
        }
        return $attributes;
    }
}
