/* Slyme — photos à la demande, aucune animation continue, aucun geste tactile intercepté. */
(() => {
  const ready = fn => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn, {once:true}) : fn();
  ready(() => document.querySelectorAll('.slyme-hero[data-slyme-hero-options]').forEach(hero => {
    if (hero.dataset.slymeHeroReady) return;
    let product;
    try { product = JSON.parse(hero.dataset.slymeHeroOptions); } catch (_) { return; }
    const root = hero.closest('[data-slyme-home]');
    const origin = new URL(root.dataset.slymeHome, location.href).origin;
    const safe = (value, image = false) => {
      try { const url = new URL(value, location.href); return /^https?:$/.test(url.protocol) && (image || url.origin === origin) ? url.href : ''; } catch (_) { return ''; }
    };
    const media = hero.querySelector('.slyme-hero-media');
    const photo = hero.querySelector('.slyme-hero-image');
    const message = hero.querySelector('.slyme-hero-image-status');
    const group = hero.querySelector('.slyme-hero-swatches');
    const name = hero.querySelector('.slyme-hero-color-name');
    const price = hero.querySelector('.slyme-product-price');
    const reduce = matchMedia('(prefers-reduced-motion: reduce)');
    const loaded = new Map();
    let colors = [], selected = hero.dataset.tone, sequence = 0, animation;
    const span = (cls, text) => { const e = document.createElement('span'); e.className = cls; e.textContent = text; return e; };
    function drawPrice(value) {
      if (!value || typeof value.amount !== 'string') return;
      const content = document.createDocumentFragment();
      if (value.amount === '') content.append(span('slyme-price-request', 'Prix sur demande'));
      else {
        if (value.label) content.append(span('slyme-price-label', value.label));
        const amount = span('slyme-price-amount', value.amount + ' ');
        amount.append(span('slyme-price-currency', value.currency)); content.append(amount);
        if (value.suffix) content.append(span('slyme-price-note', value.suffix));
      }
      price.replaceChildren(content);
    }
    const load = (url, srcset) => {
      if (loaded.has(url)) return loaded.get(url);
      const promise = new Promise((resolve, reject) => {
        const next = new Image(); next.decoding = 'async'; next.sizes=photo.sizes; if(srcset) next.srcset=srcset;
        const timeout = setTimeout(() => { next.onload = next.onerror = null; reject(new Error('Photo indisponible')); }, 10000);
        next.onload = async () => { clearTimeout(timeout); if (next.decode) await next.decode().catch(() => {}); resolve(); };
        next.onerror = () => { clearTimeout(timeout); reject(new Error('Photo indisponible')); };
        next.src = url;
      });
      loaded.set(url, promise); promise.catch(() => loaded.delete(url));
      return promise;
    };
    function imageError() { photo.hidden = true; message.hidden = false; media.removeAttribute('aria-busy'); }
    photo.addEventListener('error', imageError);
    if (photo.complete && !photo.naturalWidth) imageError();
    async function select(key, animate = true) {
      const color = colors.find(option => option.key === key);
      const choice = color || {image:product.hero.image, srcset:product.hero.srcset, url:product.url, price:product.price, label:''};
      selected = color ? color.key : '';
      hero.dataset.tone = selected || 'blanc';
      [...group.children].forEach(button => {
        const current = button.dataset.slymeColor === selected;
        button.classList.toggle('is-selected', current); button.setAttribute('aria-checked', String(current)); button.tabIndex = current ? 0 : -1;
      });
      name.textContent = choice.label;
      drawPrice(choice.price);
      const url = safe(choice.url);
      if (url) hero.querySelectorAll('[data-slyme-hero-link]').forEach(link => { link.href = url + (link.hasAttribute('data-slyme-details') ? '#tab-description' : ''); });
      const src = safe(choice.image, true), token = ++sequence;
      if (!src) { imageError(); return; }
      if (src === photo.src && !photo.hidden) { if(photo.srcset !== (choice.srcset || '')) photo.srcset=choice.srcset || ''; photo.alt = product.hero.title + (choice.label ? ' — ' + choice.label : ''); media.removeAttribute('aria-busy'); return; }
      media.setAttribute('aria-busy', 'true'); message.hidden = true;
      try {
        await load(src,choice.srcset);
        if (token !== sequence) return;
        if (animation) animation.cancel();
        photo.srcset=choice.srcset || ''; photo.src = src; photo.alt = product.hero.title + (choice.label ? ' — ' + choice.label : '');
        photo.hidden = false; message.hidden = true; media.removeAttribute('aria-busy');
        if (animate && !reduce.matches && photo.animate) animation = photo.animate([{opacity:.25,transform:'translateY(6px) scale(.99)'},{opacity:1,transform:'translateY(0) scale(1)'}], {duration:220,easing:'cubic-bezier(.2,.65,.25,1)'});
      } catch (_) { if (token === sequence) imageError(); }
    }
    function update(next) {
      if (!next || !next.hero || typeof next.hero.title !== 'string') return;
      product = next;
      hero.querySelector('.slyme-hero-title').textContent = next.hero.title;
      hero.querySelector('.slyme-hero-copy').textContent = next.hero.tagline;
      colors = (Array.isArray(next.hero.colors) ? next.hero.colors : []).filter(c => safe(c.url) && safe(c.image, true));
      const focused = group.contains(document.activeElement) ? document.activeElement.dataset.slymeColor : '';
      const keys = [...group.children].map(b => b.dataset.slymeColor).join(',');
      if (keys !== colors.map(c => c.key).join(',')) {
        group.replaceChildren(...colors.map(color => {
          const link = document.createElement('a'); link.className = 'slyme-hero-swatch'; link.dataset.slymeColor = color.key;
          const dot = document.createElement('span'); dot.setAttribute('aria-hidden','true'); link.append(dot); return link;
        }));
      }
      [...group.children].forEach((button, index) => {
        const color = colors[index]; button.href = safe(color.url); button.title = color.label;
        button.setAttribute('aria-label', color.label); button.setAttribute('role', 'radio');
      });
      hero.querySelector('.slyme-hero-colors').hidden = !colors.length;
      group.setAttribute('role', 'radiogroup');
      select(colors.some(c => c.key === selected) ? selected : (colors[0] || {}).key, false);
      if (focused) { const button = [...group.children].find(b => b.dataset.slymeColor === focused) || group.querySelector('[tabindex="0"]'); if (button) button.focus({preventScroll:true}); }
    }
    group.addEventListener('click', event => {
      const button = event.target.closest('[data-slyme-color]');
      if (!button || event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault(); select(button.dataset.slymeColor);
    });
    group.addEventListener('keydown', event => {
      const buttons = [...group.children], index = buttons.indexOf(event.target);
      if (index < 0 || event.altKey || event.ctrlKey || event.metaKey) return;
      let target = index;
      if (['ArrowRight','ArrowDown'].includes(event.key)) target = (index + 1) % buttons.length;
      else if (['ArrowLeft','ArrowUp'].includes(event.key)) target = (index - 1 + buttons.length) % buttons.length;
      else if (event.key === 'Home') target = 0;
      else if (event.key === 'End') target = buttons.length - 1;
      else if (event.key !== ' ') return;
      event.preventDefault(); buttons[target].focus({preventScroll:true}); select(buttons[target].dataset.slymeColor);
    });
    reduce.addEventListener('change', () => { if (reduce.matches && animation) animation.cancel(); });
    hero.addEventListener('slyme:product', event => update(event.detail));
    update(product); hero.dataset.slymeHeroReady = '5'; hero.removeAttribute('data-slyme-hero-options');
  }));
})();
