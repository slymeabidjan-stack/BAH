/* Slyme : navigation, recherche et prix. Aucun gestionnaire de déplacement tactile. */
(() => {
  const onReady = callback => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', callback, {once:true}) : callback();
  const storage = {
    get(key) { try { return JSON.parse(sessionStorage.getItem(key)); } catch (_) { return null; } },
    set(key, value) { try { sessionStorage.setItem(key, JSON.stringify(value)); } catch (_) {} },
    remove(key) { try { sessionStorage.removeItem(key); } catch (_) {} }
  };
  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  onReady(() => document.querySelectorAll('.slyme-products-grid[data-slyme-api]').forEach(root => {
    if (root.dataset.slymeAppReady) return;
    root.dataset.slymeAppReady = '813';
    const home = new URL(root.dataset.slymeHome, location.href);
    const api = new URL(root.dataset.slymeApi, location.href);
    const safeURL = (value, image = false) => {
      try {
        const url = new URL(value, home);
        return /^https?:$/.test(url.protocol) && (image || url.origin === home.origin) ? url.href : '';
      } catch (_) { return ''; }
    };
    const request = async (route, parameters, signal) => {
      const url = api.searchParams.has('rest_route') ? new URL(api) : new URL(route, api);
      if (url.searchParams.has('rest_route')) url.searchParams.set('rest_route', api.searchParams.get('rest_route').replace(/\/?$/, '/') + route);
      Object.entries(parameters).forEach(([key, value]) => url.searchParams.set(key, value));
      const response = await fetch(url, {signal, credentials:'same-origin', cache:'no-store', priority:route === 'search' ? 'high' : 'low', headers:{Accept:'application/json'}});
      if (!response.ok) throw new Error('Catalogue indisponible');
      const result = await response.json();
      if (!Array.isArray(result)) throw new Error('Réponse invalide');
      return result;
    };
    const priceText = price => price && price.amount !== '' ? [price.label, price.amount, price.currency].filter(Boolean).join(' ') : 'Prix sur demande';

    // Une sauvegarde au départ de la page, sans écritures répétées pendant les gestes.
    const pageKey = location.pathname + location.search;
    let entry = history.state && typeof history.state === 'object' ? history.state.slymeEntry : '';
    if (!entry) {
      entry = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      try { history.replaceState({...((history.state && typeof history.state === 'object') ? history.state : {}), slymeEntry:entry}, '', location.href); } catch (_) {}
    }
    const snapshot = () => {
      const tracks = {};
      root.querySelectorAll('.slyme-product-grid[id]').forEach(track => { tracks[track.id] = track.scrollLeft; });
      const saved = {time:Date.now(), y:scrollY, tracks};
      storage.set('slyme:entry:' + entry, saved);
      storage.set('slyme:page:' + pageKey, saved);
    };
    const restore = event => {
      if (event && event.persisted) return; // Le cache de navigation du navigateur conserve déjà tout.
      const navigation = performance.getEntriesByType('navigation')[0];
      const explicitReturn = storage.get('slyme:return') === pageKey;
      if ((!navigation || navigation.type !== 'back_forward') && !explicitReturn) return;
      const saved = explicitReturn ? storage.get('slyme:page:' + pageKey) : storage.get('slyme:entry:' + entry);
      if (explicitReturn) storage.remove('slyme:return');
      if (!saved || Date.now() - saved.time > 86400000 || !Number.isFinite(saved.y)) return;
      Object.entries(saved.tracks || {}).forEach(([id, left]) => {
        const track = document.getElementById(id);
        if (track && root.contains(track) && Number.isFinite(left)) track.scrollLeft = left;
      });
      requestAnimationFrame(() => scrollTo({top:saved.y, behavior:'instant'}));
    };
    window.addEventListener('pagehide', snapshot);
    window.addEventListener('pageshow', restore);
    root.addEventListener('click', event => {
      const link = event.target.closest('a[href]');
      if (!link || event.defaultPrevented || event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      snapshot();
      if (link.hasAttribute('data-slyme-return')) storage.set('slyme:return', home.pathname + home.search);
    });

    // Prix actuels : rafraîchissement groupé des cartes proches de l'écran, même si la page HTML est en cache.
    const cards = new Map(), latestProducts = new Map(), pending = new Set(), completed = new Set();
    const productSelector = '.slyme-product-card[data-product-id],.slyme-hero[data-product-id]';
    let timer = 0, running = false;
    const rendered = Number(root.dataset.slymeRendered || 0) * 1000;
    const heroId = root.querySelector('.slyme-hero')?.dataset.productId || '';
    root.querySelectorAll(productSelector).forEach(card => {
      const id = Number(card.dataset.productId);
      if (!Number.isInteger(id) || id < 1) return;
      if (!cards.has(id)) cards.set(id, []);
      cards.get(id).push(card);
    });
    const drawPrice = (card, price) => {
      if (!price || typeof price.amount !== 'string') return;
      const holder = card.querySelector('.slyme-product-price');
      const content = document.createDocumentFragment();
      if (price.amount === '') content.append(create('span', 'slyme-price-request', 'Prix sur demande'));
      else {
        if (price.label) content.append(create('span', 'slyme-price-label', price.label + ' '));
        const amount = create('span', 'slyme-price-amount', price.amount + ' ');
        amount.append(create('span', 'slyme-price-currency', price.currency));
        content.append(amount);
        if (price.suffix) content.append(create('span', 'slyme-price-note', price.suffix));
      }
      if (holder.textContent.replace(/\s/g,'') !== content.textContent.replace(/\s/g,'')) holder.replaceChildren(content);
    };
    const updateCard = (card, product) => {
      const url = safeURL(product.url), image = safeURL(product.image, true);
      if (!url || typeof product.name !== 'string') return;
      if (card.matches('.slyme-hero')) {
        if (!product.hero) { card.hidden = true; return; }
        card.dispatchEvent(new CustomEvent('slyme:product', {detail:product}));
        card.dataset.slymeFresh = 'true';
        return;
      }
      card.href = url;
      const name = card.querySelector('.slyme-product-name');
      if (name.textContent !== product.name) name.textContent = product.name;
      const benefit = card.querySelector('.slyme-product-benefit');
      if (benefit && typeof product.benefit === 'string' && benefit.textContent !== product.benefit) {
        const parts = product.benefit.split(/(à partir de)/iu);
        benefit.replaceChildren(...parts.map(part => /^à partir de$/iu.test(part) ? create('strong', 'slyme-starting-label', part) : document.createTextNode(part)));
      }
      const brand = card.querySelector('.slyme-product-brand');
      if (brand.textContent !== (product.brand || '')) brand.textContent = product.brand || '';
      const photo = card.querySelector('img');
      if (photo) { if (typeof product.srcset === 'string' && photo.srcset !== product.srcset) photo.srcset = product.srcset; photo.alt = product.name; if (image && photo.src !== image) photo.src = image; }
      drawPrice(card, product.price);
      card.dataset.slymeFresh = 'true';
    };
    const flush = async () => {
      timer = 0;
      if (running || !pending.size) return;
      running = true;
      const ids = [...pending].slice(0, 16);
      ids.forEach(id => pending.delete(id));
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 9000);
      try {
        const products = await request('products', {include:ids.join(','), hero:ids.includes(Number(heroId)) ? heroId : ''}, controller.signal);
        const available = new Set();
        products.forEach(product => {
          const id = Number(product.id);
          if (!ids.includes(id)) return;
          available.add(id);latestProducts.set(id,product);
          (cards.get(id) || []).forEach(card => updateCard(card, product));
        });
        ids.forEach(id => {
          completed.add(id);
          if (!available.has(id)) latestProducts.set(id,null);
          if (!available.has(id)) (cards.get(id) || []).forEach(card => {
            card.hidden = true;
            const track = card.closest('.slyme-product-grid');
            if (track) track.dispatchEvent(new Event('slyme:refresh'));
          });
        });
      } catch (_) {
        // Une panne de réseau laisse le catalogue rendu par WooCommerce consultable.
      } finally {
        clearTimeout(timeout); running = false;
        if (pending.size) timer = setTimeout(flush, 120);
      }
    };
    const enqueue = element => {
      if (rendered && Date.now() - rendered < 60000) return;
      const list = element.matches(productSelector) ? [element] : element.querySelectorAll(productSelector);
      list.forEach(card => { const id = Number(card.dataset.productId); if (!completed.has(id)) pending.add(id); });
      if (!timer) timer = setTimeout(flush, 120);
    };
    const nearScreen = card => { const r = card.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight + 150 && r.right > 0 && r.left < innerWidth; };
    let priceObserver = null;
    if ('IntersectionObserver' in window) {
      const observer = priceObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting) enqueue(entry.target);
      }), {rootMargin:'150px 0px'});
      root.querySelectorAll(productSelector).forEach(element => observer.observe(element));
    } else cards.forEach(list => list.filter(nearScreen).forEach(enqueue));
    const refreshVisible = () => cards.forEach(list => list.filter(nearScreen).forEach(enqueue));
    window.addEventListener('online', refreshVisible);
    window.addEventListener('pageshow', event => { if (event.persisted) { completed.clear(); refreshVisible(); } });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { completed.clear(); refreshVisible(); } });

    // Cartes fournies avec la page : aucune requête de collection au défilement.
    const revealSection = loader => {
      if (!loader?.isConnected) return;
      const track=loader.parentElement;
      const newCards=[...loader.content.querySelectorAll(productSelector)];
      track.querySelectorAll('.slyme-card-placeholder').forEach(node=>node.remove());
      track.append(loader.content);loader.remove();
      newCards.forEach(card=>{
        const id=Number(card.dataset.productId);
        if(!cards.has(id))cards.set(id,[]);
        cards.get(id).push(card);
        if(latestProducts.has(id)){const fresh=latestProducts.get(id);if(fresh)updateCard(card,fresh);else card.hidden=true;}
        card.querySelectorAll('img').forEach(img=>{img.loading='eager';img.fetchPriority='low';});
        if(priceObserver)priceObserver.observe(card);
      });
      track.dispatchEvent(new Event('slyme:refresh'));
    };
    if('IntersectionObserver' in window){
      const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
        if(entry.isIntersecting){sectionObserver.unobserve(entry.target);revealSection(entry.target.querySelector('template.slyme-section-loader'));}
      }),{rootMargin:navigator.connection?.saveData?'300px 0px':'1200px 0px'});
      root.querySelectorAll('template.slyme-section-loader').forEach(loader=>sectionObserver.observe(loader.parentElement));
      root.addEventListener('focusin',event=>{
        const section=event.target.closest('.slyme-carousel-section');
        if(section)revealSection(section.querySelector('template.slyme-section-loader'));
      });
    }else root.querySelectorAll('template.slyme-section-loader').forEach(revealSection);

    const prefetched = new Set();
    const warmLink = event => {
      const link = event.target.closest('.slyme-see-all,.slyme-category-card,.slyme-pagination a');
      if (!link || prefetched.size >= 2 || navigator.connection?.saveData || /(^|-)2g$/.test(navigator.connection?.effectiveType || '')) return;
      const url = new URL(link.href, location.href);
      if (url.origin !== location.origin || prefetched.has(url.href)) return;
      prefetched.add(url.href);
      const hint = document.createElement('link'); hint.rel = 'prefetch'; hint.as = 'document'; hint.href = url.href; document.head.append(hint);
    };
    root.addEventListener('pointerover', event => { if (event.pointerType === 'mouse') warmLink(event); }, {passive:true});

    const form = root.querySelector('.slyme-search');
    if (!form) return;
    const input = form.querySelector('input[type=search]');
    const results = form.querySelector('.slyme-search-results');
    const status = form.querySelector('.slyme-search-status');
    const cache = new Map();
    const keyFor = value => value.trim().replace(/\s+/g,' ').toLocaleLowerCase();
    let debounce = 0, controller = null, sequence = 0, selected = -1, composing = false, shownTerm = '', selecting = false;
    const close = () => {
      results.hidden = true; selected = -1;
      input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant');
      status.textContent = '';
    };
    const cancel = () => {
      clearTimeout(debounce); sequence++;
      if (controller) controller.abort();
      form.removeAttribute('aria-busy');
    };
    const show = (products, term) => {
      results.replaceChildren(); selected = -1; shownTerm = keyFor(term);
      input.removeAttribute('aria-activedescendant');
      products.slice(0, 8).forEach((product, index) => {
        const url = safeURL(product.url);
        if (!url || typeof product.name !== 'string') return;
        const option = create('li');
        option.id = results.id + '-' + index;
        option.setAttribute('role', 'option'); option.setAttribute('aria-selected', 'false');
        const link = create('a', 'slyme-search-result'); link.href = url;
        const photo = create('img'); if (product.srcset) {photo.srcset=product.srcset;photo.sizes='54px';} photo.src = safeURL(product.image, true); photo.alt = ''; photo.width = 48; photo.height = 48; photo.loading = 'lazy'; photo.addEventListener('error',()=>{photo.style.visibility='hidden';},{once:true});
        const description = create('span');
        description.append(create('span', 'slyme-search-name', product.name), create('span', 'slyme-search-price', priceText(product.price)));
        link.append(photo, description); option.append(link); results.append(option);
      });
      const count = results.children.length;
      if (!count) { const empty = create('li', 'slyme-search-empty', 'Aucun produit trouvé. Essaie un autre nom.'); empty.setAttribute('role', 'presentation'); results.append(empty); }
      status.textContent = count ? count + ' produit' + (count > 1 ? 's proposés.' : ' proposé.') : 'Aucun produit trouvé.';
      const entering=results.hidden;
      results.hidden = false; input.setAttribute('aria-expanded', 'true');
      if(entering)results.dispatchEvent(new CustomEvent('slyme:enter',{bubbles:true}));
    };
    const search = async () => {
      const term = input.value.trim(), key = keyFor(term);
      if (term.length < 2) { close(); return; }
      const saved=cache.get(key);
      if(saved && Date.now()-saved.time<30000){show(saved.products,term);return;}
      const current = ++sequence;
      controller = new AbortController();
      const active = controller;
      const timeout = setTimeout(() => active.abort(), 8000);
      form.setAttribute('aria-busy', 'true');status.textContent='Recherche en cours…';
      try {
        const products = await request('search', {search:term}, active.signal);
        if(current!==sequence)return;
        cache.delete(key);cache.set(key,{time:Date.now(),products});
        if(cache.size>12)cache.delete(cache.keys().next().value);
        if(form.contains(document.activeElement)||selecting)show(products,term);
      } catch (_) {
        if (current === sequence) { close(); results.replaceChildren(create('li','slyme-search-empty','Suggestions indisponibles. Utilisez le bouton de recherche pour afficher les résultats.')); results.hidden=false; input.setAttribute('aria-expanded','true'); status.textContent='Suggestions indisponibles.'; }
      } finally {
        clearTimeout(timeout);
        if (current === sequence) form.removeAttribute('aria-busy');
      }
    };
    const schedule = () => {
      cancel(); close(); selected=-1;input.removeAttribute('aria-activedescendant');
      results.querySelectorAll('[aria-selected=true]').forEach(e=>e.setAttribute('aria-selected','false'));
      if(input.value.trim().length<2){close();return;}
      if(!composing){status.textContent='Recherche en cours…';const saved=cache.get(keyFor(input.value));if(saved&&Date.now()-saved.time<30000){search();}else debounce=setTimeout(search,100);}
    };
    input.addEventListener('compositionstart', () => { composing = true; cancel(); });
    input.addEventListener('compositionend', () => { composing = false; schedule(); });
    input.addEventListener('input', schedule);
    let sheet = null, marker = null, sheetClosing = false, oldOverflow = '';
    const resizeSheet = () => {
      if (!sheet?.open) return;
      sheet.style.setProperty('--slyme-search-height', (window.visualViewport?.height || innerHeight) + 'px');
      sheet.style.setProperty('--slyme-search-top', (window.visualViewport?.offsetTop || 0) + 'px');
    };
    const closeSheet = () => {
      if (!sheet?.open) return;
      sheetClosing = true; cancel(); close(); input.blur(); sheet.close();
      marker.replaceWith(form); marker = null;
      document.documentElement.style.overflow = oldOverflow;
      setTimeout(() => { input.blur(); sheetClosing = false; }, 0);
    };
    const openSheet = () => {
      if (sheetClosing || sheet?.open || !('HTMLDialogElement' in window)) return;
      if (!sheet) {
        sheet = create('dialog','slyme-search-sheet slyme-products-grid');
        sheet.setAttribute('aria-labelledby', input.id + '-sheet-title');
        const header = create('header','slyme-search-sheet-header');
        const title = create('h2','slyme-search-sheet-title','Rechercher un produit'); title.id=input.id+'-sheet-title';
        const button = create('button','slyme-search-sheet-close','×'); button.type='button'; button.setAttribute('aria-label','Fermer la recherche');
        button.addEventListener('click',closeSheet); header.append(title,button); sheet.append(header); document.body.append(sheet);
        sheet.addEventListener('cancel', event => { event.preventDefault(); closeSheet(); });
        sheet.addEventListener('click', event => { if(event.target.closest('a')) snapshot();if(event.target===sheet){const r=sheet.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeSheet();} });
        window.visualViewport?.addEventListener('resize',resizeSheet);
        window.visualViewport?.addEventListener('scroll',resizeSheet);
        window.addEventListener('pagehide',closeSheet);
      }
      marker=document.createComment('slyme-search-position'); form.before(marker); sheet.append(form);
      oldOverflow=document.documentElement.style.overflow; sheet.showModal(); document.documentElement.style.overflow='hidden'; resizeSheet(); input.focus({preventScroll:true});
    };
    input.addEventListener('focus', () => {if(sheetClosing)return;openSheet();if(input.value.trim().length>=2)schedule();});
    input.addEventListener('keydown', event => {
      if (event.isComposing) return;
      if (event.key === 'Escape') { event.preventDefault();cancel(); close(); if(sheet?.open)closeSheet(); return; }
      const options = [...results.querySelectorAll('[role=option]')];
      if (!results.hidden && shownTerm===keyFor(input.value) && options.length && ['ArrowDown','ArrowUp'].includes(event.key)) {
        event.preventDefault();
        selected = selected < 0 ? (event.key === 'ArrowDown' ? 0 : options.length-1) : (selected + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length;
        options.forEach((option, index) => option.setAttribute('aria-selected', String(index === selected)));
        input.setAttribute('aria-activedescendant', options[selected].id);
        const row=options[selected];if(row.offsetTop<results.scrollTop)results.scrollTop=row.offsetTop;else if(row.offsetTop+row.offsetHeight>results.scrollTop+results.clientHeight)results.scrollTop=row.offsetTop+row.offsetHeight-results.clientHeight;
      } else if (event.key === 'Enter' && !results.hidden && shownTerm===keyFor(input.value) && selected >= 0 && options[selected]) {
        event.preventDefault(); options[selected].querySelector('a').click();
      }
    });
    // Garder la suggestion sous le doigt jusqu’au clic ; le flou ne doit pas la supprimer.
    results.addEventListener('pointerdown', event => {
      selecting=true;
      if(event.pointerType==='mouse'&&event.target.closest('a'))event.preventDefault();
    });
    results.addEventListener('pointerup', () => setTimeout(()=>{selecting=false;if(!form.contains(document.activeElement))close();},300));
    results.addEventListener('pointercancel',()=>{selecting=false;});
    results.addEventListener('click',event=>{if(event.target.closest('a'))cancel();});
    form.addEventListener('submit', () => { cancel(); snapshot(); });
    form.addEventListener('focusout', event => {
      if(!selecting&&!form.contains(event.relatedTarget)){cancel();close();}
    });
    document.addEventListener('pointerdown', event => { if (!form.contains(event.target)) { selecting=false;cancel();close(); } }, {passive:true});
    // Handles delayed script execution after the customer's first tap.
    if(document.activeElement===input){openSheet();if(input.value.trim().length>=2)schedule();}
  }));
})();
