/* Message préparé sur la page : aucune coordonnée conservée ni envoyée en arrière-plan. */
(() => {
 const start = () => document.querySelectorAll('.slyme-whatsapp-link[data-phone]').forEach(link => {
  if (link.dataset.slymeReady) return;
  link.dataset.slymeReady = '88';
  const product = link.closest('.product') || document;
  const cart = product.querySelector('form.cart');
  const dialog = link.parentElement.querySelector('dialog');
  const form = dialog?.querySelector('form');
  const nativeQuantity = cart?.querySelector('input.qty, input[name="quantity"]');
  const selects = [...(cart?.querySelectorAll('select[name^="attribute_"]') || [])];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const currency = link.dataset.currency || 'FCFA';
  const decimals = Math.min(6, Math.max(0, Number(link.dataset.decimals) || 0));
  const money = new Intl.NumberFormat('fr-FR', {minimumFractionDigits:decimals, maximumFractionDigits:decimals});
  let variations = [], variation = null, frame = 0, animation = null, closing = false, locked = false, leaving = false, oldOverflow = '';
  try { const data = JSON.parse(cart?.getAttribute('data-product_variations') || 'null'); if (Array.isArray(data)) variations = data; } catch (_) {}
  const urlFor = lines => {
   const url = new URL('https://wa.me/' + link.dataset.phone);
   url.searchParams.set('text', lines.join('\n'));
   return url.href;
  };
  const options = () => selects.map(select => {
   const label = (select.closest('tr')?.querySelector('label')?.textContent || select.name.replace(/^attribute_(pa_)?/, '').replace(/-/g, ' ')).trim().replace(/:$/, '').trim();
   return {label, value:select.value ? select.selectedOptions[0].textContent.trim() : 'à préciser'};
  });
  const variable = link.dataset.variable === '1' || cart?.classList.contains('variations_form');
  const selectedVariation = () => {
   if (!variable || selects.some(select => !select.value)) return null;
   const id = Number(cart?.querySelector('input.variation_id')?.value || 0);
   const selected = id ? (Number(variation?.variation_id) === id ? variation : variations.find(item => Number(item.variation_id) === id)) : null;
   if (!selected || selects.some(select => selected.attributes?.[select.name] && selected.attributes[select.name] !== select.value)) return null;
   return selected;
  };
  const availability = () => {
   if (link.dataset.inStock === '0') return 'stock';
   if (link.dataset.purchasable === '0') return 'unavailable';
   if (!variable) return 'ready';
   const selected = selectedVariation();
   if (!selected) return 'options';
   if (!selected.is_in_stock) return 'stock';
   return selected.is_purchasable && selected.variation_is_active !== false && selected.variation_is_visible !== false ? 'ready' : 'unavailable';
  };
  const unitPrice = () => {
   if (variable) {
    const selected = selectedVariation();
    return selected && Number.isFinite(Number(selected.display_price)) ? Number(selected.display_price) : null;
   }
   return link.dataset.unitPrice !== '' && Number.isFinite(Number(link.dataset.unitPrice)) ? Number(link.dataset.unitPrice) : null;
  };
  // Guard every activation, including keyboard and modified clicks, before opening WhatsApp.
  link.addEventListener('click', event => { if (availability() !== 'ready') { event.preventDefault(); event.stopImmediatePropagation(); update(); } });
  const quantityField = form?.elements.customer_quantity;
  const quantity = () => dialog?.open ? Number(quantityField.value) : Number(nativeQuantity?.value || 1);
  const formatted = amount => money.format(amount) + ' ' + currency;
  const message = withCustomer => {
   const qty = quantity(), unit = unitPrice();
   const lines = ['Bonjour Slyme Abidjan, je souhaite passer commande de : ' + link.dataset.productName, link.dataset.productUrl];
   options().forEach(option => lines.push(option.label + ' : ' + option.value));
   lines.push('Quantité : ' + (Number.isInteger(qty) && qty > 0 ? qty : 'à préciser'));
   if (unit !== null && Number.isInteger(qty) && qty > 0) lines.push('Prix unitaire : ' + formatted(unit), 'Montant des produits : ' + formatted(unit * qty));
   if (withCustomer && form) {
    const contact = [['customer_lastname', 'Nom'], ['customer_firstname', 'Prénom'], ['customer_phone', 'Numéro'], ['customer_address', 'Adresse de livraison'], ['customer_note', 'Précisions pour la livraison']];
    const details = contact.filter(([key]) => form.elements[key].value.trim()).map(([key, label]) => label + ' : ' + form.elements[key].value.trim());
    if (details.length) lines.push('', 'Mes coordonnées :', ...details);
   }
   lines.push('', 'Merci de confirmer la disponibilité et ma commande.');
   return lines;
  };
  const constraints = () => {
   if (!quantityField || !nativeQuantity) return;
   quantityField.min = nativeQuantity.min && Number(nativeQuantity.min) > 0 ? nativeQuantity.min : '1';
   quantityField.step = '1';
   if (nativeQuantity.type === 'hidden') quantityField.max = '1';
   else if (Number(nativeQuantity.max) > 0) quantityField.max = nativeQuantity.max;
   else quantityField.removeAttribute('max');
  };
  const update = () => {
   if (frame) cancelAnimationFrame(frame);
   frame = 0;
   const state = availability(), ready = state === 'ready';
   if (ready) { link.href = urlFor(message(false)); link.removeAttribute('aria-disabled'); link.removeAttribute('tabindex'); }
   else { link.removeAttribute('href'); link.setAttribute('aria-disabled', 'true'); link.setAttribute('tabindex', '-1'); }
   const label = link.querySelector('[data-wa-link-label]') || link.querySelector('span');
   if (label) label.textContent = ready ? 'Commander sur WhatsApp' : state === 'stock' ? 'Rupture de stock' : state === 'options' ? 'Choisissez vos options' : 'Produit indisponible';
   const note = link.parentElement.querySelector('.slyme-wa-link-note');
   if (note) note.textContent = ready ? 'Votre produit, vos options et vos coordonnées dans un seul message.' : state === 'stock' ? 'Ce produit ou cette option est actuellement en rupture de stock.' : state === 'options' ? 'Sélectionnez une option disponible pour commander.' : 'Ce produit ne peut pas être commandé actuellement.';
   const submit = form?.querySelector('.slyme-wa-submit');
   if (submit) submit.disabled = !ready;
   if (!form) return;
   constraints();
   const qty = quantity(), unit = unitPrice();
   const unitNode = form.querySelector('[data-wa-unit]');
   const totalNode = form.querySelector('[data-wa-total]');
   form.querySelector('[data-wa-options]').textContent = options().map(option => option.label + ' : ' + option.value).join(' · ') || 'Votre produit, prêt à commander.';
   unitNode.hidden = unit === null;
   unitNode.textContent = unit === null ? '' : formatted(unit) + ' / unité';
   totalNode.parentElement.hidden = unit === null || !Number.isInteger(qty) || qty < 1;
   totalNode.textContent = unit === null || !Number.isInteger(qty) || qty < 1 ? '' : formatted(unit * qty);
   const preview = form.querySelector('[data-wa-message]');
   if (preview) preview.textContent = message(true).join('\n');
   form.querySelector('[data-wa-quantity-step="-1"]').disabled = !Number.isFinite(qty) || qty <= Number(quantityField.min);
   form.querySelector('[data-wa-quantity-step="1"]').disabled = !Number.isFinite(qty) || (quantityField.max !== '' && qty >= Number(quantityField.max));
  };
  const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
  const syncQuantity = () => {
   if (!nativeQuantity || !quantityField.checkValidity() || !Number.isInteger(Number(quantityField.value))) return;
   nativeQuantity.value = quantityField.value;
   nativeQuantity.dispatchEvent(new Event('input', {bubbles:true}));
   nativeQuantity.dispatchEvent(new Event('change', {bubbles:true}));
  };
  product.addEventListener('change', event => {
   if (selects.includes(event.target)) variation = null;
   if (event.target === nativeQuantity && quantityField) { constraints(); quantityField.value = nativeQuantity.value || '1'; }
   schedule();
  });
  if (cart && window.jQuery && cart.classList.contains('variations_form')) {
   window.jQuery(cart).on('found_variation.slymeWhatsApp', (_event, found) => { variation = found; schedule(); });
   window.jQuery(cart).on('reset_data.slymeWhatsApp', () => { variation = null; schedule(); });
  }
  update();
  if (!form || !dialog.showModal) return;
  const cancelAnimation = () => { animation?.cancel(); animation = null; };
  const restore = () => {
   if (locked) document.documentElement.style.overflow = oldOverflow;
   locked = false; closing = false; cancelAnimation();
   if (!leaving) link.focus({preventScroll:true});
  };
  const finishClose = () => { if (dialog.open) dialog.close(); };
  const close = () => {
   if (!dialog.open || closing) return;
   closing = true; cancelAnimation();
   if (reduce.matches || !dialog.animate || document.hidden) { finishClose(); return; }
   const current = dialog.animate([{opacity:1, transform:'translateY(0) scale(1)'}, {opacity:0, transform:'translateY(5px) scale(.99)'}], {duration:140, easing:'ease-out', fill:'forwards'});
   animation = current;
   current.finished.then(() => { if (animation === current) finishClose(); }, () => {});
  };
  link.addEventListener('click', event => {
   if (event.button || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
   event.preventDefault();
   if (dialog.open) return;
   constraints(); quantityField.value = nativeQuantity?.value || '1';
   oldOverflow = document.documentElement.style.overflow;
   leaving = false; dialog.showModal(); locked = true;
   document.documentElement.style.overflow = 'hidden';
   update();
   if (!reduce.matches && dialog.animate && !document.hidden) animation = dialog.animate([{opacity:0, transform:'translateY(8px) scale(.985)'}, {opacity:1, transform:'translateY(0) scale(1)'}], {duration:220, easing:'cubic-bezier(.2,.7,.2,1)'});
  });
  dialog.querySelector('.slyme-wa-close').addEventListener('click', close);
  dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
  dialog.addEventListener('click', event => {
   if (event.target !== dialog) return;
   const rect = dialog.getBoundingClientRect();
   if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) close();
  });
  dialog.addEventListener('close', restore);
  reduce.addEventListener('change', () => { if (reduce.matches) { cancelAnimation(); if (closing) finishClose(); } });
  document.addEventListener('visibilitychange', () => { if (document.hidden) { cancelAnimation(); if (closing) finishClose(); } });
  form.addEventListener('input', event => {
   event.target.setCustomValidity?.('');
   if (event.target === quantityField) syncQuantity();
   schedule();
  });
  form.querySelectorAll('[data-wa-quantity-step]').forEach(button => button.addEventListener('click', () => {
   constraints();
   if (!quantityField.value || !quantityField.checkValidity()) quantityField.value = quantityField.min;
   if (Number(button.dataset.waQuantityStep) > 0) quantityField.stepUp(); else quantityField.stepDown();
   quantityField.setCustomValidity(''); syncQuantity(); update();
  }));
  form.addEventListener('submit', event => {
   event.preventDefault();
   if (availability() !== 'ready') { update(); return; }
   form.querySelectorAll('input, textarea').forEach(field => {
    field.value = field.value.trim();
    field.setCustomValidity(field.required && !field.value ? 'Merci de renseigner ce champ.' : '');
   });
   const phone = form.elements.customer_phone;
   const digits = phone.value.replace(/\D/g, '');
   if (phone.value && (!/^(?:\+|00)?[\d\s().-]{7,24}$/.test(phone.value) || digits.length < 7 || digits.length > 15)) phone.setCustomValidity('Vérifiez votre numéro de téléphone, avec son indicatif si nécessaire.');
   constraints();
   if (!Number.isInteger(Number(quantityField.value))) quantityField.setCustomValidity('Choisissez une quantité entière.');
   if (!form.reportValidity()) return;
   syncQuantity(); update();
   // Le client relit et envoie lui-même son message dans WhatsApp.
   location.assign(urlFor(message(true)));
  });
  window.addEventListener('pagehide', () => {
   leaving = true; cancelAnimation();
   if (frame) cancelAnimationFrame(frame); frame = 0;
   if (dialog.open) dialog.close();
   if (locked) document.documentElement.style.overflow = oldOverflow;
   locked = false; closing = false;
   form.reset();
   form.querySelectorAll('input, textarea').forEach(field => field.setCustomValidity(''));
   const preview = form.querySelector('[data-wa-message]');
   if (preview) preview.textContent = '';
  });
 });
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
})();
