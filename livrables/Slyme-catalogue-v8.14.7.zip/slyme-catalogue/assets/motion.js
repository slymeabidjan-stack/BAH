/* SLYME — défilement libre. Toucher et trackpad natifs, inertie souris seulement. */
(() => {
  // Les gestes tactiles restent entièrement gérés par le navigateur.
  if (!matchMedia('(hover:hover) and (pointer:fine)').matches) return;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const desktop = matchMedia('(min-width:768px) and (hover:hover) and (pointer:fine)');
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  function activate(track) {
    if (track.dataset.slymeMotionReady) return;
    track.dataset.slymeMotionReady = '3';
    let pointer = null, pressed = null, frame = 0, ignoreClick = 0;
    function unpress() {
      if (pressed) pressed.classList.remove('slyme-is-pressed');
      pressed = null;
    }
    function stop() {
      cancelAnimationFrame(frame); frame = 0;
      track.classList.remove('slyme-is-moving', 'slyme-is-dragging');
    }
    function coast(start, velocity, max) {
      if (reduce.matches || Math.abs(velocity) < .04) { stop(); return; }
      velocity = clamp(velocity, -3, 3);
      const began = performance.now(), decay = 190;
      track.classList.add('slyme-is-moving');
      function tick(now) {
        if (reduce.matches) { stop(); return; }
        const elapsed = now - began;
        const speed = Math.exp(-elapsed / decay);
        const raw = start + velocity * decay * (1 - speed);
        track.scrollLeft = clamp(raw, 0, max);
        if (raw <= 0 || raw >= max || Math.abs(velocity * speed) < .025 || elapsed > 1000) stop();
        else frame = requestAnimationFrame(tick);
      }
      frame = requestAnimationFrame(tick);
    }
    function move(event) {
      if (!pointer || pointer.id !== event.pointerId) return;
      if (event.buttons !== 1) { finish(true); return; }
      const dx = event.clientX - pointer.x, dy = event.clientY - pointer.y;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) unpress();
      if (!pointer.active && Math.abs(dy) > 5 && Math.abs(dy) > Math.abs(dx)) { finish(true); return; }
      if (!pointer.active && Math.abs(dx) > 5) {
        pointer.active = true;
        track.classList.add('slyme-is-moving', 'slyme-is-dragging');
        track.setPointerCapture(event.pointerId);
      }
      if (!pointer.active) return;
      const now = performance.now();
      const dt = Math.max(1, now - pointer.time);
      const left = clamp(pointer.left - dx, 0, pointer.max);
      const alpha = 1 - Math.exp(-dt / 28);
      pointer.velocity += alpha * ((left - pointer.last) / dt - pointer.velocity);
      pointer.last = left; pointer.time = now;
      if (!frame) frame = requestAnimationFrame(() => {
        frame = 0;
        if (pointer && pointer.active) track.scrollLeft = pointer.last;
      });
    }
    function finish(cancelled) {
      if (!pointer) return;
      const p = pointer; pointer = null;
      track.removeEventListener('pointermove', move);
      track.classList.remove('slyme-mouse-down'); unpress();
      if (p.active) {
        cancelAnimationFrame(frame); frame = 0;
        track.scrollLeft = p.last;
        track.classList.remove('slyme-is-dragging');
        ignoreClick = performance.now() + 400;
        const velocity = cancelled || performance.now() - p.time > 80 ? 0 : p.velocity;
        coast(p.last, velocity, p.max);
      } else stop();
      if (track.hasPointerCapture(p.id)) track.releasePointerCapture(p.id);
    }
    track.addEventListener('pointerenter', event => {
      if (event.pointerType === 'mouse') track.classList.toggle('slyme-can-drag', track.scrollWidth > track.clientWidth + 1);
    }, {passive:true});
    track.addEventListener('pointerdown', event => {
      if (pointer) finish(true);
      if (frame) stop();
      ignoreClick = 0;
      // Aucun gestionnaire pointermove n'est installé pour les gestes tactiles.
      if (event.pointerType !== 'mouse' || !event.isPrimary || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      // Une lecture de la géométrie avant les écritures, au début du geste.
      const left = track.scrollLeft, max = Math.max(0, track.scrollWidth - track.clientWidth);
      if (max < 1) return;
      track.scrollTo({left, behavior:'auto'});
      pointer = {id:event.pointerId, x:event.clientX, y:event.clientY, left, last:left, max, time:performance.now(), velocity:0, active:false};
      track.classList.add('slyme-mouse-down');
      const card = event.target.closest('.slyme-product-card');
      if (card && event.target.closest('a')) { pressed = card; pressed.classList.add('slyme-is-pressed'); }
      track.addEventListener('pointermove', move, {passive:true});
    }, {passive:true});
    track.addEventListener('pointerup', () => finish(false), {passive:true});
    track.addEventListener('pointercancel', () => finish(true), {passive:true});
    track.addEventListener('lostpointercapture', () => finish(true));
    track.addEventListener('pointerleave', () => { if (pointer && !pointer.active) finish(true); });
    track.addEventListener('click', event => {
      if (event.detail && performance.now() < ignoreClick) {
        event.preventDefault(); event.stopPropagation(); ignoreClick = 0;
      }
    }, true);
    track.addEventListener('dragstart', event => event.preventDefault());
    track.addEventListener('wheel', () => { if (frame && !pointer) stop(); }, {passive:true});
    track.addEventListener('keydown', event => {
      if (event.target !== track || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
      event.preventDefault(); stop();
      const card = track.querySelector('.slyme-product-card');
      const step = card.offsetWidth + (parseFloat(getComputedStyle(track).gap) || 0);
      const max = Math.max(0, track.scrollWidth - track.clientWidth);
      const left = event.key === 'Home' ? 0 : event.key === 'End' ? max : Math.round(track.scrollLeft / step) * step + (event.key === 'ArrowRight' ? step : -step);
      track.scrollTo({left:clamp(left, 0, max), behavior:reduce.matches ? 'auto' : 'smooth'});
    });
    track.addEventListener('focusin', () => { if (frame) stop(); });
    const controls = track.parentElement.querySelector('.slyme-carousel-controls');
    if (controls) {
      const previous = controls.querySelector('[data-slyme-prev]');
      const next = controls.querySelector('[data-slyme-next]');
      let limit = 0, navFrame = 0, observing = false;
      const render = () => {
        navFrame = 0;
        const left = track.scrollLeft;
        previous.disabled = left <= 1;
        next.disabled = left >= limit - 1;
      };
      const schedule = () => { if (!navFrame) navFrame = requestAnimationFrame(render); };
      const measure = () => {
        limit = Math.max(0, track.scrollWidth - track.clientWidth);
        controls.hidden = limit < 2;
        schedule();
      };
      const resize = 'ResizeObserver' in window ? new ResizeObserver(measure) : null;
      track.addEventListener('slyme:refresh', () => { if (observing) measure(); });
      const configure = () => {
        if (desktop.matches && !observing) {
          observing = true;
          track.addEventListener('scroll', schedule, {passive:true});
          if (resize) resize.observe(track);
          else window.addEventListener('resize', measure, {passive:true});
          measure();
        } else if (!desktop.matches && observing) {
          observing = false;
          track.removeEventListener('scroll', schedule);
          if (resize) resize.disconnect();
          else window.removeEventListener('resize', measure);
          cancelAnimationFrame(navFrame); navFrame = 0;
          controls.hidden = true;
        }
      };
      const navigate = direction => {
        if (pointer) finish(true);
        stop();
        const card = track.querySelector('.slyme-product-card');
        const gap = parseFloat(getComputedStyle(track).gap) || 0;
        const step = card.offsetWidth + gap;
        const distance = Math.max(1, Math.floor((track.clientWidth + gap) / step)) * step;
        track.scrollTo({left:clamp(track.scrollLeft + direction * distance, 0, limit), behavior:reduce.matches ? 'auto' : 'smooth'});
      };
      previous.addEventListener('click', () => navigate(-1));
      next.addEventListener('click', () => navigate(1));
      desktop.addEventListener('change', configure);
      configure();
    }
    track.querySelectorAll('img').forEach(img => {
      if (img.complete) return;
      img.classList.add('slyme-is-loading');
      const ready = () => img.classList.remove('slyme-is-loading');
      img.addEventListener('load', ready, {once:true});
      img.addEventListener('error', ready, {once:true});
    });
  }
  function start() {
    document.querySelectorAll('.slyme-products-grid[data-slyme-light]').forEach(root => {
      if (root.dataset.slymeLightReady) return;
      root.dataset.slymeLightReady = '3';
      const tracks = root.querySelectorAll('.slyme-product-grid');
      if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (entry.isIntersecting) { activate(entry.target); observer.unobserve(entry.target); }
          });
        }, {rootMargin:'500px 0px'});
        tracks.forEach(track => observer.observe(track));
      } else tracks.forEach(activate);
      root.addEventListener('focusin', event => {
        const track = event.target.closest('.slyme-product-grid');
        if (track) activate(track);
      });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
