/* Micro-interactions ponctuelles : pas de boucle d’animation, pas de bibliothèque externe. */
(() => {
 const start=()=>{
  const reduce=matchMedia('(prefers-reduced-motion: reduce)'),running=new Map();
  const play=(node,frames,duration=260,delay=0)=>{
   if(!node||reduce.matches||!node.animate||document.hidden)return;
   running.get(node)?.cancel();
   const animation=node.animate(frames,{duration,delay,easing:'cubic-bezier(.2,.7,.2,1)'});
   running.set(node,animation);
   const done=()=>{if(running.get(node)===animation)running.delete(node);};
   animation.onfinish=animation.oncancel=done;
  };
  const settle=()=>{running.forEach(a=>a.cancel());running.clear();};
  reduce.addEventListener('change',()=>{if(reduce.matches)settle();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)settle();});
  const enter=node=>play(node,[{opacity:.45,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],320);
  if('IntersectionObserver' in window){
   const observer=new IntersectionObserver(entries=>{
    entries.filter(e=>e.isIntersecting).forEach((entry,index)=>{
     observer.unobserve(entry.target);
     // Le contenu reste visible en CSS, y compris sans JavaScript.
     play(entry.target,[{opacity:.45,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],340,Math.min(index*35,105));
    });
   },{threshold:.12});
   document.querySelectorAll('.slyme-carousel-header,.slyme-hero-heading,.slyme-hero-purchase').forEach(node=>observer.observe(node));
  }
  document.addEventListener('click',event=>{
   const button=event.target.closest('.sls-option,.slyme-hero-swatch,.slyme-carousel-arrow,.sls-buybar-action,.slyme-whatsapp-link');
   if(button&&!button.disabled)play(button,[{transform:'scale(.965)'},{transform:'scale(1)'}],210);

  });
  document.addEventListener('slyme:enter',event=>enter(event.target));
  document.addEventListener('slyme:price',event=>play(event.target,[{opacity:.4,transform:'translateY(3px)'},{opacity:1,transform:'translateY(0)'}],180));
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
