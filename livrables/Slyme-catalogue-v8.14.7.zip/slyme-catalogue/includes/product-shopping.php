<?php
/** Achat sur les fiches WooCommerce classiques. Les calculs restent à WooCommerce. */
defined('ABSPATH') || exit;
final class Slyme_Product_Shopping {
    const OPTION = 'slyme_shopping_v1';
    const FEEDBACK_SESSION = 'slyme_added_to_cart';
    public static function boot() {
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_filter('woocommerce_variable_price_html', array(__CLASS__, 'minimum_price'), 10, 2);
        add_filter('woocommerce_add_to_cart_redirect', array(__CLASS__, 'cart_redirect'), 10, 2);
        add_action('woocommerce_add_to_cart', array(__CLASS__, 'cart_added'), 10, 3);
        add_action('woocommerce_before_add_to_cart_button', array(__CLASS__, 'form_fields'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 25);
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'summary'), 6);
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'services'), 32);
        add_action('wp_footer', array(__CLASS__, 'bar'), 20);
        add_action('wp_footer', array(__CLASS__, 'feedback'), 21);
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('slyme_catalogue_settings_fields', array(__CLASS__, 'settings_fields'));
        add_action('slyme_presentation_extra_fields', array(__CLASS__, 'product_fields'), 10, 2);
        add_filter('slyme_presentation_sanitized', array(__CLASS__, 'sanitize_product'), 10, 2);
    }
    private static function settings() {
        $saved=get_option(self::OPTION,array());
        $saved=is_array($saved)?$saved:array();
        // Nouvelles mentions demandées, y compris lors de la mise à jour depuis V7.
        if('71'!==($saved['services_version']??''))$saved['services']=array('delay'=>'En moins d’1 h','warranty'=>'12 mois');
        return wp_parse_args($saved,array('bar'=>'1','visual'=>'1','summary'=>'1','color_map'=>'','services'=>array()));
    }
    private static function product() {
        if(!function_exists('is_product')||!is_product())return null;
        $product=wc_get_product(get_queried_object_id());
        return Slyme_Product_Presentation::enabled($product)?$product:null;
    }
    public static function minimum_price($html,$product) {
        // Seulement le prix initial de la fiche affichée ; les variantes et le catalogue restent natifs.
        if(!function_exists('is_product')||!is_product()||!$product instanceof WC_Product||$product->get_id()!==get_queried_object_id()||!Slyme_Product_Presentation::enabled($product))return $html;
        $min=$product->get_variation_price('min',true);$max=$product->get_variation_price('max',true);
        if(''===$min||''===$max||(float)$min===(float)$max)return $html;
        return '<span class="sls-starting-price">À partir de</span> '.wc_price($min).$product->get_price_suffix();
    }
    public static function form_fields() {
        $product=self::product();
        if($product&&$product->is_type(array('simple','variable')))echo '<input type="hidden" name="sls_native_product" value="'.esc_attr($product->get_id()).'">';
    }
    private static function submitted_product($product_id=0) {
        // Une confirmation de formulaire natif, jamais un ajout de l’administration ou d’une API.
        if('POST'!==($_SERVER['REQUEST_METHOD']??'')||is_admin()||(function_exists('wp_doing_ajax')&&wp_doing_ajax())||(defined('REST_REQUEST')&&REST_REQUEST))return null;
        $submitted=$_POST['add-to-cart']??'';$origin=$_POST['sls_native_product']??'';
        if(!is_scalar($submitted)||!is_scalar($origin)||!function_exists('wc_get_product'))return null;
        $submitted=absint(wp_unslash($submitted));
        if(!$submitted||$submitted!==absint(wp_unslash($origin))||($product_id&&$submitted!==absint($product_id)))return null;
        $product=wc_get_product($submitted);
        return Slyme_Product_Presentation::enabled($product)&&$product->is_type(array('simple','variable'))?$product:null;
    }
    public static function cart_redirect($url,$product=null) {
        $flag=$_POST['sls_go_to_cart']??'';
        if(!is_scalar($flag)||'1'!==wp_unslash($flag)||!self::submitted_product($product instanceof WC_Product?$product->get_id():0))return $url;
        return wc_get_cart_url();
    }
    public static function cart_added($cart_item_key,$product_id,$quantity) {
        if(!self::submitted_product($product_id)||!function_exists('WC')||!WC()->session)return;
        // Ce hook n’est émis qu’après l’ajout effectivement accepté par WooCommerce.
        WC()->session->set(self::FEEDBACK_SESSION,absint($product_id));
    }
    private static function feedback_pending() {
        if(!function_exists('WC')||!WC()->session)return false;
        $product_id=absint(WC()->session->get(self::FEEDBACK_SESSION,0));
        if(!$product_id)return false;
        $product=self::product();
        return ($product&&$product->get_id()===$product_id)||(function_exists('is_cart')&&is_cart());
    }
    private static function clean($value,$limit=350) {
        if(!is_scalar($value))return '';
        $value=sanitize_text_field((string)$value);
        return function_exists('mb_substr')?mb_substr($value,0,$limit):substr($value,0,$limit);
    }
    public static function service_schema() {
        return array('delay'=>array('Livraison express','Mention affichée sous Livraison express.','charge'), 'warranty'=>array('Garantie','Durée ou conditions de garantie affichées.','shield'));
    }
    private static function clean_services($input) {
        $out=array();$input=is_array($input)?$input:array();
        foreach(self::service_schema() as $key=>$field)$out[$key]=self::clean($input[$key]??'');
        return $out;
    }
    public static function sanitize_settings($input) {
        $input=is_array($input)?$input:array();$out=array();
        foreach(array('bar','visual','summary') as $key)$out[$key]=isset($input[$key])&&'1'===$input[$key]?'1':'0';
        $lines=is_string($input['color_map']??null)?preg_split('/\R/u',$input['color_map']):array();$valid=array();
        foreach(array_slice($lines,0,80) as $line){$pair=explode('|',$line,2);if(count($pair)!==2)continue;$name=self::clean(trim($pair[0]),80);$hex=sanitize_hex_color(trim($pair[1]));if($name!==''&&$hex)$valid[]=$name.' | '.$hex;}
        $out['color_map']=implode("\n",$valid);$out['services']=self::clean_services($input['services']??array());$out['services_version']='71';return $out;
    }
    public static function sanitize_product($out,$input) {
        $input=is_array($input['services']??null)?$input['services']:array();
        $out['services']=self::clean_services($input);
        $out['services']['version']='71';
        $out['services']['mode']=in_array($input['mode']??'',array('inherit','custom','off'),true)?$input['mode']:'inherit';
        return $out;
    }
    public static function register() {
        register_setting('slyme_catalogue',self::OPTION,array('type'=>'array','sanitize_callback'=>array(__CLASS__,'sanitize_settings'),'default'=>array()));
    }
    public static function settings_fields() {
        $settings=self::settings();
        echo '<h2>Achat et informations sur les fiches</h2>';
        foreach(array('bar'=>'Barre d’achat sur mobile','visual'=>'Pastilles de couleur et boutons de capacité','summary'=>'Résumé de trois caractéristiques sous le titre') as $key=>$label)echo '<p><input type="hidden" name="'.self::OPTION.'['.$key.']" value="0"><label><input type="checkbox" name="'.self::OPTION.'['.$key.']" value="1"'.checked($settings[$key],'1',false).'> '.esc_html($label).'</label></p>';
        echo '<h3>Livraison et garantie — valeurs communes</h3><p>Les mentions initiales sont « En moins d’1 h » et « 12 mois ». Un champ vidé reste masqué. Tu peux les remplacer ou les masquer dans Produits → Fiches Slyme. Elles ne modifient pas les frais de livraison calculés par WooCommerce au panier.</p><table class="form-table">';
        foreach(self::service_schema() as $key=>$field)echo '<tr><th><label for="slyme-service-'.$key.'">'.esc_html($field[0]).'</label></th><td><input class="large-text" id="slyme-service-'.$key.'" type="text" maxlength="350" name="'.self::OPTION.'[services]['.$key.']" value="'.esc_attr($settings['services'][$key]??'').'"><p class="description">'.esc_html($field[1]).'</p></td></tr>';
        echo '</table><h3>Teintes des pastilles (facultatif)</h3><label for="slyme-color-map">Une teinte par ligne : nom exact de la couleur | code hexadécimal</label><p><textarea id="slyme-color-map" class="large-text code" rows="4" name="'.self::OPTION.'[color_map]">'.esc_textarea($settings['color_map']).'</textarea></p><p>Les couleurs usuelles sont reconnues. Les noms inconnus restent affichés en texte. Tu peux préciser ici tes teintes exactes. Les variantes, prix, stocks et photos se configurent dans WooCommerce, pas dans ces champs.</p>';
    }
    public static function product_fields($product,$data) {
        $services=$data['services']??array();$mode=$services['mode']??'inherit';
        if('71'!==($services['version']??''))$services=self::settings()['services'];
        echo '<h3>Livraison et garantie</h3><label class="slp-admin-wide">Informations à afficher<select name="slyme_presentation[services][mode]" data-sls-service-mode>';
        foreach(array('inherit'=>'Utiliser les informations communes de la boutique','custom'=>'Renseigner les informations de ce produit','off'=>'Masquer sur ce produit') as $value=>$label)echo '<option value="'.$value.'"'.selected($mode,$value,false).'>'.esc_html($label).'</option>';
        echo '</select></label><p>Les valeurs communes se règlent dans Réglages → Slyme Catalogue. En mode personnalisé, seuls les champs remplis ci-dessous apparaissent. Ces textes ne changent pas les frais WooCommerce.</p><div class="slp-admin-grid" data-sls-service-fields>';
        foreach(self::service_schema() as $key=>$field)echo '<label>'.esc_html($field[0]).'<input type="text" maxlength="350" name="slyme_presentation[services]['.$key.']" value="'.esc_attr($services[$key]??'').'"><span>'.esc_html($field[1]).'</span></label>';
        echo '</div>';
    }
    public static function body_class($classes) {
        if(self::product())$classes[]='slyme-product-shopping';
        return $classes;
    }
    public static function assets() {
        $product=self::product();$added=self::feedback_pending();$cart=function_exists('is_cart')&&is_cart();if(!$product&&!$added&&!$cart)return;
        $base=plugin_dir_url(dirname(__FILE__)).'assets/';$settings=self::settings();
        if($product)wp_enqueue_style('slyme-product-description',$base.'product-description.css',array(),Slyme_Catalogue_V6::VERSION);
        wp_enqueue_style('slyme-product-shopping',$base.'product-shopping.css',array(),Slyme_Catalogue_V6::VERSION);
        $deps=$product&&$product->is_type('variable')?array('jquery','wc-add-to-cart-variation'):array('jquery');
        wp_enqueue_script('slyme-product-shopping',$base.'product-shopping.js',$deps,Slyme_Catalogue_V6::VERSION,array('in_footer'=>true,'strategy'=>'defer'));
        $colors=array();foreach(explode("\n",$settings['color_map']) as $line){$pair=explode('|',$line,2);if(count($pair)===2)$colors[trim($pair[0])]=trim($pair[1]);}
        wp_add_inline_script('slyme-product-shopping','window.slymeShopping='.wp_json_encode(array('visual'=>'1'===$settings['visual'],'colors'=>$colors,'cartUrl'=>wc_get_cart_url(),'shopUrl'=>wc_get_page_permalink('shop'),'addedToCart'=>$added,'productType'=>$product?Slyme_Product_Presentation::template($product):'','money'=>array('decimals'=>wc_get_price_decimals(),'decimal'=>wc_get_price_decimal_separator(),'thousand'=>wc_get_price_thousand_separator(),'format'=>get_woocommerce_price_format(),'symbol'=>get_woocommerce_currency_symbol()))).';','before');
    }
    public static function feedback() {
        $added=self::feedback_pending();
        if(!self::product()&&!$added&&!(function_exists('is_cart')&&is_cart()))return;
        if($added)WC()->session->set(self::FEEDBACK_SESSION,null);
        echo '<div data-sls-feedback class="sls-feedback" role="status" aria-live="polite" aria-atomic="true" hidden><div class="sls-feedback-card"><span class="sls-feedback-icon" aria-hidden="true">✓</span><div><strong data-sls-feedback-title></strong><p data-sls-feedback-message></p><div class="sls-feedback-actions"><button type="button" data-sls-feedback-dismiss>Continuer mes achats</button><a data-sls-feedback-cart href="'.esc_url(wc_get_cart_url()).'">Voir le panier</a></div></div><button type="button" class="sls-feedback-close" data-sls-feedback-dismiss aria-label="Fermer">×</button></div></div>';
    }
    public static function summary() {
        $product=self::product();if(!$product||'1'!==self::settings()['summary'])return;
        $specs=Slyme_Product_Presentation::specs($product);$type=Slyme_Product_Presentation::template($product);
        $order=array('phone'=>array('display','storage','battery'),'computer'=>array('processor','memory','storage'),'accessory'=>array('compatibility','material','protection'),'generic'=>array('compatibility','connection','material'));
        $picked=array();
        foreach($order[$type]??array() as $key)if(isset($specs[$key]))$picked[$key]=$specs[$key];
        foreach($specs as $key=>$row)if(count($picked)<3&&$row['highlight']&&!isset($picked[$key]))$picked[$key]=$row;
        if(!$picked)return;
        echo '<ul class="sls-highlights" aria-label="Le produit en bref">';
        foreach(array_slice($picked,0,3,true) as $key=>$row)echo '<li><span><span class="sls-highlight-label">'.esc_html($row['label']).'</span><span class="sls-highlight-value" data-sls-spec="'.esc_attr($key).'">'.esc_html($row['value']).'</span></span></li>';
        echo '</ul>';
    }
    public static function services() {
        $product=self::product();if(!$product)return;
        $data=$product->get_meta(Slyme_Product_Presentation::META,true);$custom=is_array($data)?($data['services']??array()):array();$mode=$custom['mode']??'inherit';
        if('off'===$mode)return;
        $services='custom'===$mode&&'71'===($custom['version']??'')?$custom:self::settings()['services'];
        $rows=array();foreach(self::service_schema() as $key=>$field)if(!empty($services[$key]))$rows[$key]=$field;
        if(!$rows)return;
        echo '<section class="sls-services" aria-label="Livraison et garantie"><h2>Livraison &amp; garantie</h2><dl>';
        foreach($rows as $key=>$field)echo '<div class="sls-service"><dt><span class="sls-icon">'.Slyme_Product_Presentation::icon($field[2]).'</span>'.esc_html($field[0]).'</dt><dd>'.esc_html($services[$key]).'</dd></div>';
        echo '</dl></section>';
    }
    public static function bar() {
        $product=self::product();if(!$product||'1'!==self::settings()['bar']||!$product->is_type(array('simple','variable')))return;
        if($product->is_type('simple')&&(!$product->is_purchasable()||!$product->is_in_stock()))return;
        $bar_price=$product->get_price_html();
        // Inline et limité à la barre : reste présent même si un cache sert un ancien CSS externe.
        $bar_css=file_get_contents(dirname(__DIR__).'/assets/buybar.css');
        if(false!==$bar_css)echo '<style id="slyme-buybar-critical" data-no-optimize="1">'.$bar_css.'</style>';
        $rating='';
        if($product->get_rating_count()>0){$average=(float)$product->get_average_rating();$rating='<span class="sls-buybar-rating" style="--sls-rating:'.esc_attr(min(100,max(0,$average*20))).'%" role="img" aria-label="'.esc_attr('Note : '.$average.' sur 5, '.$product->get_rating_count().' avis').'">★★★★★</span>';}
        $image=$product->get_image('woocommerce_gallery_thumbnail',array('class'=>'sls-buybar-image','loading'=>'lazy','decoding'=>'async','sizes'=>'64px','data-no-lazy'=>'1'));
        echo '<aside class="sls-buybar" data-sls-bar hidden aria-label="Achat rapide"><div class="sls-buybar-product">'.$image.'<div class="sls-buybar-info"><span class="sls-buybar-name">'.esc_html($product->get_name()).'</span><span class="sls-buybar-caption">'.($product->is_type('variable')?'Sélectionne tes options':'Ton prochain coup de cœur').'</span><span class="sls-buybar-status" role="status" aria-live="polite"></span>'.$rating.'</div></div><div class="sls-buybar-purchase"><div class="sls-buybar-price">'.wp_kses_post($bar_price).'</div><button type="button" class="sls-buybar-action"><svg width="17" height="17" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h2l2.4 11.5a2 2 0 0 0 2 1.5H18a2 2 0 0 0 2-1.6L22 7H6"/><circle cx="10" cy="21" r="1"/><circle cx="19" cy="21" r="1"/></svg><span>Je l’achète</span></button></div></aside>';
    }
}
