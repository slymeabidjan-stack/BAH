<?php
/** Présentation des fiches : données facultatives, contenu WooCommerce conservé. */
defined('ABSPATH') || exit;
final class Slyme_Product_Presentation {
    const META = '_slyme_presentation_v1';
    public static function boot() {
        // Les caractéristiques gardent le contenu, les onglets et la typographie du thème.
        add_action('add_meta_boxes_product', array(__CLASS__, 'metabox'));
        add_action('save_post_product', array(__CLASS__, 'save_metabox'), 30);
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_post_slyme_save_presentation', array(__CLASS__, 'save_page'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'admin_assets'));
        add_action('admin_init', function() { register_setting('slyme_catalogue', 'slyme_product_presentation', array('type'=>'string','sanitize_callback'=>function($v){return $v==='0'?'0':'1';},'default'=>'1')); });
    }
    public static function schema() {
        return array(
            'display'=>array('Écran','screen','phone computer','ecran|ecran principal|taille de l ecran'),
            'processor'=>array('Processeur','chip','phone computer','processeur|puce'),
            'memory'=>array('Mémoire vive','memory','phone computer','ram|memoire vive|memoire ram'),
            'storage'=>array('Stockage','storage','phone computer','stockage|stockage interne|capacite de stockage'),
            'camera'=>array('Photo et vidéo','camera','phone','appareil photo|camera principale|capteur principal'),
            'battery'=>array('Batterie','battery','phone computer','batterie|capacite de la batterie'),
            'charging'=>array('Recharge','charge','phone accessory','recharge|charge rapide|puissance de charge'),
            'graphics'=>array('Carte graphique','chip','computer','carte graphique|gpu|graphismes'),
            'system'=>array('Système','settings','phone computer','systeme|systeme d exploitation'),
            'connection'=>array('Connectivité','wifi','phone computer accessory generic','connectivite|connexion|connectique'),
            'ports'=>array('Ports','plug','computer','ports'),
            'compatibility'=>array('Compatibilité','phone','accessory generic','compatibilite|modeles compatibles'),
            'material'=>array('Matière','layers','accessory generic','matiere|materiau|materiaux'),
            'protection'=>array('Protection','shield','accessory','protection'),
            'finish'=>array('Finition','spark','accessory','finition'),
            'dimensions'=>array('Dimensions','ruler','computer accessory generic','dimensions'),
            'weight'=>array('Poids','feather','computer accessory generic','poids')
        );
    }
    private static function data($product) {
        $data=$product->get_meta(self::META, true);
        return is_array($data)?$data:array();
    }
    public static function enabled($product) {
        return $product instanceof WC_Product && '0'!==get_option('slyme_product_presentation','1') && 'off'!==(self::data($product)['template']??'auto');
    }
    private static function normalize($value) {
        $value=strtolower(remove_accents(html_entity_decode(wp_strip_all_tags($value),ENT_QUOTES,'UTF-8')));
        return trim(preg_replace('/[^a-z0-9]+/',' ',$value));
    }
    private static function auto_template($product) {
        $name=self::normalize($product->get_name());
        $slugs=wp_get_post_terms($product->get_id(),'product_cat',array('fields'=>'slugs'));
        $text=$name.' '.(is_wp_error($slugs)?'':implode(' ',$slugs));
        if(preg_match('/\b(coque|coques|chargeur|chargeurs|cable|support|accessoires|protection)\b/',$text))return 'accessory';
        if(preg_match('/\b(ordinateur|ordinateurs|laptop|laptops|macbook|imac|desktop)\b/',$text))return 'computer';
        if(preg_match('/\b(smartphone|smartphones|iphone|redmi|pixel|galaxy s\d+|galaxy z|galaxy a\d+)\b/',$text))return 'phone';
        return 'generic';
    }
    public static function template($product) {
        $type=self::data($product)['template']??'auto';
        return in_array($type,array('phone','computer','accessory','generic'),true)?$type:self::auto_template($product);
    }
    private static function key_for($label) {
        $label=self::normalize($label);
        foreach(self::schema() as $key=>$field)foreach(explode('|',$field[3]) as $alias)if($label===self::normalize($alias))return $key;
        return '';
    }
    private static function text($value,$limit=240) {
        if(!is_scalar($value))return '';
        $value=trim(preg_replace('/\s+/u',' ',sanitize_text_field((string)$value)));
        return function_exists('mb_substr')?mb_substr($value,0,$limit):substr($value,0,$limit);
    }
    public static function specs($product) {
        $data=self::data($product);$values=array();
        if(!isset($data['auto_specs'])||$data['auto_specs']) {
            foreach($product->get_attributes() as $attribute) {
                if(!$attribute->get_visible())continue;
                $key=self::key_for(wc_attribute_label($attribute->get_name()));
                if($key){$value=self::text($product->get_attribute($attribute->get_name()));if($value!=='')$values[$key]=$value;}
            }
            // Uniquement les lignes explicites « Libellé : valeur », jamais une valeur devinée.
            preg_match_all('/<(li|p)\b[^>]*>(.*?)<\/\1>/is',$product->get_description(),$matches);
            foreach($matches[2] as $line) {
                $line=trim(preg_replace('/\s+/u',' ',html_entity_decode(wp_strip_all_tags($line),ENT_QUOTES,'UTF-8')));
                if(!preg_match('/^([^:]{2,65})\s*:\s*(.{1,180})$/u',$line,$pair))continue;
                $key=self::key_for($pair[1]);
                if($key&&!isset($values[$key]))$values[$key]=self::text($pair[2]);
            }
        }
        foreach(($data['fields']??array()) as $key=>$value)if(isset(self::schema()[$key])&&$value!=='')$values[$key]=$value;
        $result=array();$type=self::template($product);
        foreach(self::schema() as $key=>$field) {
            if(!isset($values[$key])||$values[$key]==='')continue;
            $result[$key]=array('label'=>$field[0],'value'=>$values[$key],'icon'=>$field[1],'note'=>$data['notes'][$key]??'','highlight'=>in_array($type,explode(' ',$field[2]),true));
        }
        foreach(($data['extra']??array()) as $index=>$row)$result['extra_'.$index]=array('label'=>$row[0],'value'=>$row[1],'icon'=>'settings','note'=>'','highlight'=>false);
        return $result;
    }
    public static function icon($name) {
        $paths=array(
            'screen'=>'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
            'phone'=>'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 5h4m-3 14h2"/>',
            'chip'=>'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 1v5m6-5v5M9 18v5m6-5v5M1 9h5m-5 6h5m12-6h5m-5 6h5"/><rect x="9" y="9" width="6" height="6" rx="1"/>',
            'memory'=>'<rect x="2" y="6" width="20" height="11" rx="2"/><path d="M5 10h3v3H5zm6 0h3v3h-3zm6 0h2v3h-2M6 17v3m4-3v3m4-3v3m4-3v3"/>',
            'storage'=>'<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M4 15h16m-12 3h.01M11 18h.01"/><circle cx="12" cy="9" r="3"/>',
            'camera'=>'<path d="M8 5l2-2h4l2 2h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><circle cx="12" cy="12" r="4"/>',
            'battery'=>'<rect x="2" y="6" width="18" height="12" rx="3"/><path d="M23 10v4M6 10v4m4-4v4m4-4v4"/>',
            'charge'=>'<path d="m13 2-9 12h7l-1 8 10-13h-8Z"/>',
            'wifi'=>'<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0m-11 4a6 6 0 0 1 8 0"/><circle cx="12" cy="20" r=".8"/>',
            'plug'=>'<path d="M8 2v5m8-5v5M6 7h12v4a6 6 0 0 1-12 0Zm6 10v5"/>',
            'layers'=>'<path d="m12 3 10 5-10 5L2 8Zm-10 9 10 5 10-5M2 16l10 5 10-5"/>',
            'shield'=>'<path d="m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6Z"/><path d="m8 12 3 3 5-6"/>',
            'spark'=>'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5ZM20 2v4m-2-2h4"/>',
            'ruler'=>'<path d="m3 15 12-12 6 6L9 21Zm4-4 3 3m1-7 3 3m1-7 3 3"/>',
            'feather'=>'<path d="M20 4C14-2 4 8 7 17c9 3 19-7 13-13ZM3 22 16 9m-8 7h7"/>',
            'box'=>'<path d="m12 2 10 5v10l-10 5-10-5V7Zm-10 5 10 5 10-5M12 12v10M7 4.5l10 5v5"/>',
            'settings'=>'<path d="M4 5h16M4 12h16M4 19h16"/><circle cx="8" cy="5" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="10" cy="19" r="2"/>',
            'help'=>'<circle cx="12" cy="12" r="10"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4m0 4h.01"/>'
        );
        return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'.($paths[$name]??$paths['settings']).'</svg>';
    }
    public static function metabox() {
        add_meta_box('slyme-product-presentation','Slyme — Fiche produit premium',array(__CLASS__,'box_form'),'product','normal','default');
    }
    public static function box_form($post) {
        $product=wc_get_product($post->ID);if($product)self::fields($product);
    }
    public static function fields($product) {
        $data=self::data($product);$mode=$data['template']??'auto';$auto=self::auto_template($product);$detected=self::specs($product);
        wp_nonce_field('slyme_presentation_'.$product->get_id(),'slyme_presentation_nonce');
        echo '<div class="slp-admin" data-slp-admin data-auto-template="'.esc_attr($auto).'"><p>La description habituelle reste conservée. Les champs vides ne créent aucun bloc. Les informations saisies ici sont prioritaires sur les données détectées.</p><label class="slp-admin-wide">Présentation<select name="slyme_presentation[template]" data-slp-template>';
        foreach(array('auto'=>'Automatique','phone'=>'Smartphone','computer'=>'Ordinateur','accessory'=>'Accessoire','generic'=>'Autre produit','off'=>'Présentation WooCommerce classique') as $key=>$label)echo '<option value="'.$key.'"'.selected($mode,$key,false).'>'.esc_html($label).'</option>';
        echo '</select></label><label class="slp-admin-wide">Phrase d’introduction (facultatif)<input type="text" maxlength="180" name="slyme_presentation[intro]" value="'.esc_attr($data['intro']??'').'" placeholder="Laisser vide pour afficher le nom du produit"></label><label class="slp-admin-check"><input type="checkbox" name="slyme_presentation[auto_specs]" value="1"'.checked(!isset($data['auto_specs'])||$data['auto_specs'],true,false).'> Reprendre les attributs visibles et les lignes « Libellé : valeur » reconnues dans la description.</label><h3>Caractéristiques</h3><p>Une valeur courte donne une carte plus lisible. Le détail sous la valeur est facultatif.</p><div class="slp-admin-grid">';
        foreach(self::schema() as $key=>$field){
            echo '<fieldset data-slp-types="'.esc_attr($field[2]).'"><legend>'.esc_html($field[0]).'</legend><label>Valeur<input type="text" maxlength="240" name="slyme_presentation[fields]['.$key.']" value="'.esc_attr($data['fields'][$key]??'').'" placeholder="'.esc_attr(isset($detected[$key])?'Détecté : '.$detected[$key]['value']:'Facultatif').'"></label><label>Détail court<input type="text" maxlength="240" name="slyme_presentation[notes]['.$key.']" value="'.esc_attr($data['notes'][$key]??'').'"></label></fieldset>';
        }
        echo '</div><label class="slp-admin-wide">Autres caractéristiques — une ligne par information : Libellé | Valeur<textarea rows="4" name="slyme_presentation[extra]">'.esc_textarea(implode("\n",array_map(function($r){return $r[0].' | '.$r[1];},$data['extra']??array()))).'</textarea></label><label class="slp-admin-wide">Dans la boîte — un élément réellement fourni par ligne<textarea rows="4" name="slyme_presentation[box]">'.esc_textarea(implode("\n",$data['box']??array())).'</textarea></label><h3>Questions fréquentes (facultatif)</h3><p>Une question et sa réponse sont nécessaires pour afficher une rubrique.</p>';
        for($i=0;$i<4;$i++)echo '<fieldset class="slp-admin-faq"><legend>Question '.($i+1).'</legend><label>Question<input type="text" maxlength="180" name="slyme_presentation[faq]['.$i.'][0]" value="'.esc_attr($data['faq'][$i][0]??'').'"></label><label>Réponse<textarea rows="2" maxlength="1600" name="slyme_presentation[faq]['.$i.'][1]">'.esc_textarea($data['faq'][$i][1]??'').'</textarea></label></fieldset>';
        do_action('slyme_presentation_extra_fields',$product,$data);
        echo '</div>';
    }
    public static function sanitize($input) {
        if(!is_array($input))$input=array();
        $template=self::text($input['template']??'auto',20);
        $out=array('template'=>in_array($template,array('auto','phone','computer','accessory','generic','off'),true)?$template:'auto','intro'=>self::text($input['intro']??'',180),'auto_specs'=>!empty($input['auto_specs']),'fields'=>array(),'notes'=>array(),'extra'=>array(),'box'=>array(),'faq'=>array());
        foreach(array('fields','notes') as $group)foreach(self::schema() as $key=>$unused){$value=self::text($input[$group][$key]??'');if($value!=='')$out[$group][$key]=$value;}
        $extra=is_string($input['extra']??null)?$input['extra']:'';
        foreach(array_slice(preg_split('/\R/u',$extra),0,30) as $line){$parts=explode('|',$line,2);if(count($parts)===2){$label=self::text($parts[0],80);$value=self::text($parts[1]);if($label!==''&&$value!=='')$out['extra'][]=array($label,$value);}}
        $box=is_string($input['box']??null)?$input['box']:'';
        foreach(array_slice(preg_split('/\R/u',$box),0,12) as $line){$value=self::text($line,180);if($value!=='')$out['box'][]=$value;}
        foreach(array_slice(is_array($input['faq']??null)?$input['faq']:array(),0,4) as $row){
            if(!is_array($row))continue;$q=self::text($row[0]??'',180);$a=is_string($row[1]??null)?sanitize_textarea_field($row[1]):'';
            $a=function_exists('mb_substr')?mb_substr($a,0,1600):substr($a,0,1600);
            if($q!==''&&$a!=='')$out['faq'][]=array($q,$a);
        }
        return apply_filters('slyme_presentation_sanitized',$out,$input);
    }
    public static function save_metabox($id) {
        if(wp_is_post_revision($id)||wp_is_post_autosave($id)||!current_user_can('edit_post',$id))return;
        if(!isset($_POST['slyme_presentation_nonce'])||!is_string($_POST['slyme_presentation_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slyme_presentation_nonce'])),'slyme_presentation_'.$id))return;
        if(!isset($_POST['slyme_presentation'])||!is_array($_POST['slyme_presentation']))return;
        $product=wc_get_product($id);if(!$product)return;
        $product->update_meta_data(self::META,self::sanitize(wp_unslash($_POST['slyme_presentation'])));$product->save_meta_data();
    }
    public static function menu() {
        add_submenu_page('edit.php?post_type=product','Fiches Slyme','Fiches Slyme','edit_products','slyme-product-design',array(__CLASS__,'page'));
    }
    public static function page() {
        if(!current_user_can('edit_products'))return;
        $id=isset($_GET['product_id'])?absint($_GET['product_id']):0;$product=$id?wc_get_product($id):null;
        echo '<div class="wrap"><h1>Fiches Slyme</h1>';
        if($product&&'product'===get_post_type($id)&&current_user_can('edit_post',$id)){
            if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>La présentation a été enregistrée.</p></div>';
            echo '<p><a href="'.esc_url(admin_url('edit.php?post_type=product&page=slyme-product-design')).'">← Choisir un autre produit</a></p><h2>'.esc_html($product->get_name()).'</h2><form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="slyme_save_presentation"><input type="hidden" name="product_id" value="'.absint($id).'">';
            self::fields($product);submit_button('Enregistrer la fiche');echo '</form><p><a href="'.esc_url(get_permalink($id)).'" target="_blank" rel="noopener noreferrer">Voir la fiche produit ↗</a></p>';
        }else{
            $search=isset($_GET['slyme_find'])?self::text(wp_unslash($_GET['slyme_find']),80):'';
            echo '<p>Choisis un produit pour personnaliser ses cartes, sa fiche technique et ses questions fréquentes.</p><form method="get"><input type="hidden" name="post_type" value="product"><input type="hidden" name="page" value="slyme-product-design"><label for="slp-find">Nom du produit </label><input id="slp-find" type="search" name="slyme_find" value="'.esc_attr($search).'"><button class="button">Rechercher</button></form>';
            $query=new WP_Query(array('post_type'=>'product','post_status'=>array('publish','draft','pending','private'),'posts_per_page'=>20,'s'=>$search,'search_columns'=>array('post_title'),'orderby'=>'modified','order'=>'DESC','no_found_rows'=>true));
            echo '<ul>';foreach($query->posts as $post)if(current_user_can('edit_post',$post->ID))echo '<li><a href="'.esc_url(add_query_arg(array('post_type'=>'product','page'=>'slyme-product-design','product_id'=>$post->ID),admin_url('edit.php'))).'">'.esc_html($post->post_title).'</a></li>';echo '</ul><p>Les 20 premiers résultats sont affichés. Précise le nom pour retrouver un autre produit.</p>';
        }
        echo '</div>';
    }
    public static function save_page() {
        $id=isset($_POST['product_id'])?absint($_POST['product_id']):0;
        if(!$id||'product'!==get_post_type($id)||!current_user_can('edit_post',$id))wp_die('Accès refusé.',403);
        check_admin_referer('slyme_presentation_'.$id,'slyme_presentation_nonce');
        self::save_metabox($id);
        wp_safe_redirect(add_query_arg(array('post_type'=>'product','page'=>'slyme-product-design','product_id'=>$id,'saved'=>1),admin_url('edit.php')));exit;
    }
    public static function admin_assets($hook) {
        $screen=get_current_screen();
        if(!$screen||!(strpos($hook,'slyme-product-design')!==false||($screen->post_type==='product'&&in_array($hook,array('post.php','post-new.php'),true))))return;
        $base=plugin_dir_url(dirname(__FILE__)).'assets/';
        wp_enqueue_style('slyme-product-admin',$base.'product-admin.css',array(),Slyme_Catalogue_V6::VERSION);
        wp_enqueue_script('slyme-product-admin',$base.'product-admin.js',array(),Slyme_Catalogue_V6::VERSION,true);
    }
}
