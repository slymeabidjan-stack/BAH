<?php
/**
 * Plugin Name: Slyme — Catalogue fluide
 * Description: Catalogue fluide, slider Galaxy, fiches produit premium et commande WhatsApp.
 * Version: 8.14.6
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: Slyme Abidjan
 * License: GPL-2.0-or-later
 */
defined('ABSPATH') || exit;

final class Slyme_Catalogue_V6 {
    const VERSION = '8.14.6';
    private static $config;
    private static $data = array();
    private static $curated_ids;
    private static $section_cache;
    private static $section_dirty = false;

    public static function boot() {
        foreach (array('woocommerce_update_product','woocommerce_new_product','woocommerce_update_product_variation','woocommerce_product_set_stock','woocommerce_variation_set_stock','woocommerce_product_set_stock_status','woocommerce_variation_set_stock_status','woocommerce_delete_product_transients','deleted_post','trashed_post','untrashed_post','post_updated','set_object_terms','update_option_woocommerce_hide_out_of_stock_items') as $hook) add_action($hook, array(__CLASS__, 'clear_lists_cache'));
        foreach (array('added_post_meta','updated_post_meta','deleted_post_meta') as $hook) add_action($hook, array(__CLASS__, 'stock_meta_changed'), 10, 3);
        add_action('admin_init',array(__CLASS__,'purge_after_update'));
        add_filter('wp_inline_script_attributes',array(__CLASS__,'essential_inline_attributes'));
        add_filter('script_loader_tag',array(__CLASS__,'essential_script_tag'),10,2);
        add_filter('style_loader_tag',array(__CLASS__,'essential_style_tag'),10,2);
        add_filter('litespeed_optm_js_defer_exc',array(__CLASS__,'essential_js_excludes'));
        add_filter('woocommerce_single_product_image_thumbnail_html',array(__CLASS__,'gallery_image_loading'),10,2);
        add_filter('body_class', array(__CLASS__, 'body_class'));
        add_shortcode('slyme_catalogue', array(__CLASS__, 'catalogue'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('rest_api_init', array(__CLASS__, 'routes'));
        add_action('woocommerce_single_product_summary', array(__CLASS__, 'whatsapp'), 35);
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
        add_action('admin_notices', array(__CLASS__, 'dependency_notice'));
    }

    private static function config() {
        if (null === self::$config) {
            self::$config = json_decode(file_get_contents(__DIR__ . '/catalogue.json'), true);
        }
        return is_array(self::$config) ? self::$config : array('sections' => array(), 'products' => array(), 'images' => array());
    }

    private static function catalogue_page() {
        return is_singular() && has_shortcode((string) get_post_field('post_content', get_queried_object_id()), 'slyme_catalogue');
    }
    public static function body_class($classes) {
        if (self::catalogue_page()) $classes[] = 'slyme-catalogue-page';
        return $classes;
    }
    public static function assets() {
        $url = plugin_dir_url(__FILE__) . 'assets/';
        if (current_user_can('manage_options') && isset($_GET['slyme_diagnostic'])) wp_enqueue_script('slyme-diagnostic', $url . 'diagnostic.js', array(), self::VERSION, array('in_footer'=>true, 'strategy'=>'defer'));
        wp_register_script('slyme-interactions', $url . 'interactions.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_register_style('slyme-catalogue-v5', $url . 'catalogue.css', array(), self::VERSION);
        wp_register_script('slyme-motion-v5', $url . 'motion.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_register_script('slyme-hero-v5', $url . 'hero.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        wp_register_script('slyme-catalogue-v5', $url . 'catalogue.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        if (self::catalogue_page()) {
            self::enqueue();
        }
        if (function_exists('is_product') && is_product()) {
            wp_enqueue_style('slyme-whatsapp-v5', $url . 'whatsapp.css', array(), self::VERSION);
            wp_enqueue_script('slyme-whatsapp-v5', $url . 'whatsapp.js', array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
        }
    }

    private static function enqueue() {
        wp_enqueue_style('slyme-catalogue-v5');
        if (empty($_GET['slyme_collection']) && empty($_GET['slyme_search'])) {
            wp_enqueue_script('slyme-motion-v5');
            wp_enqueue_script('slyme-hero-v5');
        }
        wp_enqueue_script('slyme-catalogue-v5');
    }

    private static function public_product($product) {
        return $product && 'product' === get_post_type($product->get_id()) && 'publish' === $product->get_status() && !post_password_required($product->get_id()) && '' === (string) get_post_field('post_password', $product->get_id()) && in_array($product->get_catalog_visibility(), array('visible', 'catalog'), true);
    }

    public static function product_data($product, $with_hero = false, $with_benefit = true) {
        if (!self::public_product($product)) return null;
        $id = $product->get_id();
        $data_key = $id . ($with_benefit ? ':full' : ':search');
        if (isset(self::$data[$data_key])) {
            $cached = self::$data[$data_key];
            if ($with_hero) $cached['hero'] = self::hero_data($product, $cached);
            return $cached;
        }
        $config = self::config();
        $price = $product->get_price();
        $prefix = '';
        if ($product->is_type('variable')) {
            $price = $product->get_variation_price('min', true);
            $max = $product->get_variation_price('max', true);
            if ('' !== $price && (float) $max > (float) $price) $prefix = 'À partir de';
        } elseif ($product->is_type('grouped')) {
            $amounts = array();
            foreach ($product->get_children() as $child_id) {
                $child = wc_get_product($child_id);
                if (self::public_product($child) && '' !== $child->get_price()) $amounts[] = wc_get_price_to_display($child);
            }
            $price = $amounts ? min($amounts) : '';
            if ($amounts) $prefix = 'À partir de';
        } elseif ('' !== $price) {
            $price = wc_get_price_to_display($product);
        }
        $currency = get_woocommerce_currency();
        $symbol = in_array($currency, array('XOF', 'XAF'), true) ? 'FCFA' : html_entity_decode(get_woocommerce_currency_symbol($currency), ENT_QUOTES, 'UTF-8');
        $image_id = $product->get_image_id();
        $image = isset($config['images'][$image_id]) ? $config['images'][$image_id] : '';
        $current_image = wp_get_attachment_url($image_id);
        if ($image && $current_image) {
            $current_path = strstr((string) wp_parse_url($current_image, PHP_URL_PATH), '/wp-content/uploads/');
            $optimized_path = strstr((string) wp_parse_url($image, PHP_URL_PATH), '/wp-content/uploads/');
            if (!$current_path || rawurldecode($current_path) !== rawurldecode((string) $optimized_path)) $image = '';
        }
        if (!$image) $image = wp_get_attachment_image_url($image_id, 'medium');
        if (!$image) $image = wc_placeholder_img_src('woocommerce_thumbnail');
        $brand = isset($config['products'][$id]['brand']) ? $config['products'][$id]['brand'] : '';
        if (taxonomy_exists('product_brand')) {
            $brands = get_the_terms($id, 'product_brand');
            if ($brands && !is_wp_error($brands)) $brand = reset($brands)->name;
        }
        $result = array(
            'id' => $id,
            'name' => html_entity_decode(wp_strip_all_tags($product->get_name()), ENT_QUOTES, 'UTF-8'),
            'benefit' => $with_benefit ? self::card_benefit($product) : '',
            'url' => get_permalink($id),
            'image' => esc_url_raw($image),
            'srcset' => self::responsive_image($image_id,$image),
            'brand' => html_entity_decode($brand, ENT_QUOTES, 'UTF-8'),
            'price' => array(
                'label' => $prefix,
                'amount' => '' === $price ? '' : number_format((float) $price, wc_get_price_decimals(), ',', ' '),
                'currency' => $symbol,
                'suffix' => html_entity_decode(wp_strip_all_tags($product->get_price_suffix()), ENT_QUOTES, 'UTF-8'),
            ),
        );
        self::$data[$data_key] = $result;
        if ($with_hero) $result['hero'] = self::hero_data($product, $result);
        return $result;
    }

    private static function hero_data($product, $data) {
        $config = self::config();
        if (empty($config['hero']) || $product->get_slug() !== $config['hero']['slug']) return null;
        $settings = $config['hero'];
        $colors = array();
        // Les variantes publiées dans WooCommerce déterminent les couleurs et leurs prix.
        if ($product->is_type('variable')) {
            $prices = $product->get_variation_prices(true);
            $variations = $product->get_available_variations('objects');
            foreach ($settings['colors'] as $color) {
                $amounts = array();
                $image = ''; $hero_image_id=0;
                foreach ($variations as $variation) {
                    $attributes = $variation->get_variation_attributes();
                    if (!isset($attributes['attribute_pa_couleur']) || $attributes['attribute_pa_couleur'] !== $color['key']) continue;
                    $vid = $variation->get_id();
                    if (!isset($prices['price'][$vid]) || '' === $prices['price'][$vid]) continue;
                    $amounts[] = (float) $prices['price'][$vid];
                    if (!$image && $variation->get_image_id()) { $hero_image_id=$variation->get_image_id();$image=wp_get_attachment_image_url($hero_image_id,'full'); }
                }
                if (!$amounts) continue;
                $price = $data['price'];
                $price['amount'] = number_format(min($amounts), wc_get_price_decimals(), ',', ' ');
                $price['label'] = max($amounts) > min($amounts) ? 'À partir de' : '';
                $colors[] = array('key' => $color['key'], 'label' => $color['label'],
                    'image' => esc_url_raw($image ? $image : $color['image']), 'srcset'=>self::responsive_image($hero_image_id,$image,true),
                    'url' => add_query_arg('attribute_pa_couleur', $color['key'], $data['url']), 'price' => $price);
            }
        }
        $image = wp_get_attachment_image_url($product->get_image_id(), 'full');
        if (!$image && !empty($settings['colors'][0]['image'])) $image = $settings['colors'][0]['image'];
        return array('title' => preg_replace('/^Samsung\s+/iu', '', $data['name']),
            'tagline' => $settings['tagline'], 'image' => esc_url_raw($image), 'srcset'=>self::responsive_image($product->get_image_id(),$image,true), 'colors' => $colors);
    }

    private static function hero() {
        $config = self::config();
        if (empty($config['hero'])) return '';
        $settings = $config['hero'];
        $product = wc_get_product(absint($settings['id']));
        if (!$product || $product->get_slug() !== $settings['slug']) {
            $post = get_page_by_path($settings['slug'], OBJECT, 'product');
            $product = $post ? wc_get_product($post->ID) : null;
        }
        $data = self::product_data($product, true);
        if (!$data || empty($data['hero'])) return '';
        $hero = $data['hero'];
        $selected = $hero['colors'] ? $hero['colors'][0] : array('key' => 'blanc', 'label' => '', 'image' => $hero['image'], 'srcset'=>$hero['srcset'], 'url' => $data['url'], 'price' => $data['price']);
        $uid = wp_unique_id('slyme-hero-');
        $out = '<section class="slyme-hero" data-product-id="' . absint($data['id']) . '" data-tone="' . esc_attr($selected['key']) . '" aria-labelledby="' . $uid . '-title" data-slyme-hero-options="' . esc_attr(wp_json_encode($data)) . '">';
        $out .= '<div class="slyme-hero-heading"><p class="slyme-hero-eyebrow"><span>Samsung</span><span class="slyme-hero-badge">À la une</span></p><h2 class="slyme-hero-title" id="' . $uid . '-title">' . esc_html($hero['title']) . '</h2><p class="slyme-hero-copy">' . esc_html($hero['tagline']) . '</p></div>';
        $out .= '<div class="slyme-hero-media"><div class="slyme-hero-orbit" aria-hidden="true"></div><img data-no-lazy="1" class="slyme-hero-image" sizes="(min-width:1024px) 55vw, 90vw"' . (!empty($selected['srcset']) ? ' srcset="' . esc_attr($selected['srcset']) . '"' : '') . ' src="' . esc_url($selected['image']) . '" alt="' . esc_attr($hero['title'] . ($selected['label'] ? ' — ' . $selected['label'] : '')) . '" width="800" height="800" loading="eager" fetchpriority="high" decoding="async" draggable="false"><p class="slyme-hero-image-status" role="status" hidden>Photo indisponible pour cette couleur.</p></div>';
        $out .= '<div class="slyme-hero-purchase">' . self::price_html($selected['price']);
        $out .= '<div class="slyme-hero-colors"' . (!$hero['colors'] ? ' hidden' : '') . '><div class="slyme-hero-swatches" role="group" aria-label="Choisir une couleur">';
        foreach ($hero['colors'] as $index => $color) {
            // Sans JavaScript, les pastilles ouvrent directement la bonne couleur sur la fiche.
            $out .= '<a class="slyme-hero-swatch' . (0 === $index ? ' is-selected' : '') . '" data-slyme-color="' . esc_attr($color['key']) . '" href="' . esc_url($color['url']) . '" aria-label="' . esc_attr($color['label']) . '" title="' . esc_attr($color['label']) . '"><span aria-hidden="true"></span></a>';
        }
        $out .= '</div><p class="slyme-hero-color-name" aria-live="polite" aria-atomic="true">' . esc_html($selected['label']) . '</p></div>';
        $arrow = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg>';
        $out .= '<div class="slyme-hero-actions"><a class="slyme-hero-cta" data-slyme-hero-link href="' . esc_url($selected['url']) . '">Acheter ' . $arrow . '</a><a class="slyme-hero-details" data-slyme-hero-link data-slyme-details href="' . esc_url($selected['url'] . '#tab-description') . '">Détails <span aria-hidden="true">↗</span></a></div></div></section>';
        return $out;
    }

    private static function price_html($price) {
        $out = '<p class="slyme-product-price">';
        if ('' === $price['amount']) return $out . '<span class="slyme-price-request">Prix sur demande</span></p>';
        if ($price['label']) $out .= '<span class="slyme-price-label">' . esc_html($price['label']) . ' </span>';
        $out .= '<span class="slyme-price-amount">' . esc_html($price['amount']) . ' <span class="slyme-price-currency">' . esc_html($price['currency']) . '</span></span>';
        if ($price['suffix']) $out .= '<span class="slyme-price-note">' . esc_html($price['suffix']) . '</span>';
        return $out . '</p>';
    }

    private static function card_benefit($product) {
        // Read only existing product data, with no remote request or variation lookup.
        $clean = static function($value) {
            return trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags((string) $value), ENT_QUOTES, 'UTF-8')));
        };
        $short = static function($value) use ($clean) {
            $value = $clean($value);
            if (function_exists('mb_strlen') && mb_strlen($value) <= 72) return $value;
            if (!function_exists('mb_strlen') && strlen($value) <= 72) return $value;
            $prefix = function_exists('mb_substr') ? mb_substr($value, 0, 69) : substr($value, 0, 69);
            return preg_replace('/\s+\S*$/u', '', $prefix) . '…';
        };
        $key_for = static function($label) use ($clean) {
            $label = strtolower(remove_accents($clean($label)));
            $label = trim(preg_replace('/[^a-z0-9]+/', ' ', $label));
            $aliases = array(
                'storage'=>'stockage|stockage interne|capacite de stockage|stockage rom|rom',
                'memory'=>'ram|memoire vive|memoire ram',
                'battery'=>'batterie|autonomie|capacite de la batterie',
                'display'=>'ecran|taille de l ecran|ecran principal|affichage',
                'processor'=>'processeur|puce', 'camera'=>'camera principale|appareil photo|capteur principal',
                'compatibility'=>'compatibilite|modeles compatibles', 'material'=>'matiere|materiau|materiaux',
                'charging'=>'recharge|charge rapide|puissance de charge', 'connection'=>'connectivite|connexion|connectique',
                'capacity'=>'capacite', 'protection'=>'protection', 'finish'=>'finition', 'graphics'=>'carte graphique|gpu'
            );
            foreach ($aliases as $key=>$names) if (in_array($label, explode('|',$names), true)) return $key;
            return '';
        };
        $values = array();
        $schema = Slyme_Product_Presentation::schema();
        $meta = $product->get_meta(Slyme_Product_Presentation::META, true);
        foreach (is_array($meta) ? ($meta['fields'] ?? array()) : array() as $key=>$value) {
            if (is_scalar($value) && $clean($value) !== '' && isset($schema[$key])) $values[$key] = array($schema[$key][0], $clean($value));
        }
        foreach ($product->get_attributes() as $attribute) {
            if (!$attribute->get_visible()) continue;
            $label = wc_attribute_label($attribute->get_name());
            $key = $key_for($label);
            if ($key && !isset($values[$key])) {
                $value = $clean($product->get_attribute($attribute->get_name()));
                if ($value !== '') $values[$key] = array($label, $value);
            }
        }
        // Bound scanning; extract labelled lines, rows and heading/value pairs only.
        $description = $product->get_short_description() . '\n' . $product->get_description();
        $description = function_exists('mb_substr') ? mb_substr($description, 0, 24000) : substr($description, 0, 24000);
        preg_match_all('/<(?:p|li|tr|h[2-6])\b[^>]*>(.*?)<\/(?:p|li|tr|h[2-6])>/is', $description, $lines);
        $heading = '';
        foreach ($lines[0] as $index=>$markup) {
            $line = $clean(preg_replace('/<\/(?:td|th)>\s*<(?:td|th)\b[^>]*>/i', ': ', $lines[1][$index]));
            if (preg_match('/^<h[2-6]\b/i', $markup)) { $heading = $key_for($line); continue; }
            if (preg_match('/^([^:]{2,65}):\s*(.{1,240})$/u', $line, $pair)) {
                $key = $key_for($pair[1]);
                if ($key && !isset($values[$key])) $values[$key] = array($clean($pair[1]), $clean($pair[2]));
            } elseif ($heading && !isset($values[$heading]) && $line !== '' && (function_exists('mb_strlen') ? mb_strlen($line) : strlen($line)) <= 100) {
                $values[$heading] = array($schema[$heading][0] ?? ucfirst($heading), $line);
            }
            $heading = '';
        }
        $name = strtolower(remove_accents($product->get_name()));
        $order = array('storage','display','battery','memory','processor','camera','capacity','charging','compatibility','material','connection','protection','finish','graphics');
        if (preg_match('/watch|montre|mibro/', $name)) $order = array('battery','display','compatibility','connection','material');
        elseif (preg_match('/coque|etui|cable|chargeur|ecouteur|airpods|buds|power.?bank/', $name)) $order = array('compatibility','charging','capacity','battery','material','connection','protection','finish');
        elseif (preg_match('/macbook|imac|ordinateur|thinkpad|latitude|elitebook|vivobook|probook|ideapad|inspiron/', $name)) $order = array('processor','memory','storage','graphics','display','battery');
        foreach ($order as $key) if (isset($values[$key])) {
            list($label, $value) = $values[$key];
            if (in_array($key, array('storage','capacity'), true)) {
                preg_match_all('/\b(\d+(?:[.,]\d+)?)\s*(Go|To|GB|TB)\b/iu', $value, $capacities, PREG_SET_ORDER);
                $remainder = preg_replace('/\b\d+(?:[.,]\d+)?\s*(Go|To|GB|TB)\b|\b(?:ou|et)\b|[\s|,;\/]+/iu', '', $value);
                $sizes = array();
                foreach ($capacities as $capacity) {
                    $size = (float) str_replace(',', '.', $capacity[1]) * (in_array(strtolower($capacity[2]), array('to','tb'), true) ? 1024 : 1);
                    $sizes[(string) $size] = $capacity[1] . ' ' . $capacity[2];
                }
                if ($remainder === '' && count($sizes) > 1) {
                    ksort($sizes, SORT_NUMERIC);
                    $value = 'à partir de ' . reset($sizes);
                    $label = 'Stockage';
                }
            }
            return $short($label . ' : ' . $value);
        }
        // An existing introductory paragraph may be used when no labelled spec exists.
        foreach (array($product->get_short_description(), $product->get_description()) as $source) {
            if (preg_match('/<p\b[^>]*>(.*?)<\/p>/is', $source, $paragraph)) $source = $paragraph[1];
            else $source = preg_replace('/<h[1-6]\b[^>]*>.*?<\/h[1-6]>/is', '', $source);
            $text = $clean($source);
            if ($text !== '' && !preg_match('/https?:|\[.*?\]/i', $text)) return $short($text);
        }
        return '';
    }

    // Les fichiers utiles sont différés jusqu’à l’analyse HTML, jamais jusqu’au premier geste.
    public static function purge_after_update() {
        if(!current_user_can('manage_options') || get_option('slyme_catalogue_assets_version','')===self::VERSION)return;
        update_option('slyme_catalogue_assets_version',self::VERSION,false);
        self::clear_lists_cache();
        // Une seule purge à la mise à jour ; jamais au défilement ni à chaque visite.
        do_action('litespeed_purge_all');
    }
    public static function essential_inline_attributes($attributes) {
        $id=$attributes['id']??'';
        $essential=strpos($id,'slyme-')===0 || (function_exists('is_product') && is_product() && (strpos($id,'wc-add-to-cart-variation-')===0 || strpos($id,'wc-single-product-')===0));
        if($essential)$attributes['data-no-optimize']='1';
        return $attributes;
    }
    public static function essential_script_tag($tag,$handle) {
        $essential=strpos($handle,'slyme-')===0 || (function_exists('is_product') && is_product() && in_array($handle,array('jquery-core','jquery-migrate','wc-add-to-cart-variation','wc-single-product','flexslider','zoom','photoswipe','photoswipe-ui-default'),true));
        return $essential && strpos($tag,'data-no-optimize=')===false ? str_replace('<script ','<script data-no-optimize="1" ',$tag) : $tag;
    }
    public static function essential_style_tag($tag,$handle) {
        return strpos($handle,'slyme-')===0 && strpos($tag,'data-no-optimize=')===false ? str_replace('<link ','<link data-no-optimize="1" ',$tag) : $tag;
    }
    public static function essential_js_excludes($list) {
        $list=is_array($list)?$list:array();$list[]='/slyme-catalogue/assets/';
        if(function_exists('is_product') && is_product()) foreach(array('/jquery/jquery','/wc-add-to-cart-variation','/single-product','/jquery.flexslider','/jquery.zoom','/photoswipe') as $path)$list[]=$path;
        return array_values(array_unique($list));
    }
    public static function gallery_image_loading($html,$attachment_id) {
        // Conserve le lazy loading natif pour les photos suivantes.
        static $first=true;
        if($first){
            $tags=new WP_HTML_Tag_Processor($html);
            if($tags->next_tag('IMG')){$tags->set_attribute('data-no-lazy','1');$tags->set_attribute('loading','eager');$tags->set_attribute('fetchpriority','high');$html=$tags->get_updated_html();$first=false;}
        }
        return $html;
    }
    private static function responsive_image($id,$fallback='',$hero=false) {
        if (!$id) return '';
        $native=(string)wp_get_attachment_image_srcset($id,'medium_large');
        // Réutilise le CDN déjà actif. Aucun nouveau service n’est activé.
        $host=(string)wp_parse_url($fallback,PHP_URL_HOST);
        $meta=wp_get_attachment_metadata($id);
        if(!preg_match('/^i[0-3]\.wp\.com$/',$host) || empty($meta['width']))return $native;
        $maximum=min((int)$meta['width'],$hero?1600:640);
        $widths=$hero?array(320,640,960,1280):array(80,160,320,480);
        $widths[]= $maximum;sort($widths);$set=array();
        foreach(array_unique($widths) as $width){
            if($width>$maximum)continue;
            $url=remove_query_arg(array('fit','resize','w','h','crop','zoom'),$fallback);
            $url=add_query_arg('w',$width,$url);
            $set[]=esc_url_raw($url).' '.$width.'w';
        }
        return implode(', ',$set);
    }

    public static function rest_section($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable','Catalogue indisponible.',array('status'=>503));
        $key = sanitize_key((string) $request->get_param('section'));
        $offset = (string) $request->get_param('offset');
        if (!in_array($offset,array('0','3'),true)) return new WP_Error('slyme_offset','Position invalide.',array('status'=>400));
        foreach (self::config()['sections'] as $section) {
            if ($section['key'] !== $key || !empty($section['nav_only'])) continue;
            $ids = array_slice(self::section_ids($section),(int)$offset,6-(int)$offset);
            _prime_post_caches($ids,true,true);
            $html = '';
            foreach ($ids as $id) $html .= self::card(wc_get_product($id));
            if (self::$section_dirty) { set_transient('slyme_lists_v810',self::$section_cache,300);self::$section_dirty=false; }
            return self::response(array(array('key'=>$key,'html'=>$html)));
        }
        return new WP_Error('slyme_section','Collection inconnue.',array('status'=>404));
    }

    private static function normalize_search($text) {
        $text = strtolower(remove_accents(wp_strip_all_tags((string)$text)));
        $text = preg_replace('/\b(telephones?|smartphones?)\b/','smartphone',$text);
        $text = preg_replace('/\bordinateurs?\b/','ordinateur',$text);
        $text = preg_replace('/\bmontres?\b/','montre',$text);
        $text = preg_replace('/\btablettes?\b/','tablette',$text);
        $text = preg_replace('/(\d+)\s*(gb|go)\b/u','$1go',$text);
        $text = preg_replace('/(\d+)\s*(tb|to)\b/u','$1to',$text);
        return trim(preg_replace('/[^a-z0-9]+/',' ',$text));
    }

    private static function search_index() {
        $saved = get_transient('slyme_search_index_v812');
        if (is_array($saved)) return $saved;
        global $wpdb;
        $args = self::query_args();
        $args['posts_per_page'] = 3000;
        $args['no_found_rows'] = true;
        $args['update_post_meta_cache'] = false;
        $args['update_post_term_cache'] = false;
        $index = array();
        foreach ((new WP_Query($args))->posts as $post) {
            if ($post->post_password !== '') continue;
            $title = self::normalize_search($post->post_title);
            $index[$post->ID] = array('title'=>$title,'text'=>$title);
        }
        if ($index) {
            $ids = implode(',',array_map('absint',array_keys($index)));
            $rows = $wpdb->get_results("SELECT tr.object_id,t.name,tt.taxonomy FROM {$wpdb->term_relationships} tr INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tr.object_id IN ($ids) AND (tt.taxonomy='product_cat' OR tt.taxonomy='product_brand' OR tt.taxonomy LIKE 'pa\\_%')");
            foreach ($rows as $row) $index[$row->object_id]['text'] .= ' ' . self::normalize_search($row->name);
            $rows = $wpdb->get_results("SELECT post_id,meta_value FROM {$wpdb->postmeta} WHERE post_id IN ($ids) AND meta_key='_product_attributes'");
            foreach ($rows as $row) {
                $attributes = maybe_unserialize($row->meta_value);
                if (!is_array($attributes)) continue;
                foreach ($attributes as $attribute) if (empty($attribute['is_taxonomy']) && isset($attribute['value'])) $index[$row->post_id]['text'] .= ' ' . self::normalize_search($attribute['value']);
            }
        }
        set_transient('slyme_search_index_v812',$index,300);
        return $index;
    }

    private static function search_ids($term) {
        $normal = self::normalize_search($term);
        if (strlen($normal)<2 || strlen($normal)>80) return array();
        $tokens = array_values(array_unique(explode(' ',$normal)));
        $index = self::search_index();
        $vocabulary = array();
        foreach ($index as $item) foreach (explode(' ',$item['text']) as $word) if ($word !== '') $vocabulary[$word] = true;
        $terms = array();
        foreach ($tokens as $token) {
            $alternatives = array($token);
            // Une capacité ou un numéro de modèle ne doit jamais être corrigé.
            if (strlen($token)>=4 && !preg_match('/\d/',$token) && !isset($vocabulary[$token])) {
                $best = strlen($token)>=8 ? 2 : 1; $candidates = array();
                foreach ($vocabulary as $word=>$unused) {
                    if (strlen($word)<4 || preg_match('/\d/',$word) || abs(strlen($word)-strlen($token))>$best) continue;
                    $distance=levenshtein($token,$word);
                    if ($distance<$best) { $best=$distance; $candidates=array($word); }
                    elseif ($distance===$best) $candidates[]=$word;
                }
                $alternatives=array_merge($alternatives,array_slice($candidates,0,4));
            }
            $terms[]=$alternatives;
        }
        $ranked=array();
        foreach ($index as $id=>$item) {
            $score=0;
            foreach ($terms as $alternatives) {
                $match=0;
                foreach ($alternatives as $position=>$token) {
                    $pattern='/\b'.preg_quote($token,'/').(strlen($token)<3 || preg_match('/\d/',$token) ? '\b' : '[a-z0-9]*\b').'/';
                    if (preg_match($pattern,$item['text'])) $match=max($match,($position===0?10:6)+(preg_match($pattern,$item['title'])?4:0));
                }
                if (!$match) { $score=0;break; }
                $score+=$match;
            }
            if ($score) $ranked[$id]=$score;
        }
        arsort($ranked,SORT_NUMERIC);
        return array_keys($ranked);
    }

    private static function card($product, $eager = false) {
        $data = self::product_data($product);
        if (!$data) return '';
        $responsive = $data['srcset'];
        $image = '<img data-no-lazy="1" sizes="(max-width:599px) 44vw, (max-width:1023px) 220px, 240px"' . ($responsive ? ' srcset="' . esc_attr($responsive) . '"' : '') . ' src="' . esc_url($data['image']) . '" alt="' . esc_attr($data['name']) . '" width="600" height="600" decoding="async" draggable="false" loading="' . ($eager ? 'eager' : 'lazy') . '"' . ($eager ? ' fetchpriority="high"' : '') . '>';
        return '<a class="slyme-product-card" data-product-id="' . absint($data['id']) . '" href="' . esc_url($data['url']) . '" draggable="false"><div class="slyme-product-media" aria-hidden="true">' . $image . '</div><div class="slyme-product-content"><p class="slyme-product-brand">' . esc_html($data['brand']) . '</p><h4 class="slyme-product-name">' . esc_html($data['name']) . '</h4><p class="slyme-product-benefit">' . preg_replace('/(à partir de)/iu', '<strong class="slyme-starting-label">$1</strong>', esc_html($data['benefit'])) . '</p>' . self::price_html($data['price']) . '</div></a>';
    }

    private static function query_args() {
        $excluded = array('exclude-from-catalog');
        if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) $excluded[] = 'outofstock';
        return array('post_type' => 'product', 'post_status' => 'publish', 'has_password' => false, 'ignore_sticky_posts' => true,
            'tax_query' => array(array('taxonomy' => 'product_visibility', 'field' => 'slug', 'terms' => $excluded, 'operator' => 'NOT IN')));
    }

    public static function stock_meta_changed($meta_id, $product_id, $key) {
        if (in_array($key, array('_stock','_stock_status','_visibility'), true) && in_array(get_post_type($product_id), array('product','product_variation'), true)) self::clear_lists_cache();
    }

    public static function clear_lists_cache() {
        delete_transient('slyme_lists_v810');
        self::$section_cache = null;
        self::$section_dirty = false;
        delete_transient('slyme_search_index_v812');
        self::$curated_ids = null;
    }

    private static function section_ids($section) {
        if (null === self::$section_cache) {
            $hash = md5(wp_json_encode(self::config()['sections']));
            $saved = get_transient('slyme_lists_v810');
            self::$section_cache = is_array($saved) && ($saved['hash'] ?? '') === $hash ? $saved : array('hash'=>$hash, 'sections'=>array());
        }
        $cache_key = $section['key'];
        if (isset(self::$section_cache['sections'][$cache_key])) return self::$section_cache['sections'][$cache_key];


        // Résoudre les sélections en une lecture légère, sans instancier tout le catalogue.
        if (null === self::$curated_ids) {
            global $wpdb;
            $config = self::config();
            $ids = array_map('absint', array_keys($config['products']));
            $slugs = array_values(array_filter(array_column($config['products'], 'slug')));
            self::$curated_ids = array();
            if ($ids && $slugs) {
                $sql = "SELECT ID, post_name FROM {$wpdb->posts} WHERE post_type = 'product' AND (ID IN (" . implode(',', $ids) . ") OR post_name IN (" . implode(',', array_fill(0, count($slugs), '%s')) . ")) ORDER BY ID ASC";
                $rows = $wpdb->get_results($wpdb->prepare($sql, $slugs));
                $existing = array(); $by_slug = array();
                foreach ($rows as $row) { $existing[(int) $row->ID] = (int) $row->ID; $by_slug[$row->post_name] = (int) $row->ID; }
                foreach ($config['products'] as $id => $data) self::$curated_ids[$id] = isset($existing[$id]) ? $existing[$id] : ($by_slug[$data['slug']] ?? 0);
            }
        }
        $curated = array();
        foreach ($section['ids'] as $id) if (!empty(self::$curated_ids[$id])) $curated[] = self::$curated_ids[$id];
        $args = self::query_args();
        $args['fields'] = 'ids';
        $args['posts_per_page'] = -1;
        $args['no_found_rows'] = true;
        if ($section['categories']) {
            $args['tax_query'][] = array('taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $section['categories']);
            $args['orderby'] = 'date';
            $args['order'] = 'DESC';
            $all = (new WP_Query($args))->posts;
            // Ordre initial conservé ; les nouveaux produits de ces catégories suivent.
            $ids = array_values(array_unique(array_merge(array_intersect($curated, $all), $all)));
            self::$section_dirty = true;
            self::$section_cache['sections'][$cache_key] = $ids;
            return $ids;
        }
        $args['post__in'] = $curated ? $curated : array(0);
        $args['orderby'] = 'post__in';
        $ids = (new WP_Query($args))->posts;
        self::$section_dirty = true;
        self::$section_cache['sections'][$cache_key] = $ids;
        return $ids;
    }

    private static function view_url($base, $collection = '', $search = '', $page = 1) {
        $args = array();
        if ($collection) $args['slyme_collection'] = $collection;
        if ($search) $args['slyme_search'] = $search;
        if ($page > 1) $args['slyme_page'] = $page;
        return $args ? add_query_arg($args, $base) : $base;
    }

    private static function category_nav($base) {
        $items = array('smartphones' => 'Smartphones', 'montres' => 'Montres', 'tablettes' => 'Tablettes', 'ordinateurs' => 'Ordinateurs');
        $icons = array(
            'smartphones' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="27" y="10" width="42" height="76" rx="9"/><path d="M41 16h14M44 80h8"/><path class="slyme-category-accent" d="M35 63l25-31M35 48l15-17"/></svg>'
,            'montres' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M37 25l3-17h16l3 17M37 71l3 17h16l3-17"/><rect x="26" y="25" width="44" height="46" rx="13"/><path d="M70 40h4v10h-4"/><path class="slyme-category-accent" d="M48 35v14l9 5"/><circle cx="48" cy="49" r="17"/></svg>'
,            'tablettes' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="17" y="10" width="62" height="76" rx="7"/><path d="M23 20h50v55H23zM44 80h8"/><path class="slyme-category-accent" d="M31 62l33-29M31 47l18-16"/></svg>'
,            'ordinateurs' => '<svg class="slyme-category-symbol" viewBox="0 0 96 96" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="13" y="20" width="70" height="49" rx="5"/><path d="M13 69L5 80h86l-8-11M40 74h16"/><path class="slyme-category-accent" d="M31 53l30-18M31 40l13-8"/></svg>'
        );
        $out = '<nav class="slyme-category-nav" aria-label="Explorer les catégories"><div class="slyme-category-track" tabindex="0" aria-label="Catégories de produits">';
        foreach ($items as $key => $label) {
            $out .= '<a class="slyme-category-card" data-slyme-category="' . esc_attr($key) . '" href="' . esc_url(self::view_url($base, $key)) . '">' . $icons[$key] . '<span class="slyme-category-label">' . esc_html($label) . '</span></a>';
        }
        return $out . '</div></nav>';
    }

    private static function search_form($base, $query) {
        $uid = wp_unique_id('slyme-search-');
        $query_args = array();
        wp_parse_str((string) wp_parse_url($base, PHP_URL_QUERY), $query_args);
        $hidden = '';
        foreach (array('page_id', 'p', 'lang') as $key) if (isset($query_args[$key]) && is_scalar($query_args[$key])) $hidden .= '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($query_args[$key]) . '">';
        return '<form class="slyme-search" role="search" action="' . esc_url($base) . '" method="get">' . $hidden . '<label class="slyme-sr-only" for="' . $uid . '">Rechercher un produit</label><div class="slyme-search-field"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m16 16 4 4"></path></svg><input id="' . $uid . '" type="search" name="slyme_search" value="' . esc_attr($query) . '" placeholder="Rechercher un produit…" maxlength="80" autocomplete="off" enterkeyhint="search" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="' . $uid . '-results"><button type="submit" aria-label="Lancer la recherche"><span class="slyme-search-submit-label">Rechercher</span><svg class="slyme-search-submit-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"></path></svg></button></div><ul id="' . $uid . '-results" class="slyme-search-results" role="listbox" aria-label="Produits suggérés" hidden></ul><p class="slyme-search-status" aria-live="polite"></p></form>';
    }

    public static function catalogue() {
        if (!function_exists('wc_get_product')) return '<p>Le catalogue est momentanément indisponible.</p>';
        self::enqueue();
        global $wpdb; $started = microtime(true); $queries_before = $wpdb->num_queries;
        $base = get_permalink(get_queried_object_id());
        if (!$base) $base = home_url('/');
        $key = isset($_GET['slyme_collection']) ? sanitize_key(wp_unslash($_GET['slyme_collection'])) : '';
        $search = isset($_GET['slyme_search']) ? sanitize_text_field(wp_unslash($_GET['slyme_search'])) : '';
        $search = function_exists('mb_substr') ? mb_substr($search, 0, 80) : substr($search, 0, 80);
        $page = isset($_GET['slyme_page']) ? max(1, absint($_GET['slyme_page'])) : 1;
        $sections = self::config()['sections'];
        $selected = null;
        foreach ($sections as $section) if ($section['key'] === $key) $selected = $section;
        $hero = (!$selected && !$search) ? self::hero() : '';
        $out = '<div class="slyme-products-grid' . ($hero ? ' slyme-has-hero' : '') . '" id="slyme-catalogue" data-slyme-light="8" data-slyme-rendered="' . time() . '" data-slyme-api="' . esc_url(rest_url('slyme/v1/')) . '" data-slyme-home="' . esc_url($base) . '">';
        $out .= self::search_form($base, $search);
        if ($selected || $search) {
            $args = self::query_args();
            $args['posts_per_page'] = 24;
            $args['paged'] = $page;
            if ($search) {
                $matches = self::search_ids($search);
                $args['post__in'] = $matches ? $matches : array(0);
                $args['orderby'] = 'post__in';
                $title = 'Résultats pour « ' . $search . ' »';
            } else {
                $ids = self::section_ids($selected);
                $args['post__in'] = $ids ? $ids : array(0);
                $args['orderby'] = 'post__in';
                $title = $selected['title'];
            }
            $query = new WP_Query($args);
            $out .= '<a class="slyme-return" data-slyme-return href="' . esc_url(self::view_url($base)) . '">← Retour au catalogue</a><div class="slyme-collection-header"><h2>' . esc_html($title) . '</h2><p>' . absint($query->found_posts) . ' produit' . (1 === (int) $query->found_posts ? '' : 's') . '</p></div><div class="slyme-collection-grid">';
            foreach ($query->posts as $index => $post) $out .= self::card(wc_get_product($post->ID), 0 === $index);
            $out .= '</div>';
            if (!$query->found_posts) $out .= '<p class="slyme-empty">Aucun produit trouvé. Essaie un autre nom ou une autre marque.</p>';
            if ($query->max_num_pages > 1) {
                $out .= '<nav class="slyme-pagination" aria-label="Pages de produits">';
                if ($page > 1) $out .= '<a href="' . esc_url(self::view_url($base, $key, $search, $page - 1)) . '">← Précédent</a>';
                $out .= '<span aria-current="page">Page ' . absint($page) . ' sur ' . absint($query->max_num_pages) . '</span>';
                if ($page < $query->max_num_pages) $out .= '<a href="' . esc_url(self::view_url($base, $key, $search, $page + 1)) . '">Suivant →</a>';
                $out .= '</nav>';
            }
        } else {
            $out .= '<noscript><p>Ouvre une collection avec « Voir tout » pour consulter tous ses produits.</p><style>#slyme-catalogue .slyme-card-placeholder{display:none}</style></noscript>' . $hero . self::category_nav($base) . '<div class="slyme-boutique">';
            // Une seule préparation de métadonnées pour les aperçus, au lieu d’une par rangée.
            $preview_ids=array();foreach($sections as $preview_section){if(!empty($preview_section['nav_only']))continue;$preview_ids=array_merge($preview_ids,array_slice(self::section_ids($preview_section),0,6));}
            $preview_ids=array_values(array_unique($preview_ids));
            _prime_post_caches($preview_ids,true,true);
            $attachment_ids=array();foreach($preview_ids as $preview_id){$attachment_id=(int)get_post_meta($preview_id,'_thumbnail_id',true);if($attachment_id)$attachment_ids[]=$attachment_id;}
            if($attachment_ids)_prime_post_caches(array_values(array_unique($attachment_ids)),false,true);
            $rendered_sections = 0;
            foreach ($sections as $index => $section) {
                if (!empty($section['nav_only'])) continue;
                $ids = self::section_ids($section);
                if (!$ids) continue;
                $title = $section['title'];
                $track = 'slyme-carousel-' . $section['key'];
                $heading = explode(' ', $title, 2);
                $title_html = count($heading) === 2 ? '<span aria-hidden="true">' . esc_html($heading[0]) . '</span> ' . esc_html($heading[1]) : esc_html($title);
                $out .= '<section class="slyme-carousel-section"><header class="slyme-carousel-header"><h3 class="slyme-cat-title">' . $title_html . '</h3><div class="slyme-header-actions"><a class="slyme-see-all" href="' . esc_url(self::view_url($base, $section['key'])) . '" aria-label="Voir tous les produits — ' . esc_attr($title) . '">Voir tout <span aria-hidden="true">→</span></a><div class="slyme-carousel-controls" hidden role="group" aria-label="Défiler dans ' . esc_attr($title) . '">';
                foreach (array(true, false) as $previous) {
                    $out .= '<button class="slyme-carousel-arrow" type="button" aria-controls="' . $track . '" aria-label="' . ($previous ? 'Produits précédents' : 'Produits suivants') . '" data-slyme-' . ($previous ? 'prev' : 'next') . '><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' . ($previous ? 'm14 6-6 6 6 6' : 'm10 6 6 6-6 6') . '"></path></svg></button>';
                }
                $out .= '</div></div></header><div class="slyme-product-grid" id="' . $track . '" tabindex="0" role="group" aria-label="' . esc_attr($title) . ' — carrousel de produits" aria-keyshortcuts="ArrowLeft ArrowRight Home End">';
                $initial = $rendered_sections++ < 2 ? min(6,count($ids)) : 0;
                $visible_ids = array_slice($ids, 0, $initial);
                _prime_post_caches($visible_ids, true, true);
                foreach ($visible_ids as $position => $id) $out .= self::card(wc_get_product($id), $rendered_sections===1 && $position<3);
                if (min(6,count($ids)) > $initial) {
                    $remaining=array_slice($ids,$initial,6-$initial);
                    _prime_post_caches($remaining,true,true);
                    $ready_cards='';foreach($remaining as $id)$ready_cards.=self::card(wc_get_product($id));
                    $out .= '<template class="slyme-section-loader" data-slyme-section="' . esc_attr($section['key']) . '" data-slyme-offset="' . $initial . '">' . $ready_cards . '</template>';
                    for ($slot=$initial; $slot<min(6,count($ids)); $slot++) $out .= '<div class="slyme-product-card slyme-card-placeholder" aria-hidden="true"><div class="slyme-product-media"></div></div>';
                }
                $out .= '</div></section>';
            }
            $out .= '</div>';
        }
        if (self::$section_dirty) { set_transient('slyme_lists_v810', self::$section_cache, 300); self::$section_dirty = false; }
        if (current_user_can('manage_options') && isset($_GET['slyme_diagnostic'])) $out .= '<span hidden id="slyme-server-metrics" data-ms="' . round((microtime(true)-$started)*1000,1) . '" data-queries="' . ($wpdb->num_queries-$queries_before) . '"></span>';
        return $out . '</div>';
    }

    public static function routes() {
        register_rest_route('slyme/v1', '/section', array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>array(__CLASS__,'rest_section')));
        register_rest_route('slyme/v1', '/search', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_search'), 'args' => array('search' => array('sanitize_callback' => 'sanitize_text_field', 'default' => ''))));
        register_rest_route('slyme/v1', '/products', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_products')));
    }

    private static function response($products) {
        $response = new WP_REST_Response($products, 200);
        $response->header('Cache-Control', 'no-store, private');
        return $response;
    }

    public static function rest_search($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable', 'Catalogue indisponible.', array('status' => 503));
        $term = trim((string) $request->get_param('search'));
        $length = function_exists('mb_strlen') ? mb_strlen($term) : strlen($term);
        if ($length < 2 || $length > 80) return self::response(array());
        $ids = array_slice(self::search_ids($term),0,8);
        _prime_post_caches($ids,true,true);
        $products = array();
        foreach ($ids as $id) {
            $data = self::product_data(wc_get_product($id), false, false);
            if ($data) $products[] = $data;
        }
        return self::response($products);
    }

    public static function rest_products($request) {
        if (!function_exists('wc_get_product')) return new WP_Error('slyme_unavailable', 'Catalogue indisponible.', array('status' => 503));
        $include = $request->get_param('include');
        if (!is_string($include) || !preg_match('/^\d+(,\d+){0,59}$/', $include)) return new WP_Error('slyme_ids', 'Liste de produits invalide.', array('status' => 400));
        $products = array();
        $ids = wp_parse_id_list($include);
        _prime_post_caches($ids, true, true);
        foreach ($ids as $id) {
            $data = self::product_data(wc_get_product($id), (string) $id === (string) $request->get_param('hero'));
            if ($data) $products[] = $data;
        }
        return self::response($products);
    }

    private static function whatsapp_icon() {
        return '<svg class="slyme-wa-logo" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.5 3.5A11.9 11.9 0 0 0 12 0C5.4 0 0 5.4 0 12c0 2.1.6 4.2 1.6 6L0 24l6.2-1.6A12 12 0 0 0 12 24c6.6 0 12-5.4 12-12 0-3.2-1.2-6.2-3.5-8.5ZM12 22a10 10 0 0 1-5.1-1.4l-.4-.2-3.7 1 1-3.6-.3-.4A10 10 0 1 1 12 22Z"/><path fill="currentColor" d="M17.4 14.1c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-.9 1.2-.2.2-.3.2-.6.1-.3-.2-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6.3-.5c.1-.2.1-.4 0-.6-.1-.2-.7-1.7-1-2.3-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.7 1.2 2.9c.2.2 2 3 4.9 4.2.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.5-.1 1.8-.7 2.1-1.4.3-.7.3-1.3.2-1.4-.1-.2-.2-.2-.5-.4Z"/></svg>';
    }
    public static function whatsapp() {
        global $product;
        if (!self::public_product($product)) return;
        $phone = preg_replace('/\D/', '', get_option('slyme_whatsapp_number', '2250703283286'));
        if (!preg_match('/^[1-9]\d{9,14}$/', $phone)) return;
        $name = html_entity_decode(wp_strip_all_tags($product->get_name()), ENT_QUOTES, 'UTF-8');
        $url = get_permalink($product->get_id());
        $text = "Bonjour Slyme Abidjan, je souhaite passer commande de : " . $name . "\nQuantité : 1\n" . $url . "\nMerci de confirmer ma commande.";
        $uid = wp_unique_id('slyme-wa-');
        $currency = get_woocommerce_currency();
        $symbol = in_array($currency, array('XOF', 'XAF'), true) ? 'FCFA' : html_entity_decode(get_woocommerce_currency_symbol($currency), ENT_QUOTES, 'UTF-8');
        $unit = $product->is_type('simple') && '' !== $product->get_price() ? wc_get_price_to_display($product) : '';
        $image = wp_get_attachment_image_url($product->get_image_id(), 'woocommerce_thumbnail');
        $qtymax = $product->get_max_purchase_quantity();
        $qtymax = $qtymax > 0 ? ' max="' . esc_attr($qtymax) . '"' : '';
        $logo = self::whatsapp_icon();
        $in_stock = $product->is_in_stock();
        $variable = $product->is_type('variable');
        $ready = $in_stock && !$variable && $product->is_purchasable();
        $state = $ready ? '' : ' aria-disabled="true" tabindex="-1"';
        $destination = $ready ? ' href="' . esc_url('https://wa.me/' . $phone . '?text=' . rawurlencode($text)) . '"' : '';
        $label = !$in_stock ? 'Rupture de stock' : ($variable ? 'Choisissez vos options' : ($ready ? 'Commander sur WhatsApp' : 'Produit indisponible'));
        echo '<div class="slyme-whatsapp"><a class="slyme-whatsapp-link" data-in-stock="' . ($in_stock ? '1' : '0') . '" data-purchasable="' . ($product->is_purchasable() ? '1' : '0') . '" data-variable="' . ($variable ? '1' : '0') . '"' . $state . ' data-phone="' . esc_attr($phone) . '" data-product-name="' . esc_attr($name) . '" data-product-url="' . esc_url($url) . '" data-unit-price="' . esc_attr($unit) . '" data-currency="' . esc_attr($symbol) . '" data-decimals="' . absint(wc_get_price_decimals()) . '"' . $destination . ' target="_blank" rel="noopener noreferrer">' . $logo . '<span data-wa-link-label>' . esc_html($label) . '</span><span class="slyme-wa-link-arrow" aria-hidden="true">↗</span></a><p class="slyme-wa-link-note" aria-live="polite">' . esc_html($ready ? 'Votre produit, vos options et vos coordonnées dans un seul message.' : (!$in_stock ? 'Ce produit est actuellement indisponible.' : 'Sélectionnez une option disponible pour commander.')) . '</p>
<dialog class="slyme-whatsapp-dialog" aria-labelledby="' . esc_attr($uid) . 'title"><form class="slyme-whatsapp-form" method="dialog">
<header class="slyme-wa-header"><span class="slyme-wa-brand">' . $logo . '</span><div><p class="slyme-wa-eyebrow">Commande WhatsApp</p><h2 id="' . esc_attr($uid) . 'title">Votre commande.</h2></div><button class="slyme-wa-close" type="button" aria-label="Fermer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg></button></header>
<div class="slyme-wa-body"><p class="slyme-wa-intro">Quelques détails, et on s’occupe de vous.</p><section class="slyme-wa-product" aria-label="Récapitulatif du produit">';
        if ($image) echo '<img class="slyme-wa-photo" src="' . esc_url($image) . '" width="72" height="72" loading="lazy" decoding="async" alt="">';
        echo '<div class="slyme-wa-product-info"><strong>' . esc_html($name) . '</strong><p data-wa-options></p><p class="slyme-wa-unit" data-wa-unit hidden></p></div></section>
<div class="slyme-wa-order-row"><div><label for="' . esc_attr($uid) . 'quantity">Quantité</label><div class="slyme-wa-quantity"><button type="button" data-wa-quantity-step="-1" aria-label="Diminuer la quantité">−</button><input id="' . esc_attr($uid) . 'quantity" name="customer_quantity" type="number" inputmode="numeric" min="1" step="1"' . $qtymax . ' value="1" required aria-label="Quantité"><button type="button" data-wa-quantity-step="1" aria-label="Augmenter la quantité">+</button></div></div><div class="slyme-wa-total" hidden><span>Montant des produits</span><strong data-wa-total></strong></div></div>
<h3 class="slyme-wa-section-title">Vos coordonnées</h3>
<div class="slyme-wa-names"><label>Nom<input name="customer_lastname" autocomplete="family-name" maxlength="80" required placeholder="Votre nom"></label><label>Prénom<input name="customer_firstname" autocomplete="given-name" maxlength="80" required placeholder="Votre prénom"></label></div>
<label>Numéro de téléphone<input name="customer_phone" type="tel" autocomplete="tel" inputmode="tel" maxlength="24" required placeholder="Ex. +225 07 00 00 00 00"></label>
<label>Adresse de livraison<textarea name="customer_address" autocomplete="street-address" rows="2" maxlength="500" required placeholder="Commune, quartier et repère…"></textarea></label>
<label>Précisions pour la livraison <span class="slyme-wa-optional">(facultatif)</span><textarea name="customer_note" rows="2" maxlength="500" placeholder="Une indication utile pour le livreur…"></textarea></label>
</div>
<footer class="slyme-wa-footer"><p>Relisez le message dans WhatsApp avant de l’envoyer.</p><button class="slyme-wa-submit" type="submit">' . $logo . '<span>Continuer sur WhatsApp</span><span aria-hidden="true">↗</span></button></footer>
</form></dialog></div>';
    }

    public static function admin_menu() {
        add_options_page('Slyme — Catalogue', 'Slyme Catalogue', 'manage_options', 'slyme-catalogue', array(__CLASS__, 'settings_page'));
    }
    public static function settings() {
        register_setting('slyme_catalogue', 'slyme_whatsapp_number', array('type' => 'string', 'sanitize_callback' => array(__CLASS__, 'sanitize_phone'), 'default' => '2250703283286'));
    }
    public static function sanitize_phone($value) {
        $number = preg_replace('/\D/', '', (string) $value);
        if ('' === $number || preg_match('/^[1-9]\d{9,14}$/', $number)) return $number;
        add_settings_error('slyme_whatsapp_number', 'invalid_phone', 'Saisis le numéro complet avec son indicatif, par exemple 2250703283286.');
        return get_option('slyme_whatsapp_number', '2250703283286');
    }
    public static function settings_page() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>Slyme — Catalogue fluide</h1><p>Sur la page du catalogue, remplace l’ancien bloc par un bloc Code court contenant <code>[slyme_catalogue]</code>.</p><form action="options.php" method="post">';
        settings_fields('slyme_catalogue');
        echo '<table class="form-table"><tr><th scope="row"><label for="slyme-whatsapp-number">Numéro WhatsApp</label></th><td><input id="slyme-whatsapp-number" class="regular-text" type="tel" name="slyme_whatsapp_number" value="' . esc_attr(get_option('slyme_whatsapp_number', '2250703283286')) . '"><p class="description">Indicatif et numéro complet. Le numéro prérempli est celui du service client publié sur slymeabidjan.ci. Utilise ici ton numéro WhatsApp ; laisse vide pour masquer le bouton.</p></td></tr></table>';
        echo '<p><input type="hidden" name="slyme_product_presentation" value="0"><label><input type="checkbox" name="slyme_product_presentation" value="1"' . checked(get_option('slyme_product_presentation', '1'), '1', false) . '> Activer les aides à l’achat sur les fiches produit</label></p><p>Personnalise les caractéristiques dans <strong>Produits → Fiches Slyme</strong>. Les caractéristiques gardent la mise en page du thème, sans icônes ni blocs décoratifs ajoutés.</p>';
        do_action('slyme_catalogue_settings_fields');
        submit_button();
        echo '</form><h2>Diagnostic de fluidité</h2><p>Connecté comme administrateur, ouvre la page du catalogue avec <code>?slyme_diagnostic=1</code> dans son adresse (ou <code>&amp;slyme_diagnostic=1</code> si elle contient déjà un paramètre). Le panneau mesure cette visite uniquement, sans envoi de données. Les durées des fichiers indiquent leur chargement, pas leur coût JavaScript.</p><p><a class="button" href="' . esc_url(add_query_arg('slyme_diagnostic','1',home_url('/'))) . '">Tester la page d’accueil</a></p><p>Les prix, noms et liens proviennent de WooCommerce. Les carrousels présentent jusqu’à 6 produits ; « Voir tout » donne accès à la collection complète, par pages de 24 produits. Les sélections « Nos offres du moment », « Tout juste sortis » et « Autres » reprennent tes sélections actuelles.</p></div>';
    }
    public static function dependency_notice() {
        if (!function_exists('wc_get_product') && current_user_can('activate_plugins')) echo '<div class="notice notice-warning"><p>Slyme Catalogue nécessite WooCommerce actif.</p></div>';
    }
}
Slyme_Catalogue_V6::boot();
require_once __DIR__ . '/includes/product-presentation.php';
Slyme_Product_Presentation::boot();

require_once __DIR__ . '/includes/product-shopping.php';
Slyme_Product_Shopping::boot();
