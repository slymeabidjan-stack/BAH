/* Extensions de l’interface native : WooCommerce garde les variantes, le stock et le panier. */
(() => {
 'use strict';
 const start=()=>{
  const config=window.slymeShopping||{},$=window.jQuery;
  let confirmedCart=false;
  if(document.body.classList.contains('woocommerce-cart')){
   try{confirmedCart=sessionStorage.getItem('slyme:cart-confirmed')==='1';sessionStorage.removeItem('slyme:cart-confirmed');}catch(error){/* Le panier natif fonctionne aussi sans stockage navigateur. */}
  }
  // Le retour d’un ajout classique peut arriver sur le panier, sans fiche produit.
  const feedback=(()=>{
   let node=document.querySelector('[data-sls-feedback]');
   if(!node){
    node=document.createElement('div');node.className='sls-feedback';node.dataset.slsFeedback='';node.hidden=true;
    node.setAttribute('role','status');node.setAttribute('aria-live','polite');node.setAttribute('aria-atomic','true');
    node.innerHTML='<div class="sls-feedback-card"><span class="sls-feedback-icon" aria-hidden="true">✓</span><div><strong data-sls-feedback-title></strong><p data-sls-feedback-message></p><div class="sls-feedback-actions"><button type="button" data-sls-feedback-dismiss>Continuer mes achats</button><a data-sls-feedback-cart>Voir le panier</a></div></div><button type="button" class="sls-feedback-close" data-sls-feedback-dismiss aria-label="Fermer">×</button></div>';
    document.body.append(node);
   }
   const title=node.querySelector('[data-sls-feedback-title]'),message=node.querySelector('[data-sls-feedback-message]'),cart=node.querySelector('[data-sls-feedback-cart]');
   const dismiss=node.querySelector('.sls-feedback-actions [data-sls-feedback-dismiss]');
   let announcement=document.querySelector('[data-sls-feedback-announcement]'),announcementTimer=0;
   if(!announcement){
    announcement=document.createElement('span');announcement.className='sls-feedback-announcement';announcement.dataset.slsFeedbackAnnouncement='';
    announcement.setAttribute('role','status');announcement.setAttribute('aria-live','polite');announcement.setAttribute('aria-atomic','true');
    document.body.append(announcement);
   }
   // Une région toujours présente annonce le texte, sans relire les boutons de la carte.
   node.setAttribute('aria-live','off');
   const hide=()=>{clearTimeout(announcementTimer);node.hidden=true;};
   if(!node.dataset.slsReady){
    node.dataset.slsReady='1';
    node.querySelectorAll('[data-sls-feedback-dismiss]').forEach(button=>button.addEventListener('click',()=>{
     const continueShopping=button===dismiss&&node.dataset.kind==='success'&&document.body.classList.contains('woocommerce-cart')&&config.shopUrl;
     hide();
     if(continueShopping)window.location.assign(config.shopUrl);
    }));
    document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!node.hidden)hide();});
   }
   const show=(heading,text,success=false)=>{
    title.textContent=heading;message.textContent=text;
    node.dataset.kind=success?'success':'choice';
    node.querySelector('.sls-feedback-icon').textContent=success?'✓':'i';
    dismiss.textContent=success?'Continuer mes achats':'D’accord';
    cart.hidden=!success||!config.cartUrl;
    if(config.cartUrl)cart.href=config.cartUrl;
    node.hidden=false;
    clearTimeout(announcementTimer);announcement.textContent='';
    announcementTimer=setTimeout(()=>{announcement.textContent=heading+'. '+text;},100);
   };
   const success=()=>show('Ajouté au panier','Votre article vous attend. Vous pouvez continuer vos achats.',true);
   if($&&!document.body.dataset.slsFeedbackReady){
    document.body.dataset.slsFeedbackReady='1';
    $(document.body).on('added_to_cart.slsFeedback',success);
   }
   if(config.addedToCart||confirmedCart)success();
   return {show,hide};
  })();
  if(!document.body.classList.contains('slyme-product-shopping'))return;
  const product=document.querySelector('div.product[id^="product-"]');
  const form=product?.querySelector('form.cart');
  if(!product||!form||form.dataset.slsReady)return;
  form.dataset.slsReady='1';
  const variable=form.classList.contains('variations_form');
  const selects=[...form.querySelectorAll('.variations select[name^="attribute_"]')];
  const nativeButton=form.querySelector('.single_add_to_cart_button');
  const groups=[];
  const normalize=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const colors={noir:'#000',black:'#000',blanc:'#fff',white:'#fff',bleu:'#0184c8',blue:'#0184c8',rouge:'#e51b23',red:'#e51b23',vert:'#008b45',green:'#008b45',violet:'#8224e3',purple:'#8224e3',rose:'#ed5c9c',pink:'#ed5c9c',orange:'#ff6b00',gris:'#969b9f',grey:'#969b9f',gray:'#969b9f',argent:'#c3c9ce',silver:'#c3c9ce',or:'#c6ad7b',gold:'#c6ad7b',beige:'#d8cbb6',marron:'#503727',brown:'#503727'};
  Object.entries(config.colors||{}).forEach(([name,hex])=>{if(/^#(?:[a-f0-9]{3}|[a-f0-9]{6})$/i.test(hex))colors[normalize(name)]=hex;});
  const kindFor=select=>{
   const name=normalize(select.name+' '+(select.closest('tr')?.querySelector('label')?.textContent||''));
   if(/\b(couleurs?|colou?rs?|coloris)\b/.test(name))return 'color';
   if(/\b(ram|memoire vive)\b/.test(name))return 'memory';
   if(/\b(stockage|capacite|capacity|storage|memoire)\b/.test(name))return 'storage';
   return '';
  };
  const missingSelections=()=>selects.filter(select=>!select.value);
  const choiceMessage=()=>{
   const labels=[...new Set(missingSelections().map(select=>{
    const kind=kindFor(select);
    if(kind==='color')return 'la couleur';
    if(kind==='storage')return 'la capacité';
    if(kind==='memory')return 'la mémoire vive';
    const label=select.closest('tr')?.querySelector('label')?.textContent.trim()||select.name.replace(/^attribute_(pa_)?/,'').replace(/[-_]/g,' ');
    return 'l’option « '+label+' »';
   }))];
   const joined=labels.length>1?labels.slice(0,-1).join(', ')+' et '+labels[labels.length-1]:labels[0];
   return joined?'Choisissez '+joined+' pour continuer.':'Choisissez vos options pour continuer.';
  };
  let singletonTimer=0;
  const autoSelectSingletons=()=>{
   clearTimeout(singletonTimer);
   singletonTimer=0;
   if(!variable||!$||!$.fn.wc_variation_form)return;
   const variations=$(form).data('product_variations');
   // Ne choisir que lorsqu’il n’existe aucun choix réel ; conserver les valeurs du marchand.
   selects.forEach(select=>{
    if(select.value||select.disabled)return;
    const options=[...select.options].filter(option=>{
     if(!option.value||option.disabled)return false;
     if(!Array.isArray(variations))return true;
     return variations.some(variation=>variation.is_in_stock!==false&&variation.is_purchasable!==false&&variation.variation_is_visible!==false&&selects.every(other=>{
      const value=other===select?option.value:other.value;
      return !value||!variation.attributes?.[other.name]||variation.attributes[other.name]===value;
     }));
    });
    if(options.length===1){select.value=options[0].value;select.dispatchEvent(new Event('change',{bubbles:true}));}
   });
   syncGroups();
  };
  const scheduleSingletons=()=>{if(!singletonTimer)singletonTimer=setTimeout(autoSelectSingletons,0);};
  const summaries=[...product.querySelectorAll('[data-sls-spec]')].map(node=>({node,text:node.textContent}));
  const syncSummary=()=>summaries.forEach(({node,text})=>{
   const select=selects.find(s=>kindFor(s)===node.dataset.slsSpec);
   node.textContent=select?.value?select.selectedOptions[0].textContent:text;
  });
  const syncGroups=()=>{
   groups.forEach(({select,buttons})=>{
    const options=new Map([...select.options].map(o=>[o.value,o]));
    buttons.forEach(button=>{
     const option=options.get(button.dataset.value),selected=select.value===button.dataset.value;
     button.disabled=select.disabled||!option||option.disabled;
     button.setAttribute('aria-checked',String(selected));
     button.tabIndex=-1;
     button.title=button.textContent+(button.disabled?' — Indisponible avec ces options':'');
    });
    const target=buttons.find(b=>!b.disabled&&b.getAttribute('aria-checked')==='true')||buttons.find(b=>!b.disabled);
    if(target)target.tabIndex=0;
   });
   syncSummary();
  };
  if(variable&&$&&$.fn.wc_variation_form&&config.visual){
   selects.forEach((select,index)=>{
    const kind=kindFor(select);if(!kind)return;
    const reference=document.createElement('select');
    reference.innerHTML=$(select).data('attribute_html')||select.innerHTML;
    const options=[...reference.options].filter(o=>o.value);
    if(!options.length||options.length>24)return;
    // Si une autre extension transforme déjà ce champ, garder son interface.
    if(select.hidden||getComputedStyle(select).display==='none')return;
    const label=select.closest('tr')?.querySelector('label');
    const group=document.createElement('div');group.className='sls-options';group.setAttribute('role','radiogroup');
    if(label){if(!label.id)label.id='sls-label-'+index;group.setAttribute('aria-labelledby',label.id);}else group.setAttribute('aria-label',select.name.replace(/^attribute_(pa_)?/,''));
    const buttons=options.map((option,i)=>{
     const button=document.createElement('button');button.type='button';button.className='sls-option';button.id='sls-option-'+index+'-'+i;button.dataset.value=option.value;button.setAttribute('role','radio');button.setAttribute('aria-label',option.textContent.trim());
     if(kind==='color'&&colors[normalize(option.textContent)]){
      const dot=document.createElement('span');dot.className='sls-color';dot.setAttribute('aria-hidden','true');dot.style.backgroundColor=colors[normalize(option.textContent)];button.append(dot);
     }
     const text=document.createElement('span');text.textContent=option.textContent;button.append(text);
     button.addEventListener('click',()=>{if(button.disabled)return;select.value=option.value;select.dispatchEvent(new Event('change',{bubbles:true}));syncGroups();});
     group.append(button);return button;
    });
    group.addEventListener('keydown',event=>{
     if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
     const enabled=buttons.filter(b=>!b.disabled);if(!enabled.length)return;
     event.preventDefault();let i=enabled.indexOf(document.activeElement);
     if(event.key==='Home')i=0;else if(event.key==='End')i=enabled.length-1;else i=(i+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1)+enabled.length)%enabled.length;
     enabled[i].focus();enabled[i].click();
    });
    select.after(group);select.hidden=true;select.classList.add('sls-native-select');
    if(label)label.htmlFor=buttons[0].id;
    groups.push({select,buttons});
   });
   $(form).on('woocommerce_update_variation_values.sls wc_variation_form.sls reset_data.sls woocommerce_variation_has_changed.sls',syncGroups);
   // WooCommerce demande parfois le focus sur le select natif après une remise à zéro.
   $(form).on('reset_focus.sls',()=>groups[0]?.buttons.find(b=>!b.disabled)?.focus());
  }
  if(groups.length)form.classList.add('sls-visual-options');
  form.addEventListener('change',syncSummary);
  if(variable&&$)$(form).on('woocommerce_variation_has_changed.slsSummary reset_data.slsSummary',syncSummary);
  syncGroups();
  if(variable&&$&&$.fn.wc_variation_form){
   $(form).on('woocommerce_update_variation_values.slsSingleton wc_variation_form.slsSingleton',scheduleSingletons);
   scheduleSingletons();
  }
  const bar=document.querySelector('[data-sls-bar]');
  if(!bar)return;
  if(!nativeButton||variable&&(!$||!$.fn.wc_variation_form))return;
  const price=bar.querySelector('.sls-buybar-price'),caption=bar.querySelector('.sls-buybar-caption'),status=bar.querySelector('.sls-buybar-status'),action=bar.querySelector('.sls-buybar-action');
  const actionLabel=action.querySelector('span'),photo=bar.querySelector('.sls-buybar-image');
  const originalPhoto=photo?{src:photo.getAttribute('src'),srcset:photo.getAttribute('srcset')||''}:null;
  const originalPrice=price.innerHTML,mobile=matchMedia('(max-width: 767px)'),reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let current=null,ready=false,busy=false,pending=false,lookupFailed=false,visibilityFrame=0,goToCart=false;
  const complete=()=>selects.length>0&&selects.every(s=>s.value);
  const matches=v=>v&&complete()&&selects.every(s=>!v.attributes?.[s.name]||v.attributes[s.name]===s.value)&&String(form.querySelector('[name="variation_id"]')?.value)===String(v.variation_id);
  const nativeUnavailable=()=>nativeButton.disabled||nativeButton.classList.contains('disabled')||nativeButton.classList.contains('loading');
  const canBuy=()=>!busy&&!nativeUnavailable()&&(!variable||(ready&&matches(current)&&current.is_purchasable&&current.is_in_stock&&current.variation_is_visible));
  const textFrom=html=>{const div=document.createElement('div');div.innerHTML=html||'';return div.textContent.trim();};
  const selectedPrice=variation=>{
   if(variation.price_html)return variation.price_html;
   // WooCommerce peut ne pas fournir de HTML lorsque les variantes ont le même prix.
   if(typeof variation.display_price!=='number'||!Number.isFinite(variation.display_price))return originalPrice;
   const money=config.money||{decimals:0,decimal:',',thousand:' ',format:'%2$s %1$s',symbol:'FCFA'};
   const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
   const parts=variation.display_price.toFixed(Math.max(0,Math.min(6,Number(money.decimals)||0))).split('.');
   const amount=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,()=>money.thousand)+(parts.length>1?money.decimal+parts[1]:'');
   return '<span class="woocommerce-Price-amount amount"><bdi>'+escape(textFrom(money.format)).replace('%1$s','<span class="woocommerce-Price-currencySymbol">'+escape(textFrom(money.symbol))+'</span>').replace('%2$s',escape(amount))+'</bdi></span>';
  };
  const render=()=>{
   const valid=variable&&matches(current);
   const nextPrice=valid?selectedPrice(current):originalPrice;
   if(price.innerHTML!==nextPrice){price.innerHTML=nextPrice;if(!bar.hidden)price.dispatchEvent(new CustomEvent('slyme:price',{bubbles:true}));}
   const qty=Number(form.querySelector('input.qty')?.value||1);
   caption.textContent=valid?'Option sélectionnée'+(qty>1?' · prix unitaire':''):variable?'Sélectionne tes options':qty>1?'Prix unitaire · '+qty+' articles':'Prix unitaire';
   status.textContent=busy?'Ajout en cours…':valid?(textFrom(current.availability_html)||(current.is_in_stock?'Disponible':'Indisponible')):pending?'Vérification de la disponibilité…':lookupFailed?'Vérification impossible. Réessayez.':variable?(missingSelections().length?choiceMessage():'Choisissez à nouveau vos options.'):(textFrom(product.querySelector('.summary .stock')?.innerHTML||'')||'En stock');
   const unavailable=valid&&(!current.is_in_stock||!current.is_purchasable||!current.variation_is_visible);
   const blocked=unavailable||(!variable&&nativeUnavailable())||(variable&&complete()&&!pending&&nativeUnavailable());
   actionLabel.textContent=busy?'Ajout en cours…':pending?'Vérification…':lookupFailed?'Réessayer':blocked?'Indisponible':'Je l’achète';
   action.disabled=busy||pending||(blocked&&!lookupFailed);
   bar.dataset.stock=unavailable?'out':valid||!variable?'in':'choose';
   if(photo&&originalPhoto){
    const image=valid&&current.image?.src?current.image:null;
    const nextSrc=image?.gallery_thumbnail_src||image?.thumb_src||image?.src||originalPhoto.src;
    const nextSet=image?(image.srcset||''):originalPhoto.srcset;
    if(photo.getAttribute('src')!==nextSrc)photo.setAttribute('src',nextSrc);
    if(nextSet)photo.setAttribute('srcset',nextSet);else photo.removeAttribute('srcset');
   }
  };
  const thresholdTarget=product.querySelector('.slyme-whatsapp-link')||nativeButton;
  const updateVisibility=()=>{
   visibilityFrame=0;
   const active=document.activeElement;
   const editing=active&&(/^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)||active.isContentEditable);
   const rect=thresholdTarget.getBoundingClientRect();
   // Prendre le relais dès que « Commander sur WhatsApp » vient de sortir en haut.
   const visible=mobile.matches&&rect.bottom<0&&!editing&&rect.height>0;
   const wasHidden=bar.hidden;
   bar.hidden=!visible;
   if(visible&&wasHidden)bar.dispatchEvent(new CustomEvent('slyme:enter',{bubbles:true}));
   document.body.classList.toggle('sls-has-buybar',visible);
   if(visible)document.body.style.setProperty('--sls-bar-height',bar.offsetHeight+'px');
  };
  const scheduleVisibility=()=>{if(!visibilityFrame)visibilityFrame=requestAnimationFrame(updateVisibility);};
  if('IntersectionObserver' in window)new IntersectionObserver(scheduleVisibility).observe(thresholdTarget);
  window.addEventListener('scroll',scheduleVisibility,{passive:true});
  if('ResizeObserver' in window){const observer=new ResizeObserver(scheduleVisibility);observer.observe(bar);observer.observe(thresholdTarget);}
  mobile.addEventListener('change',scheduleVisibility);
  window.addEventListener('resize',scheduleVisibility,{passive:true});
  document.addEventListener('focusin',scheduleVisibility);document.addEventListener('focusout',scheduleVisibility);
  window.addEventListener('pageshow',()=>{clearCartIntent();busy=false;render();scheduleVisibility();});
  form.addEventListener('change',event=>{
   if(event.target.matches('select[name^="attribute_"]')){current=null;ready=false;lookupFailed=false;pending=complete();render();scheduleSingletons();}
  },true);
  if(variable){
   $(form).on('found_variation.sls',(event,variation)=>{current=variation;ready=false;lookupFailed=false;pending=false;render();});
   $(form).on('show_variation.sls',(event,variation,purchasable)=>{if(matches(variation)){current=variation;ready=!!purchasable;pending=false;render();}});
   $(form).on('reset_data.sls hide_variation.sls',()=>{current=null;ready=false;lookupFailed=false;pending=false;render();});
   $(form).on('woocommerce_variation_has_changed.sls',()=>{if(!matches(current)){current=null;ready=false;}render();});
   // Une requête échouée ne doit pas laisser la barre bloquée.
   $(document).on('ajaxError.sls',(event,xhr,settings)=>{
    if(!pending||xhr.statusText==='abort'||!String(settings.url).includes('wc-ajax=get_variation'))return;
    const productId=new URLSearchParams(settings.data||'').get('product_id');
    if(productId&&productId!==String(form.dataset.product_id))return;
    current=null;ready=false;pending=false;lookupFailed=true;render();
   });
  }
  form.addEventListener('change',render);
  let targetTimer=0;
  const goToForm=()=>{
   const select=selects.find(s=>!s.value);
   const target=select?(groups.find(g=>g.select===select)?.buttons.find(b=>!b.disabled)||select):nativeButton;
   if(!target)return;
   form.querySelectorAll('.sls-buy-target').forEach(node=>node.classList.remove('sls-buy-target'));
   clearTimeout(targetTimer);
   target.classList.add('sls-buy-target');
   target.scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'center'});
   target.focus({preventScroll:true});
   targetTimer=setTimeout(()=>target.classList.remove('sls-buy-target'),1800);
  };
  const clearCartIntent=()=>{goToCart=false;form.querySelector('input[data-sls-cart-intent]')?.remove();};
  action.addEventListener('click',()=>{
   if(action.disabled)return;
   autoSelectSingletons();
   if(variable&&!complete()){
    feedback.show('Personnalisez votre produit',choiceMessage());
    goToForm();scheduleVisibility();return;
   }
   if(variable&&lookupFailed){lookupFailed=false;pending=true;render();$(form).trigger('check_variations');return;}
   if(!canBuy())return;
   if(!form.checkValidity()){form.reportValidity();return;}
   feedback.hide();
   let intent=form.querySelector('input[data-sls-cart-intent]');
   if(!intent){intent=document.createElement('input');intent.type='hidden';intent.name='sls_go_to_cart';intent.dataset.slsCartIntent='';form.append(intent);}
   intent.value='1';goToCart=true;
   // WooCommerce valide encore le stock et la variante ; conserver son bouton comme submitter.
   if(typeof form.requestSubmit==='function')form.requestSubmit(nativeButton);else nativeButton.click();
  });
  form.addEventListener('submit',event=>{if(!event.defaultPrevented){busy=true;render();}});
  form.addEventListener('invalid',clearCartIntent,true);
  if($){
   $(document.body).on('added_to_cart.sls',(event,fragments,hash,button)=>{
    busy=false;render();
    const addedButton=button?.jquery?button[0]:button instanceof Element?button:null;
    if(goToCart&&config.cartUrl&&addedButton&&(addedButton===nativeButton||form.contains(addedButton))){
     try{sessionStorage.setItem('slyme:cart-confirmed','1');}catch(error){/* Ne pas bloquer la navigation si le stockage est indisponible. */}
     clearCartIntent();window.location.assign(config.cartUrl);
    }
   });
   $(document.body).on('wc_add_to_cart_error.sls',()=>{clearCartIntent();busy=false;render();});
   $(document).on('ajaxError.slsCart',(event,xhr,settings)=>{
    if((busy||goToCart)&&String(settings.url).includes('wc-ajax=add_to_cart')){clearCartIntent();busy=false;render();}
   });
  }
  if('MutationObserver' in window)new MutationObserver(render).observe(nativeButton,{attributes:true,attributeFilter:['class','disabled']});
  render();scheduleVisibility();
  if(variable){pending=complete();render();$(form).trigger('check_variations');}
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
